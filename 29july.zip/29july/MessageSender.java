package com.ltts;

import org.apache.log4j.Logger;

import com.microsoft.azure.iothub.DeviceClient;
import com.microsoft.azure.iothub.Message;

public class MessageSender{
	private final static Logger logger = Logger.getLogger(MessageSender.class);
	private DeviceClient client;

	public MessageSender(DeviceClient client) {
		super();
		this.client = client;
	}

	public void sendData(TelemetryDataPoint pTelemetryData) {
		logger.trace("sendData - Enter");
		try {
			String sMsg = pTelemetryData.serialize();
			Message objMessage = new Message(sMsg);			
			logger.debug("Message sent: " + sMsg);
			Object objLock = new Object();
			EventCallback callback = new EventCallback();
			client.sendEventAsync(objMessage, callback, objLock);
			
//			synchronized (objLock) {
//				objLock.wait();
//			}
			Thread.sleep(5);

		} catch (Exception e) {
			logger.error("Error while sending data", e);			
		}
		logger.trace("sendData - Leave");		
	}
}