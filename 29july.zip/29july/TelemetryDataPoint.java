package com.ltts;

import java.math.BigDecimal;

import com.google.gson.Gson;

public class TelemetryDataPoint {
	public String macId;
	public BigDecimal energy;
	public String tstampval;

	public TelemetryDataPoint(String macId, BigDecimal energy, String timestamp) {
		super();
		this.macId = macId;
		this.energy = energy;
		this.tstampval = timestamp;
	}

	public String serialize() {
		Gson gson = new Gson();
		return gson.toJson(this);
	}

}
