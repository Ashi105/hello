var fs = require('fs');
var csv = require('fast-csv');
var list = [];
const data = "";
var read = fs.createReadStream('view.csv')
.pipe(csv())
.on('data',function(data){
     list.push(data[1]); // I already tried to get out data in here but data don't get out the function
        console.log(data);
})
.on('end', function(data){
    console.log('Read finished');
})

console.log("test"); // why it run the first
console.log(data); // empty
for (var i = 0; i < list.length; i++){
     console.log(list[i]); // list is empty.Why?
}
