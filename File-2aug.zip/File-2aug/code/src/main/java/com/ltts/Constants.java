package com.ltts;

public class Constants {
	public static final String MACID = "LCLid";
	public static final String ENERGY_CONSUMPTION = "energy(kWh/hh)";
	public static final String TIMESTAMPVAL = "tstp";
	
	public static final String CONSUMPTION_FOLDER = "F:\\project\\datalakesetup\\impl\\data3\\halfhourly_dataset";
	public static final String DEVICEMAP_FILE = "devicelist.json";
}
