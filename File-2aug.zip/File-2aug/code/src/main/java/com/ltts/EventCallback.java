package com.ltts;

import org.apache.log4j.Logger;

import com.microsoft.azure.iothub.IotHubEventCallback;
import com.microsoft.azure.iothub.IotHubStatusCode;

public class EventCallback implements IotHubEventCallback {
	private final static Logger logger = Logger.getLogger(MessageSender.class);
	
	public void execute(IotHubStatusCode status, Object context) {
		logger.debug("IoT hub response: " + status.name());
		if (context != null) {
			synchronized (context) {
				context.notify();
			}
		}
	}
	
}