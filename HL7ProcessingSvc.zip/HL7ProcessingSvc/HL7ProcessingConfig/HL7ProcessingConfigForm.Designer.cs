namespace HL7ProcessingConfig
{
	partial class HL7ProcessingConfigForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.groupBoxTPS = new System.Windows.Forms.GroupBox();
			this.numTPSPortNumber = new System.Windows.Forms.NumericUpDown();
			this.textBoxTPSIPAddress = new System.Windows.Forms.TextBox();
			this.labelPortNumber = new System.Windows.Forms.Label();
			this.labelIPAddress = new System.Windows.Forms.Label();
			this.groupBoxHIS = new System.Windows.Forms.GroupBox();
			this.numHISPortNumber = new System.Windows.Forms.NumericUpDown();
			this.textBoxHISIPAddress = new System.Windows.Forms.TextBox();
			this.labelHISPortNumber = new System.Windows.Forms.Label();
			this.labelHISIPAddress = new System.Windows.Forms.Label();
			this.groupBoxFieldLimits = new System.Windows.Forms.GroupBox();
			this.NumORUMsgPIDPatientAccountNumber = new System.Windows.Forms.NumericUpDown();
			this.label28 = new System.Windows.Forms.Label();
			this.NumORUMsgOBROrderedCategory = new System.Windows.Forms.NumericUpDown();
			this.NumORUMsgOBROrderControlNumber = new System.Windows.Forms.NumericUpDown();
			this.label27 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.numORMMsgORCDateOfService = new System.Windows.Forms.NumericUpDown();
			this.label25 = new System.Windows.Forms.Label();
			this.numORMMsgPV1HospitalService = new System.Windows.Forms.NumericUpDown();
			this.label24 = new System.Windows.Forms.Label();
			this.numORMMsgPV1VisitNumber = new System.Windows.Forms.NumericUpDown();
			this.label23 = new System.Windows.Forms.Label();
			this.numORMMsgOBROrderedCategory = new System.Windows.Forms.NumericUpDown();
			this.numORMMsgOBROrderControlNumber = new System.Windows.Forms.NumericUpDown();
			this.label22 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.numORMMsgPIDPatientAccountNumber = new System.Windows.Forms.NumericUpDown();
			this.label20 = new System.Windows.Forms.Label();
			this.numACKMSAControlID = new System.Windows.Forms.NumericUpDown();
			this.label19 = new System.Windows.Forms.Label();
			this.numACKMSAAckCode = new System.Windows.Forms.NumericUpDown();
			this.label18 = new System.Windows.Forms.Label();
			this.numORUOBXSummaryNarrative = new System.Windows.Forms.NumericUpDown();
			this.label17 = new System.Windows.Forms.Label();
			this.numORUOBXObservationValue = new System.Windows.Forms.NumericUpDown();
			this.label14 = new System.Windows.Forms.Label();
			this.numORUOBXObservationId = new System.Windows.Forms.NumericUpDown();
			this.label15 = new System.Windows.Forms.Label();
			this.numORUOBXTypeCode = new System.Windows.Forms.NumericUpDown();
			this.label16 = new System.Windows.Forms.Label();
			this.numORUPIDPatientSex = new System.Windows.Forms.NumericUpDown();
			this.label12 = new System.Windows.Forms.Label();
			this.numORUPIDPatientName = new System.Windows.Forms.NumericUpDown();
			this.label13 = new System.Windows.Forms.Label();
			this.numORUPIDPatientID = new System.Windows.Forms.NumericUpDown();
			this.label11 = new System.Windows.Forms.Label();
			this.numORMMsgNTEComment = new System.Windows.Forms.NumericUpDown();
			this.label9 = new System.Windows.Forms.Label();
			this.numORMMsgORCOrderControl = new System.Windows.Forms.NumericUpDown();
			this.label10 = new System.Windows.Forms.Label();
			this.numORMMsgPIDPatientSex = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.numORMMsgPIDPatientName = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.numORMMsgPIDPatientID = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.numORMMsgMSHControlID = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.numReceivingFacility = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.numReceivingApplication = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.numSendingFacility = new System.Windows.Forms.NumericUpDown();
			this.label2 = new System.Windows.Forms.Label();
			this.numSendingApplication = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.cbLLPCompliantACK = new System.Windows.Forms.CheckBox();
			this.groupBoxSending = new System.Windows.Forms.GroupBox();
			this.textBoxSendingFacility = new System.Windows.Forms.TextBox();
			this.labelSendingFacility = new System.Windows.Forms.Label();
			this.textBoxSendingApplication = new System.Windows.Forms.TextBox();
			this.labelSendingApp = new System.Windows.Forms.Label();
			this.groupBoxReceiving = new System.Windows.Forms.GroupBox();
			this.textBoxReceivingFacility = new System.Windows.Forms.TextBox();
			this.labelReceivingFacility = new System.Windows.Forms.Label();
			this.textBoxReceivingApplication = new System.Windows.Forms.TextBox();
			this.labelReceivingApp = new System.Windows.Forms.Label();
			this.groupBoxProcessing = new System.Windows.Forms.GroupBox();
			this.cbORMPolling = new System.Windows.Forms.ComboBox();
			this.labelORMPolling = new System.Windows.Forms.Label();
			this.cbVersionNumber = new System.Windows.Forms.ComboBox();
			this.labelHL7Version = new System.Windows.Forms.Label();
			this.numProcessingInterval = new System.Windows.Forms.NumericUpDown();
			this.labelInterval = new System.Windows.Forms.Label();
			this.buttonSaveSettings = new System.Windows.Forms.Button();
			this.buttonDefaultSettings = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.serviceController = new System.ServiceProcess.ServiceController();
			this.buttonStopService = new System.Windows.Forms.Button();
			this.buttonStartService = new System.Windows.Forms.Button();
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.LogONOFF = new System.Windows.Forms.CheckBox();
			this.groupBoxTPS.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTPSPortNumber)).BeginInit();
			this.groupBoxHIS.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numHISPortNumber)).BeginInit();
			this.groupBoxFieldLimits.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgPIDPatientAccountNumber)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgOBROrderedCategory)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgOBROrderControlNumber)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgORCDateOfService)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPV1HospitalService)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPV1VisitNumber)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgOBROrderedCategory)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgOBROrderControlNumber)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientAccountNumber)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numACKMSAControlID)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numACKMSAAckCode)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXSummaryNarrative)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXObservationValue)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXObservationId)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXTypeCode)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientSex)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientName)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientID)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgNTEComment)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgORCOrderControl)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientSex)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientName)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientID)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgMSHControlID)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numReceivingFacility)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numReceivingApplication)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numSendingFacility)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numSendingApplication)).BeginInit();
			this.groupBoxSending.SuspendLayout();
			this.groupBoxReceiving.SuspendLayout();
			this.groupBoxProcessing.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numProcessingInterval)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
			this.statusStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBoxTPS
			// 
			this.groupBoxTPS.Controls.Add(this.numTPSPortNumber);
			this.groupBoxTPS.Controls.Add(this.textBoxTPSIPAddress);
			this.groupBoxTPS.Controls.Add(this.labelPortNumber);
			this.groupBoxTPS.Controls.Add(this.labelIPAddress);
			this.groupBoxTPS.Location = new System.Drawing.Point(21, 12);
			this.groupBoxTPS.Name = "groupBoxTPS";
			this.groupBoxTPS.Size = new System.Drawing.Size(211, 91);
			this.groupBoxTPS.TabIndex = 0;
			this.groupBoxTPS.TabStop = false;
			this.groupBoxTPS.Text = "HL7 Processing Svc";
			// 
			// numTPSPortNumber
			// 
			this.numTPSPortNumber.Location = new System.Drawing.Point(97, 56);
			this.numTPSPortNumber.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
			this.numTPSPortNumber.Name = "numTPSPortNumber";
			this.numTPSPortNumber.Size = new System.Drawing.Size(52, 20);
			this.numTPSPortNumber.TabIndex = 3;
			// 
			// textBoxTPSIPAddress
			// 
			this.textBoxTPSIPAddress.Location = new System.Drawing.Point(97, 27);
			this.textBoxTPSIPAddress.Name = "textBoxTPSIPAddress";
			this.textBoxTPSIPAddress.Size = new System.Drawing.Size(90, 20);
			this.textBoxTPSIPAddress.TabIndex = 1;
			this.textBoxTPSIPAddress.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxIPAddress_Validating);
			// 
			// labelPortNumber
			// 
			this.labelPortNumber.AutoSize = true;
			this.labelPortNumber.Location = new System.Drawing.Point(21, 59);
			this.labelPortNumber.Name = "labelPortNumber";
			this.labelPortNumber.Size = new System.Drawing.Size(69, 13);
			this.labelPortNumber.TabIndex = 2;
			this.labelPortNumber.Text = "Port Number:";
			// 
			// labelIPAddress
			// 
			this.labelIPAddress.AutoSize = true;
			this.labelIPAddress.Location = new System.Drawing.Point(21, 30);
			this.labelIPAddress.Name = "labelIPAddress";
			this.labelIPAddress.Size = new System.Drawing.Size(61, 13);
			this.labelIPAddress.TabIndex = 0;
			this.labelIPAddress.Text = "IP Address:";
			// 
			// groupBoxHIS
			// 
			this.groupBoxHIS.Controls.Add(this.numHISPortNumber);
			this.groupBoxHIS.Controls.Add(this.textBoxHISIPAddress);
			this.groupBoxHIS.Controls.Add(this.labelHISPortNumber);
			this.groupBoxHIS.Controls.Add(this.labelHISIPAddress);
			this.groupBoxHIS.Location = new System.Drawing.Point(455, 15);
			this.groupBoxHIS.Name = "groupBoxHIS";
			this.groupBoxHIS.Size = new System.Drawing.Size(211, 91);
			this.groupBoxHIS.TabIndex = 1;
			this.groupBoxHIS.TabStop = false;
			this.groupBoxHIS.Text = "Hospital Information Server";
			// 
			// numHISPortNumber
			// 
			this.numHISPortNumber.Location = new System.Drawing.Point(97, 56);
			this.numHISPortNumber.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
			this.numHISPortNumber.Name = "numHISPortNumber";
			this.numHISPortNumber.Size = new System.Drawing.Size(52, 20);
			this.numHISPortNumber.TabIndex = 3;
			// 
			// textBoxHISIPAddress
			// 
			this.textBoxHISIPAddress.Location = new System.Drawing.Point(97, 27);
			this.textBoxHISIPAddress.Name = "textBoxHISIPAddress";
			this.textBoxHISIPAddress.Size = new System.Drawing.Size(90, 20);
			this.textBoxHISIPAddress.TabIndex = 1;
			this.textBoxHISIPAddress.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxIPAddress_Validating);
			// 
			// labelHISPortNumber
			// 
			this.labelHISPortNumber.AutoSize = true;
			this.labelHISPortNumber.Location = new System.Drawing.Point(21, 59);
			this.labelHISPortNumber.Name = "labelHISPortNumber";
			this.labelHISPortNumber.Size = new System.Drawing.Size(69, 13);
			this.labelHISPortNumber.TabIndex = 2;
			this.labelHISPortNumber.Text = "Port Number:";
			// 
			// labelHISIPAddress
			// 
			this.labelHISIPAddress.AutoSize = true;
			this.labelHISIPAddress.Location = new System.Drawing.Point(21, 30);
			this.labelHISIPAddress.Name = "labelHISIPAddress";
			this.labelHISIPAddress.Size = new System.Drawing.Size(61, 13);
			this.labelHISIPAddress.TabIndex = 0;
			this.labelHISIPAddress.Text = "IP Address:";
			// 
			// groupBoxFieldLimits
			// 
			this.groupBoxFieldLimits.Controls.Add(this.NumORUMsgPIDPatientAccountNumber);
			this.groupBoxFieldLimits.Controls.Add(this.label28);
			this.groupBoxFieldLimits.Controls.Add(this.NumORUMsgOBROrderedCategory);
			this.groupBoxFieldLimits.Controls.Add(this.NumORUMsgOBROrderControlNumber);
			this.groupBoxFieldLimits.Controls.Add(this.label27);
			this.groupBoxFieldLimits.Controls.Add(this.label26);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgORCDateOfService);
			this.groupBoxFieldLimits.Controls.Add(this.label25);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPV1HospitalService);
			this.groupBoxFieldLimits.Controls.Add(this.label24);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPV1VisitNumber);
			this.groupBoxFieldLimits.Controls.Add(this.label23);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgOBROrderedCategory);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgOBROrderControlNumber);
			this.groupBoxFieldLimits.Controls.Add(this.label22);
			this.groupBoxFieldLimits.Controls.Add(this.label21);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPIDPatientAccountNumber);
			this.groupBoxFieldLimits.Controls.Add(this.label20);
			this.groupBoxFieldLimits.Controls.Add(this.numACKMSAControlID);
			this.groupBoxFieldLimits.Controls.Add(this.label19);
			this.groupBoxFieldLimits.Controls.Add(this.numACKMSAAckCode);
			this.groupBoxFieldLimits.Controls.Add(this.label18);
			this.groupBoxFieldLimits.Controls.Add(this.numORUOBXSummaryNarrative);
			this.groupBoxFieldLimits.Controls.Add(this.label17);
			this.groupBoxFieldLimits.Controls.Add(this.numORUOBXObservationValue);
			this.groupBoxFieldLimits.Controls.Add(this.label14);
			this.groupBoxFieldLimits.Controls.Add(this.numORUOBXObservationId);
			this.groupBoxFieldLimits.Controls.Add(this.label15);
			this.groupBoxFieldLimits.Controls.Add(this.numORUOBXTypeCode);
			this.groupBoxFieldLimits.Controls.Add(this.label16);
			this.groupBoxFieldLimits.Controls.Add(this.numORUPIDPatientSex);
			this.groupBoxFieldLimits.Controls.Add(this.label12);
			this.groupBoxFieldLimits.Controls.Add(this.numORUPIDPatientName);
			this.groupBoxFieldLimits.Controls.Add(this.label13);
			this.groupBoxFieldLimits.Controls.Add(this.numORUPIDPatientID);
			this.groupBoxFieldLimits.Controls.Add(this.label11);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgNTEComment);
			this.groupBoxFieldLimits.Controls.Add(this.label9);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgORCOrderControl);
			this.groupBoxFieldLimits.Controls.Add(this.label10);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPIDPatientSex);
			this.groupBoxFieldLimits.Controls.Add(this.label5);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPIDPatientName);
			this.groupBoxFieldLimits.Controls.Add(this.label6);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgPIDPatientID);
			this.groupBoxFieldLimits.Controls.Add(this.label7);
			this.groupBoxFieldLimits.Controls.Add(this.numORMMsgMSHControlID);
			this.groupBoxFieldLimits.Controls.Add(this.label8);
			this.groupBoxFieldLimits.Controls.Add(this.numReceivingFacility);
			this.groupBoxFieldLimits.Controls.Add(this.label4);
			this.groupBoxFieldLimits.Controls.Add(this.numReceivingApplication);
			this.groupBoxFieldLimits.Controls.Add(this.label3);
			this.groupBoxFieldLimits.Controls.Add(this.numSendingFacility);
			this.groupBoxFieldLimits.Controls.Add(this.label2);
			this.groupBoxFieldLimits.Controls.Add(this.numSendingApplication);
			this.groupBoxFieldLimits.Controls.Add(this.label1);
			this.groupBoxFieldLimits.Location = new System.Drawing.Point(21, 229);
			this.groupBoxFieldLimits.Name = "groupBoxFieldLimits";
			this.groupBoxFieldLimits.Size = new System.Drawing.Size(651, 280);
			this.groupBoxFieldLimits.TabIndex = 7;
			this.groupBoxFieldLimits.TabStop = false;
			this.groupBoxFieldLimits.Text = "Field Limits:";
			// 
			// NumORUMsgPIDPatientAccountNumber
			// 
			this.NumORUMsgPIDPatientAccountNumber.Location = new System.Drawing.Point(592, 47);
			this.NumORUMsgPIDPatientAccountNumber.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.NumORUMsgPIDPatientAccountNumber.Name = "NumORUMsgPIDPatientAccountNumber";
			this.NumORUMsgPIDPatientAccountNumber.Size = new System.Drawing.Size(42, 20);
			this.NumORUMsgPIDPatientAccountNumber.TabIndex = 55;
			this.NumORUMsgPIDPatientAccountNumber.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(454, 47);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(134, 13);
			this.label28.TabIndex = 54;
			this.label28.Text = "ORU PID Patient Account:";
			// 
			// NumORUMsgOBROrderedCategory
			// 
			this.NumORUMsgOBROrderedCategory.Location = new System.Drawing.Point(592, 203);
			this.NumORUMsgOBROrderedCategory.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.NumORUMsgOBROrderedCategory.Name = "NumORUMsgOBROrderedCategory";
			this.NumORUMsgOBROrderedCategory.Size = new System.Drawing.Size(42, 20);
			this.NumORUMsgOBROrderedCategory.TabIndex = 53;
			this.NumORUMsgOBROrderedCategory.Value = new decimal(new int[] {
            21,
            0,
            0,
            0});
			// 
			// NumORUMsgOBROrderControlNumber
			// 
			this.NumORUMsgOBROrderControlNumber.Location = new System.Drawing.Point(592, 177);
			this.NumORUMsgOBROrderControlNumber.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.NumORUMsgOBROrderControlNumber.Name = "NumORUMsgOBROrderControlNumber";
			this.NumORUMsgOBROrderControlNumber.Size = new System.Drawing.Size(42, 20);
			this.NumORUMsgOBROrderControlNumber.TabIndex = 52;
			this.NumORUMsgOBROrderControlNumber.Value = new decimal(new int[] {
            39,
            0,
            0,
            0});
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(454, 203);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(135, 13);
			this.label27.TabIndex = 51;
			this.label27.Text = "ORU OBR Ordered Categ: ";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(454, 177);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(125, 13);
			this.label26.TabIndex = 50;
			this.label26.Text = "ORU OBR Order Control:";
			// 
			// numORMMsgORCDateOfService
			// 
			this.numORMMsgORCDateOfService.Location = new System.Drawing.Point(374, 21);
			this.numORMMsgORCDateOfService.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgORCDateOfService.Name = "numORMMsgORCDateOfService";
			this.numORMMsgORCDateOfService.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgORCDateOfService.TabIndex = 21;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(236, 21);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(138, 13);
			this.label25.TabIndex = 20;
			this.label25.Text = "ORM ORC Date of Service:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// numORMMsgPV1HospitalService
			// 
			this.numORMMsgPV1HospitalService.Location = new System.Drawing.Point(374, 151);
			this.numORMMsgPV1HospitalService.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPV1HospitalService.Name = "numORMMsgPV1HospitalService";
			this.numORMMsgPV1HospitalService.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPV1HospitalService.TabIndex = 31;
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(237, 151);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(138, 13);
			this.label24.TabIndex = 30;
			this.label24.Text = "ORM PV1 Hospital Service:";
			// 
			// numORMMsgPV1VisitNumber
			// 
			this.numORMMsgPV1VisitNumber.Location = new System.Drawing.Point(374, 125);
			this.numORMMsgPV1VisitNumber.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPV1VisitNumber.Name = "numORMMsgPV1VisitNumber";
			this.numORMMsgPV1VisitNumber.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPV1VisitNumber.TabIndex = 29;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(237, 125);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(120, 13);
			this.label23.TabIndex = 28;
			this.label23.Text = "ORM PV1 Visit Number:";
			// 
			// numORMMsgOBROrderedCategory
			// 
			this.numORMMsgOBROrderedCategory.Location = new System.Drawing.Point(374, 99);
			this.numORMMsgOBROrderedCategory.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgOBROrderedCategory.Name = "numORMMsgOBROrderedCategory";
			this.numORMMsgOBROrderedCategory.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgOBROrderedCategory.TabIndex = 27;
			// 
			// numORMMsgOBROrderControlNumber
			// 
			this.numORMMsgOBROrderControlNumber.Location = new System.Drawing.Point(374, 73);
			this.numORMMsgOBROrderControlNumber.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgOBROrderControlNumber.Name = "numORMMsgOBROrderControlNumber";
			this.numORMMsgOBROrderControlNumber.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgOBROrderControlNumber.TabIndex = 25;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(237, 99);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(133, 13);
			this.label22.TabIndex = 26;
			this.label22.Text = "ORM OBR Ordered Categ:";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(237, 73);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(126, 13);
			this.label21.TabIndex = 24;
			this.label21.Text = "ORM OBR Order Control:";
			// 
			// numORMMsgPIDPatientAccountNumber
			// 
			this.numORMMsgPIDPatientAccountNumber.Location = new System.Drawing.Point(157, 229);
			this.numORMMsgPIDPatientAccountNumber.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPIDPatientAccountNumber.Name = "numORMMsgPIDPatientAccountNumber";
			this.numORMMsgPIDPatientAccountNumber.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPIDPatientAccountNumber.TabIndex = 17;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(20, 229);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(135, 13);
			this.label20.TabIndex = 16;
			this.label20.Text = "ORM PID Patient Account:";
			// 
			// numACKMSAControlID
			// 
			this.numACKMSAControlID.Location = new System.Drawing.Point(374, 203);
			this.numACKMSAControlID.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numACKMSAControlID.Name = "numACKMSAControlID";
			this.numACKMSAControlID.Size = new System.Drawing.Size(42, 20);
			this.numACKMSAControlID.TabIndex = 35;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(237, 203);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(107, 13);
			this.label19.TabIndex = 34;
			this.label19.Text = "ACK MSA Control ID:";
			// 
			// numACKMSAAckCode
			// 
			this.numACKMSAAckCode.Location = new System.Drawing.Point(374, 177);
			this.numACKMSAAckCode.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numACKMSAAckCode.Name = "numACKMSAAckCode";
			this.numACKMSAAckCode.Size = new System.Drawing.Size(42, 20);
			this.numACKMSAAckCode.TabIndex = 33;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(237, 177);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(107, 13);
			this.label18.TabIndex = 32;
			this.label18.Text = "ACK MSA Ack Code:";
			// 
			// numORUOBXSummaryNarrative
			// 
			this.numORUOBXSummaryNarrative.Location = new System.Drawing.Point(592, 151);
			this.numORUOBXSummaryNarrative.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUOBXSummaryNarrative.Name = "numORUOBXSummaryNarrative";
			this.numORUOBXSummaryNarrative.Size = new System.Drawing.Size(42, 20);
			this.numORUOBXSummaryNarrative.TabIndex = 49;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(454, 151);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(128, 13);
			this.label17.TabIndex = 48;
			this.label17.Text = "ORU OBX Summary Narr:";
			// 
			// numORUOBXObservationValue
			// 
			this.numORUOBXObservationValue.Location = new System.Drawing.Point(592, 125);
			this.numORUOBXObservationValue.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUOBXObservationValue.Name = "numORUOBXObservationValue";
			this.numORUOBXObservationValue.Size = new System.Drawing.Size(42, 20);
			this.numORUOBXObservationValue.TabIndex = 47;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(454, 125);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(137, 13);
			this.label14.TabIndex = 46;
			this.label14.Text = "ORU OBX Observation Val:";
			// 
			// numORUOBXObservationId
			// 
			this.numORUOBXObservationId.Location = new System.Drawing.Point(592, 99);
			this.numORUOBXObservationId.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUOBXObservationId.Name = "numORUOBXObservationId";
			this.numORUOBXObservationId.Size = new System.Drawing.Size(42, 20);
			this.numORUOBXObservationId.TabIndex = 45;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(454, 99);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(131, 13);
			this.label15.TabIndex = 44;
			this.label15.Text = "ORU OBX Observation Id:";
			// 
			// numORUOBXTypeCode
			// 
			this.numORUOBXTypeCode.Location = new System.Drawing.Point(592, 73);
			this.numORUOBXTypeCode.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUOBXTypeCode.Name = "numORUOBXTypeCode";
			this.numORUOBXTypeCode.Size = new System.Drawing.Size(42, 20);
			this.numORUOBXTypeCode.TabIndex = 43;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(454, 73);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(114, 13);
			this.label16.TabIndex = 42;
			this.label16.Text = "ORU OBX Type Code:";
			// 
			// numORUPIDPatientSex
			// 
			this.numORUPIDPatientSex.Location = new System.Drawing.Point(592, 21);
			this.numORUPIDPatientSex.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUPIDPatientSex.Name = "numORUPIDPatientSex";
			this.numORUPIDPatientSex.Size = new System.Drawing.Size(42, 20);
			this.numORUPIDPatientSex.TabIndex = 41;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(454, 21);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(112, 13);
			this.label12.TabIndex = 40;
			this.label12.Text = "ORU PID Patient Sex:";
			// 
			// numORUPIDPatientName
			// 
			this.numORUPIDPatientName.Location = new System.Drawing.Point(374, 256);
			this.numORUPIDPatientName.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUPIDPatientName.Name = "numORUPIDPatientName";
			this.numORUPIDPatientName.Size = new System.Drawing.Size(42, 20);
			this.numORUPIDPatientName.TabIndex = 39;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(236, 256);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(122, 13);
			this.label13.TabIndex = 38;
			this.label13.Text = "ORU PID Patient Name:";
			// 
			// numORUPIDPatientID
			// 
			this.numORUPIDPatientID.Location = new System.Drawing.Point(374, 229);
			this.numORUPIDPatientID.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORUPIDPatientID.Name = "numORUPIDPatientID";
			this.numORUPIDPatientID.Size = new System.Drawing.Size(42, 20);
			this.numORUPIDPatientID.TabIndex = 37;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(236, 229);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(105, 13);
			this.label11.TabIndex = 36;
			this.label11.Text = "ORU PID Patient ID:";
			// 
			// numORMMsgNTEComment
			// 
			this.numORMMsgNTEComment.Location = new System.Drawing.Point(374, 47);
			this.numORMMsgNTEComment.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgNTEComment.Name = "numORMMsgNTEComment";
			this.numORMMsgNTEComment.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgNTEComment.TabIndex = 23;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(237, 47);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(107, 13);
			this.label9.TabIndex = 22;
			this.label9.Text = "ORM NTE Comment:";
			// 
			// numORMMsgORCOrderControl
			// 
			this.numORMMsgORCOrderControl.Location = new System.Drawing.Point(157, 256);
			this.numORMMsgORCOrderControl.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgORCOrderControl.Name = "numORMMsgORCOrderControl";
			this.numORMMsgORCOrderControl.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgORCOrderControl.TabIndex = 19;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(20, 256);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(126, 13);
			this.label10.TabIndex = 18;
			this.label10.Text = "ORM ORC Order Control:";
			// 
			// numORMMsgPIDPatientSex
			// 
			this.numORMMsgPIDPatientSex.Location = new System.Drawing.Point(157, 203);
			this.numORMMsgPIDPatientSex.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPIDPatientSex.Name = "numORMMsgPIDPatientSex";
			this.numORMMsgPIDPatientSex.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPIDPatientSex.TabIndex = 15;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(20, 203);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(113, 13);
			this.label5.TabIndex = 14;
			this.label5.Text = "ORM PID Patient Sex:";
			// 
			// numORMMsgPIDPatientName
			// 
			this.numORMMsgPIDPatientName.Location = new System.Drawing.Point(157, 177);
			this.numORMMsgPIDPatientName.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPIDPatientName.Name = "numORMMsgPIDPatientName";
			this.numORMMsgPIDPatientName.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPIDPatientName.TabIndex = 13;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(20, 177);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(123, 13);
			this.label6.TabIndex = 12;
			this.label6.Text = "ORM PID Patient Name:";
			// 
			// numORMMsgPIDPatientID
			// 
			this.numORMMsgPIDPatientID.Location = new System.Drawing.Point(157, 151);
			this.numORMMsgPIDPatientID.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgPIDPatientID.Name = "numORMMsgPIDPatientID";
			this.numORMMsgPIDPatientID.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgPIDPatientID.TabIndex = 11;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(20, 151);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(106, 13);
			this.label7.TabIndex = 10;
			this.label7.Text = "ORM PID Patient ID:";
			// 
			// numORMMsgMSHControlID
			// 
			this.numORMMsgMSHControlID.Location = new System.Drawing.Point(157, 125);
			this.numORMMsgMSHControlID.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numORMMsgMSHControlID.Name = "numORMMsgMSHControlID";
			this.numORMMsgMSHControlID.Size = new System.Drawing.Size(42, 20);
			this.numORMMsgMSHControlID.TabIndex = 9;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(20, 125);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(109, 13);
			this.label8.TabIndex = 8;
			this.label8.Text = "ORM MSH ControlID:";
			// 
			// numReceivingFacility
			// 
			this.numReceivingFacility.Location = new System.Drawing.Point(157, 99);
			this.numReceivingFacility.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numReceivingFacility.Name = "numReceivingFacility";
			this.numReceivingFacility.Size = new System.Drawing.Size(42, 20);
			this.numReceivingFacility.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(20, 99);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(93, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Receiving Facility:";
			// 
			// numReceivingApplication
			// 
			this.numReceivingApplication.Location = new System.Drawing.Point(157, 73);
			this.numReceivingApplication.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numReceivingApplication.Name = "numReceivingApplication";
			this.numReceivingApplication.Size = new System.Drawing.Size(42, 20);
			this.numReceivingApplication.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(20, 73);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(113, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Receiving Application:";
			// 
			// numSendingFacility
			// 
			this.numSendingFacility.Location = new System.Drawing.Point(157, 47);
			this.numSendingFacility.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numSendingFacility.Name = "numSendingFacility";
			this.numSendingFacility.Size = new System.Drawing.Size(42, 20);
			this.numSendingFacility.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(20, 47);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Sending Facility:";
			// 
			// numSendingApplication
			// 
			this.numSendingApplication.Location = new System.Drawing.Point(157, 21);
			this.numSendingApplication.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numSendingApplication.Name = "numSendingApplication";
			this.numSendingApplication.Size = new System.Drawing.Size(42, 20);
			this.numSendingApplication.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(20, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Sending Application:";
			// 
			// cbLLPCompliantACK
			// 
			this.cbLLPCompliantACK.AutoSize = true;
			this.cbLLPCompliantACK.Checked = true;
			this.cbLLPCompliantACK.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbLLPCompliantACK.Location = new System.Drawing.Point(9, 138);
			this.cbLLPCompliantACK.Name = "cbLLPCompliantACK";
			this.cbLLPCompliantACK.Size = new System.Drawing.Size(151, 17);
			this.cbLLPCompliantACK.TabIndex = 56;
			this.cbLLPCompliantACK.Text = "Add Header-Trailer to ACK";
			this.cbLLPCompliantACK.UseVisualStyleBackColor = true;
			this.cbLLPCompliantACK.CheckedChanged += new System.EventHandler(this.cbLLPCompliantACK_CheckedChanged);
			// 
			// groupBoxSending
			// 
			this.groupBoxSending.Controls.Add(this.textBoxSendingFacility);
			this.groupBoxSending.Controls.Add(this.labelSendingFacility);
			this.groupBoxSending.Controls.Add(this.textBoxSendingApplication);
			this.groupBoxSending.Controls.Add(this.labelSendingApp);
			this.groupBoxSending.Location = new System.Drawing.Point(21, 112);
			this.groupBoxSending.Name = "groupBoxSending";
			this.groupBoxSending.Size = new System.Drawing.Size(211, 111);
			this.groupBoxSending.TabIndex = 3;
			this.groupBoxSending.TabStop = false;
			this.groupBoxSending.Text = "Sending";
			// 
			// textBoxSendingFacility
			// 
			this.textBoxSendingFacility.Location = new System.Drawing.Point(88, 62);
			this.textBoxSendingFacility.Name = "textBoxSendingFacility";
			this.textBoxSendingFacility.Size = new System.Drawing.Size(99, 20);
			this.textBoxSendingFacility.TabIndex = 3;
			this.textBoxSendingFacility.Text = "SVCFAC";
			// 
			// labelSendingFacility
			// 
			this.labelSendingFacility.AutoSize = true;
			this.labelSendingFacility.Location = new System.Drawing.Point(20, 65);
			this.labelSendingFacility.Name = "labelSendingFacility";
			this.labelSendingFacility.Size = new System.Drawing.Size(42, 13);
			this.labelSendingFacility.TabIndex = 2;
			this.labelSendingFacility.Text = "Facility:";
			// 
			// textBoxSendingApplication
			// 
			this.textBoxSendingApplication.Location = new System.Drawing.Point(88, 35);
			this.textBoxSendingApplication.Name = "textBoxSendingApplication";
			this.textBoxSendingApplication.Size = new System.Drawing.Size(99, 20);
			this.textBoxSendingApplication.TabIndex = 1;
			this.textBoxSendingApplication.Text = "SVCAPP";
			// 
			// labelSendingApp
			// 
			this.labelSendingApp.AutoSize = true;
			this.labelSendingApp.Location = new System.Drawing.Point(20, 38);
			this.labelSendingApp.Name = "labelSendingApp";
			this.labelSendingApp.Size = new System.Drawing.Size(62, 13);
			this.labelSendingApp.TabIndex = 0;
			this.labelSendingApp.Text = "Application:";
			// 
			// groupBoxReceiving
			// 
			this.groupBoxReceiving.Controls.Add(this.textBoxReceivingFacility);
			this.groupBoxReceiving.Controls.Add(this.labelReceivingFacility);
			this.groupBoxReceiving.Controls.Add(this.textBoxReceivingApplication);
			this.groupBoxReceiving.Controls.Add(this.labelReceivingApp);
			this.groupBoxReceiving.Location = new System.Drawing.Point(461, 112);
			this.groupBoxReceiving.Name = "groupBoxReceiving";
			this.groupBoxReceiving.Size = new System.Drawing.Size(211, 111);
			this.groupBoxReceiving.TabIndex = 4;
			this.groupBoxReceiving.TabStop = false;
			this.groupBoxReceiving.Text = "Receiving";
			// 
			// textBoxReceivingFacility
			// 
			this.textBoxReceivingFacility.Location = new System.Drawing.Point(88, 62);
			this.textBoxReceivingFacility.Name = "textBoxReceivingFacility";
			this.textBoxReceivingFacility.Size = new System.Drawing.Size(99, 20);
			this.textBoxReceivingFacility.TabIndex = 3;
			this.textBoxReceivingFacility.Text = "HISFAC";
			// 
			// labelReceivingFacility
			// 
			this.labelReceivingFacility.AutoSize = true;
			this.labelReceivingFacility.Location = new System.Drawing.Point(20, 65);
			this.labelReceivingFacility.Name = "labelReceivingFacility";
			this.labelReceivingFacility.Size = new System.Drawing.Size(42, 13);
			this.labelReceivingFacility.TabIndex = 2;
			this.labelReceivingFacility.Text = "Facility:";
			// 
			// textBoxReceivingApplication
			// 
			this.textBoxReceivingApplication.Location = new System.Drawing.Point(88, 35);
			this.textBoxReceivingApplication.Name = "textBoxReceivingApplication";
			this.textBoxReceivingApplication.Size = new System.Drawing.Size(99, 20);
			this.textBoxReceivingApplication.TabIndex = 1;
			this.textBoxReceivingApplication.Text = "HISAPP";
			// 
			// labelReceivingApp
			// 
			this.labelReceivingApp.AutoSize = true;
			this.labelReceivingApp.Location = new System.Drawing.Point(19, 38);
			this.labelReceivingApp.Name = "labelReceivingApp";
			this.labelReceivingApp.Size = new System.Drawing.Size(62, 13);
			this.labelReceivingApp.TabIndex = 0;
			this.labelReceivingApp.Text = "Application:";
			// 
			// groupBoxProcessing
			// 
			this.groupBoxProcessing.Controls.Add(this.LogONOFF);
			this.groupBoxProcessing.Controls.Add(this.cbORMPolling);
			this.groupBoxProcessing.Controls.Add(this.labelORMPolling);
			this.groupBoxProcessing.Controls.Add(this.cbLLPCompliantACK);
			this.groupBoxProcessing.Controls.Add(this.cbVersionNumber);
			this.groupBoxProcessing.Controls.Add(this.labelHL7Version);
			this.groupBoxProcessing.Controls.Add(this.numProcessingInterval);
			this.groupBoxProcessing.Controls.Add(this.labelInterval);
			this.groupBoxProcessing.Location = new System.Drawing.Point(238, 12);
			this.groupBoxProcessing.Name = "groupBoxProcessing";
			this.groupBoxProcessing.Size = new System.Drawing.Size(211, 211);
			this.groupBoxProcessing.TabIndex = 5;
			this.groupBoxProcessing.TabStop = false;
			this.groupBoxProcessing.Text = "Processing";
			// 
			// cbORMPolling
			// 
			this.cbORMPolling.FormattingEnabled = true;
			this.cbORMPolling.Items.AddRange(new object[] {
            "20",
            "30",
            "50",
            "100",
            "200",
            "300"});
			this.cbORMPolling.Location = new System.Drawing.Point(122, 30);
			this.cbORMPolling.MaxDropDownItems = 3;
			this.cbORMPolling.Name = "cbORMPolling";
			this.cbORMPolling.Size = new System.Drawing.Size(75, 21);
			this.cbORMPolling.TabIndex = 5;
			// 
			// labelORMPolling
			// 
			this.labelORMPolling.AutoSize = true;
			this.labelORMPolling.Location = new System.Drawing.Point(6, 33);
			this.labelORMPolling.Name = "labelORMPolling";
			this.labelORMPolling.Size = new System.Drawing.Size(116, 13);
			this.labelORMPolling.TabIndex = 4;
			this.labelORMPolling.Text = "ORM polling Time (ms):";
			// 
			// cbVersionNumber
			// 
			this.cbVersionNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbVersionNumber.FormattingEnabled = true;
			this.cbVersionNumber.Items.AddRange(new object[] {
            "2.3",
            "2.4",
            "2.5"});
			this.cbVersionNumber.Location = new System.Drawing.Point(122, 83);
			this.cbVersionNumber.MaxDropDownItems = 3;
			this.cbVersionNumber.Name = "cbVersionNumber";
			this.cbVersionNumber.Size = new System.Drawing.Size(75, 21);
			this.cbVersionNumber.TabIndex = 3;
			// 
			// labelHL7Version
			// 
			this.labelHL7Version.AutoSize = true;
			this.labelHL7Version.Location = new System.Drawing.Point(8, 87);
			this.labelHL7Version.Name = "labelHL7Version";
			this.labelHL7Version.Size = new System.Drawing.Size(108, 13);
			this.labelHL7Version.TabIndex = 2;
			this.labelHL7Version.Text = "HL7 Version Number:";
			// 
			// numProcessingInterval
			// 
			this.numProcessingInterval.Location = new System.Drawing.Point(122, 57);
			this.numProcessingInterval.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.numProcessingInterval.Name = "numProcessingInterval";
			this.numProcessingInterval.Size = new System.Drawing.Size(75, 20);
			this.numProcessingInterval.TabIndex = 1;
			// 
			// labelInterval
			// 
			this.labelInterval.AutoSize = true;
			this.labelInterval.Location = new System.Drawing.Point(7, 60);
			this.labelInterval.Name = "labelInterval";
			this.labelInterval.Size = new System.Drawing.Size(103, 13);
			this.labelInterval.TabIndex = 0;
			this.labelInterval.Text = "ORU Interval (secs):";
			// 
			// buttonSaveSettings
			// 
			this.buttonSaveSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonSaveSettings.Location = new System.Drawing.Point(338, 524);
			this.buttonSaveSettings.Name = "buttonSaveSettings";
			this.buttonSaveSettings.Size = new System.Drawing.Size(98, 23);
			this.buttonSaveSettings.TabIndex = 11;
			this.buttonSaveSettings.Text = "&Save Settings";
			this.buttonSaveSettings.UseVisualStyleBackColor = true;
			this.buttonSaveSettings.Click += new System.EventHandler(this.buttonSaveSettings_Click);
			// 
			// buttonDefaultSettings
			// 
			this.buttonDefaultSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonDefaultSettings.Location = new System.Drawing.Point(232, 524);
			this.buttonDefaultSettings.Name = "buttonDefaultSettings";
			this.buttonDefaultSettings.Size = new System.Drawing.Size(98, 23);
			this.buttonDefaultSettings.TabIndex = 10;
			this.buttonDefaultSettings.Text = "&Default Settings";
			this.buttonDefaultSettings.UseVisualStyleBackColor = true;
			this.buttonDefaultSettings.Click += new System.EventHandler(this.buttonDefaultSettings_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.CausesValidation = false;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(598, 524);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(68, 23);
			this.buttonCancel.TabIndex = 12;
			this.buttonCancel.Text = "&Done";
			this.buttonCancel.UseVisualStyleBackColor = true;
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// serviceController
			// 
			this.serviceController.ServiceName = "HL7ProcessingService";
			// 
			// buttonStopService
			// 
			this.buttonStopService.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonStopService.Location = new System.Drawing.Point(22, 524);
			this.buttonStopService.Name = "buttonStopService";
			this.buttonStopService.Size = new System.Drawing.Size(98, 23);
			this.buttonStopService.TabIndex = 8;
			this.buttonStopService.Text = "St&op Service";
			this.buttonStopService.UseVisualStyleBackColor = true;
			this.buttonStopService.Click += new System.EventHandler(this.buttonStopService_Click);
			// 
			// buttonStartService
			// 
			this.buttonStartService.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonStartService.Location = new System.Drawing.Point(126, 524);
			this.buttonStartService.Name = "buttonStartService";
			this.buttonStartService.Size = new System.Drawing.Size(98, 23);
			this.buttonStartService.TabIndex = 9;
			this.buttonStartService.Text = "S&tart Service";
			this.buttonStartService.UseVisualStyleBackColor = true;
			this.buttonStartService.Click += new System.EventHandler(this.buttonStartService_Click);
			// 
			// statusStrip
			// 
			this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
			this.statusStrip.Location = new System.Drawing.Point(0, 559);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new System.Drawing.Size(684, 22);
			this.statusStrip.TabIndex = 0;
			this.statusStrip.Text = "statusStrip1";
			// 
			// toolStripStatusLabel
			// 
			this.toolStripStatusLabel.Name = "toolStripStatusLabel";
			this.toolStripStatusLabel.Size = new System.Drawing.Size(76, 17);
			this.toolStripStatusLabel.Text = "Service Status";
			// 
			// LogONOFF
			// 
			this.LogONOFF.AutoSize = true;
			this.LogONOFF.Location = new System.Drawing.Point(9, 165);
			this.LogONOFF.Name = "LogONOFF";
			this.LogONOFF.Size = new System.Drawing.Size(64, 17);
			this.LogONOFF.TabIndex = 13;
			this.LogONOFF.Text = "&Logging";
			this.LogONOFF.UseVisualStyleBackColor = true;
			// 
			// HL7ProcessingConfigForm
			// 
			this.AcceptButton = this.buttonSaveSettings;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(684, 581);
			this.Controls.Add(this.statusStrip);
			this.Controls.Add(this.buttonStartService);
			this.Controls.Add(this.buttonStopService);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonDefaultSettings);
			this.Controls.Add(this.buttonSaveSettings);
			this.Controls.Add(this.groupBoxProcessing);
			this.Controls.Add(this.groupBoxReceiving);
			this.Controls.Add(this.groupBoxSending);
			this.Controls.Add(this.groupBoxFieldLimits);
			this.Controls.Add(this.groupBoxHIS);
			this.Controls.Add(this.groupBoxTPS);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(690, 690);
			this.MinimumSize = new System.Drawing.Size(690, 590);
			this.Name = "HL7ProcessingConfigForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "HL7 Processing Svc";
			this.Load += new System.EventHandler(this.HL7ProcessingConfigForm_Load);
			this.groupBoxTPS.ResumeLayout(false);
			this.groupBoxTPS.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTPSPortNumber)).EndInit();
			this.groupBoxHIS.ResumeLayout(false);
			this.groupBoxHIS.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numHISPortNumber)).EndInit();
			this.groupBoxFieldLimits.ResumeLayout(false);
			this.groupBoxFieldLimits.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgPIDPatientAccountNumber)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgOBROrderedCategory)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumORUMsgOBROrderControlNumber)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgORCDateOfService)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPV1HospitalService)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPV1VisitNumber)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgOBROrderedCategory)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgOBROrderControlNumber)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientAccountNumber)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numACKMSAControlID)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numACKMSAAckCode)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXSummaryNarrative)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXObservationValue)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXObservationId)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUOBXTypeCode)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientSex)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientName)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORUPIDPatientID)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgNTEComment)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgORCOrderControl)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientSex)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientName)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgPIDPatientID)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numORMMsgMSHControlID)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numReceivingFacility)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numReceivingApplication)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numSendingFacility)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numSendingApplication)).EndInit();
			this.groupBoxSending.ResumeLayout(false);
			this.groupBoxSending.PerformLayout();
			this.groupBoxReceiving.ResumeLayout(false);
			this.groupBoxReceiving.PerformLayout();
			this.groupBoxProcessing.ResumeLayout(false);
			this.groupBoxProcessing.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numProcessingInterval)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupBoxTPS;
		private System.Windows.Forms.Label labelPortNumber;
		private System.Windows.Forms.Label labelIPAddress;
		private System.Windows.Forms.GroupBox groupBoxHIS;
		private System.Windows.Forms.Label labelHISPortNumber;
		private System.Windows.Forms.Label labelHISIPAddress;
		private System.Windows.Forms.GroupBox groupBoxFieldLimits;
		private System.Windows.Forms.GroupBox groupBoxSending;
		private System.Windows.Forms.TextBox textBoxSendingFacility;
		private System.Windows.Forms.Label labelSendingFacility;
		private System.Windows.Forms.TextBox textBoxSendingApplication;
		private System.Windows.Forms.Label labelSendingApp;
		private System.Windows.Forms.GroupBox groupBoxReceiving;
		private System.Windows.Forms.TextBox textBoxReceivingFacility;
		private System.Windows.Forms.Label labelReceivingFacility;
		private System.Windows.Forms.TextBox textBoxReceivingApplication;
		private System.Windows.Forms.Label labelReceivingApp;
		private System.Windows.Forms.GroupBox groupBoxProcessing;
		private System.Windows.Forms.Label labelInterval;
		private System.Windows.Forms.Button buttonSaveSettings;
		private System.Windows.Forms.Button buttonDefaultSettings;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.NumericUpDown numSendingApplication;
		private System.Windows.Forms.NumericUpDown numReceivingFacility;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.NumericUpDown numReceivingApplication;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown numSendingFacility;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.NumericUpDown numORMMsgPIDPatientSex;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown numORMMsgPIDPatientName;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.NumericUpDown numORMMsgPIDPatientID;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.NumericUpDown numORMMsgMSHControlID;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.NumericUpDown numORMMsgNTEComment;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.NumericUpDown numORMMsgORCOrderControl;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.NumericUpDown numORUOBXObservationValue;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.NumericUpDown numORUOBXObservationId;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.NumericUpDown numORUOBXTypeCode;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.NumericUpDown numORUPIDPatientSex;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.NumericUpDown numORUPIDPatientName;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.NumericUpDown numORUPIDPatientID;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.NumericUpDown numORUOBXSummaryNarrative;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.NumericUpDown numACKMSAControlID;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.NumericUpDown numACKMSAAckCode;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.TextBox textBoxTPSIPAddress;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.TextBox textBoxHISIPAddress;
		private System.Windows.Forms.NumericUpDown numProcessingInterval;
		private System.Windows.Forms.NumericUpDown numTPSPortNumber;
		private System.Windows.Forms.NumericUpDown numHISPortNumber;
		private System.Windows.Forms.Button buttonStartService;
		private System.Windows.Forms.Button buttonStopService;
		private System.ServiceProcess.ServiceController serviceController;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.NumericUpDown numORMMsgPIDPatientAccountNumber;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.NumericUpDown numORMMsgOBROrderControlNumber;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.NumericUpDown numORMMsgOBROrderedCategory;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.NumericUpDown numORMMsgPV1VisitNumber;
		private System.Windows.Forms.NumericUpDown numORMMsgPV1HospitalService;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.NumericUpDown numORMMsgORCDateOfService;
		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
		private System.Windows.Forms.CheckBox LogONOFF;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.NumericUpDown NumORUMsgOBROrderedCategory;
		private System.Windows.Forms.NumericUpDown NumORUMsgOBROrderControlNumber;
		private System.Windows.Forms.NumericUpDown NumORUMsgPIDPatientAccountNumber;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.ComboBox cbVersionNumber;
		private System.Windows.Forms.Label labelHL7Version;
		private System.Windows.Forms.CheckBox cbLLPCompliantACK;
		private System.Windows.Forms.Label labelORMPolling;
		private System.Windows.Forms.ComboBox cbORMPolling;
	}
}

