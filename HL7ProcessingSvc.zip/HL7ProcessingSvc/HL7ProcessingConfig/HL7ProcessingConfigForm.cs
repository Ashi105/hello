using System;
using System.ComponentModel;
using System.ServiceProcess;
using System.Text.RegularExpressions;
using System.Windows.Forms;

using HL7ProcessingSettings;

namespace HL7ProcessingConfig
{
	public partial class HL7ProcessingConfigForm : Form
	{
		public static SvcSettingsMgr sSvcSettingsMgr;
		private static TimeSpan fiveSeconds = new TimeSpan(0, 0, 5);

		public HL7ProcessingConfigForm()
		{
			InitializeComponent();
			
			try
			{
				sSvcSettingsMgr = new SvcSettingsMgr();
			}
			catch (System.Exception ex)
			{
				MessageBox.Show(string.Format("Failed to load service settings:  Error = {0}", ex.Message));
			}
		}

		private void LoadConfigForm()
		{
			try
			{
				SvcSettingsMgr.HL7ProcessingNetwork tpNetwork = sSvcSettingsMgr.SvcSettings.HL7ProcessingNetwork;
				textBoxTPSIPAddress.Text = tpNetwork.TPSIPAddress;
				numTPSPortNumber.Value = decimal.Parse(tpNetwork.TPSPortNumber.ToString());
				textBoxHISIPAddress.Text = tpNetwork.HISIPAddress;
				numHISPortNumber.Value = decimal.Parse(tpNetwork.HISPortNumber.ToString());

				//SvcSettingsMgr.HL7ProcessingUser tpUser = sSvcSettingsMgr.SvcSettings.HL7ProcessingUser;
				//textBoxUsername.Text = tpUser.UserName;
				//textBoxPassword.Text = tpUser.Password;

				SvcSettingsMgr.HL7ProcessingSettings tpSettings = sSvcSettingsMgr.SvcSettings.HL7ProcessingSettings;
				textBoxSendingApplication.Text = tpSettings.SendingApplication;
				textBoxSendingFacility.Text = tpSettings.SendingFacility;
				textBoxReceivingApplication.Text = tpSettings.ReceivingApplication;
				textBoxReceivingFacility.Text = tpSettings.ReceivingFacility;
				numProcessingInterval.Value = decimal.Parse(tpSettings.ReportProcessingIntervalSecs.ToString());
				cbVersionNumber.Text = tpSettings.HL7VersionNumber.ToString();
				cbORMPolling.Text = tpSettings.ORMPollingTime.ToString();
				LogONOFF.Checked = tpSettings.HL7ProcessingLogON;
				if (tpSettings.ACKSaveSettings == true)
				{
					cbLLPCompliantACK.Checked = tpSettings.LLPCompliantACK;
				}
				else
				{
					cbLLPCompliantACK.Checked = true;
				}
				numSendingApplication.Value = decimal.Parse(tpSettings.LimitSendingApplication.ToString());
				numSendingFacility.Value = decimal.Parse(tpSettings.LimitSendingFacility.ToString());
				numReceivingApplication.Value = decimal.Parse(tpSettings.LimitReceivingApplication.ToString());
				numReceivingFacility.Value = decimal.Parse(tpSettings.LimitReceivingFacility.ToString());
				
				numACKMSAAckCode.Value = decimal.Parse(tpSettings.LimitACKMsgMSAAcknowledgementCode.ToString());
				numACKMSAControlID.Value = decimal.Parse(tpSettings.LimitACKMsgMSAControlID.ToString());
				numORMMsgMSHControlID.Value = decimal.Parse(tpSettings.LimitORMMsgMSHControlID.ToString());
				numORMMsgPIDPatientID.Value = decimal.Parse(tpSettings.LimitORMMsgPIDPatientID.ToString());
				numORMMsgPIDPatientName.Value = decimal.Parse(tpSettings.LimitORMMsgPIDPatientName.ToString());
				numORMMsgPIDPatientSex.Value = decimal.Parse(tpSettings.LimitORMMsgPIDPatientSex.ToString());
				numORMMsgORCOrderControl.Value = decimal.Parse(tpSettings.LimitORMMsgORCOrderControl.ToString());
				numORMMsgNTEComment.Value = decimal.Parse(tpSettings.LimitORMMsgNTEComment.ToString());

				numORMMsgPIDPatientAccountNumber.Value = decimal.Parse(tpSettings.LimitORMMsgPIDPatientAccountNumber.ToString());
				numORMMsgOBROrderControlNumber.Value = decimal.Parse(tpSettings.LimitORMMsgOBROrderControlNumber.ToString());
				numORMMsgOBROrderedCategory.Value = decimal.Parse(tpSettings.LimitORMMsgOBROrderedCategory.ToString());
				numORMMsgPV1VisitNumber.Value = decimal.Parse(tpSettings.LimitORMMsgPV1PatientVisitNumber.ToString());
				numORMMsgPV1HospitalService.Value = decimal.Parse(tpSettings.LimitORMMsgPV1HospitalService.ToString());
				numORMMsgORCDateOfService.Value = decimal.Parse(tpSettings.LimitORMMsgORCDateOfService.ToString());

				numORUPIDPatientID.Value = decimal.Parse(tpSettings.LimitORUMsgPIDPatientID.ToString());
				numORUPIDPatientName.Value = decimal.Parse(tpSettings.LimitORUMsgPIDPatientName.ToString());
				numORUPIDPatientSex.Value = decimal.Parse(tpSettings.LimitORUMsgPIDPatientSex.ToString());
				numORUOBXTypeCode.Value = decimal.Parse(tpSettings.LimitORUMsgOBXTypeCode.ToString());
				numORUOBXObservationId.Value = decimal.Parse(tpSettings.LimitORUMsgOBXObservationIdentifier.ToString());
				numORUOBXObservationValue.Value = decimal.Parse(tpSettings.LimitORUMsgOBXObservationValue.ToString());
				numORUOBXSummaryNarrative.Value = decimal.Parse(tpSettings.LimitORUMsgOBXSummaryNarrative.ToString());
				NumORUMsgOBROrderControlNumber.Value = decimal.Parse(tpSettings.LimitORUMsgOBROrderControlNumber.ToString());
				NumORUMsgOBROrderedCategory.Value = decimal.Parse(tpSettings.LimitORUMsgOBROrderedCategory.ToString());
				NumORUMsgPIDPatientAccountNumber.Value = decimal.Parse(tpSettings.LimitORUMsgPIDPatientAccountNumber.ToString());
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Format("Failed to load service settings:  Error = {0}", ex.Message));
			}
		}

		private void SaveConfigForm()
		{
			try
			{
				SvcSettingsMgr.HL7ProcessingNetwork tpNetwork = sSvcSettingsMgr.SvcSettings.HL7ProcessingNetwork;
				tpNetwork.TPSIPAddress = textBoxTPSIPAddress.Text;
				tpNetwork.TPSPortNumber = int.Parse(numTPSPortNumber.Text);
				tpNetwork.HISIPAddress = textBoxHISIPAddress.Text;
				tpNetwork.HISPortNumber = int.Parse(numHISPortNumber.Text);

				//SvcSettingsMgr.HL7ProcessingUser tpUser = sSvcSettingsMgr.SvcSettings.HL7ProcessingUser;
				//tpUser.UserName = textBoxUsername.Text;
				//tpUser.Password = textBoxPassword.Text;

				SvcSettingsMgr.HL7ProcessingSettings tpSettings = sSvcSettingsMgr.SvcSettings.HL7ProcessingSettings;
				tpSettings.SendingApplication = textBoxSendingApplication.Text;
				tpSettings.SendingFacility = textBoxSendingFacility.Text;
				tpSettings.ReceivingApplication = textBoxReceivingApplication.Text;
				tpSettings.ReceivingFacility = textBoxReceivingFacility.Text;
				tpSettings.HL7ProcessingLogON = LogONOFF.Checked;
				tpSettings.LLPCompliantACK = cbLLPCompliantACK.Checked;
				tpSettings.ReportProcessingIntervalSecs = int.Parse(numProcessingInterval.Text);
				tpSettings.HL7VersionNumber = double.Parse(cbVersionNumber.Text);
				tpSettings.ORMPollingTime = int.Parse(cbORMPolling.Text);

				tpSettings.LimitSendingApplication = int.Parse(numSendingApplication.Text);
				tpSettings.LimitSendingFacility = int.Parse(numSendingFacility.Text);
				tpSettings.LimitReceivingApplication = int.Parse(numReceivingApplication.Text);
				tpSettings.LimitReceivingFacility = int.Parse(numReceivingFacility.Text);

				tpSettings.LimitACKMsgMSAAcknowledgementCode = int.Parse(numACKMSAAckCode.Text);
				tpSettings.LimitACKMsgMSAControlID = int.Parse(numACKMSAControlID.Text);
				tpSettings.LimitORMMsgMSHControlID = int.Parse(numORMMsgMSHControlID.Text);
				tpSettings.LimitORMMsgPIDPatientID = int.Parse(numORMMsgPIDPatientID.Text);
				tpSettings.LimitORMMsgPIDPatientName = int.Parse(numORMMsgPIDPatientName.Text);
				tpSettings.LimitORMMsgPIDPatientSex = int.Parse(numORMMsgPIDPatientSex.Text);
				tpSettings.LimitORMMsgORCOrderControl = int.Parse(numORMMsgORCOrderControl.Text);
				tpSettings.LimitORMMsgNTEComment = int.Parse(numORMMsgNTEComment.Text);

				tpSettings.LimitORMMsgPIDPatientAccountNumber = int.Parse(numORMMsgPIDPatientAccountNumber.Text);
				tpSettings.LimitORMMsgOBROrderControlNumber = int.Parse(numORMMsgOBROrderControlNumber.Text);
				tpSettings.LimitORMMsgOBROrderedCategory = int.Parse(numORMMsgOBROrderedCategory.Text);
				tpSettings.LimitORMMsgPV1PatientVisitNumber = int.Parse(numORMMsgPV1VisitNumber.Text);
				tpSettings.LimitORMMsgPV1HospitalService = int.Parse(numORMMsgPV1HospitalService.Text);
				tpSettings.LimitORMMsgORCDateOfService = int.Parse(numORMMsgORCDateOfService.Text);

				tpSettings.LimitORUMsgPIDPatientID = int.Parse(numORUPIDPatientID.Text);
				tpSettings.LimitORUMsgPIDPatientName = int.Parse(numORUPIDPatientName.Text);
				tpSettings.LimitORUMsgPIDPatientSex = int.Parse(numORUPIDPatientSex.Text);
				tpSettings.LimitORUMsgOBXTypeCode = int.Parse(numORUOBXTypeCode.Text);
				tpSettings.LimitORUMsgOBXObservationIdentifier = int.Parse(numORUOBXObservationId.Text);
				tpSettings.LimitORUMsgOBXObservationValue = int.Parse(numORUOBXObservationValue.Text);
				tpSettings.LimitORUMsgOBXSummaryNarrative = int.Parse(numORUOBXSummaryNarrative.Text);
				tpSettings.LimitORUMsgOBROrderControlNumber = int.Parse(NumORUMsgOBROrderControlNumber.Text);
				tpSettings.LimitORUMsgOBROrderedCategory = int.Parse(NumORUMsgOBROrderedCategory.Text);
				tpSettings.LimitORUMsgPIDPatientAccountNumber = int.Parse(NumORUMsgPIDPatientAccountNumber.Text);
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Format("Failed to save service settings:  Error = {0}", ex.Message));
			}

		}

		private void buttonCancel_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void buttonSaveSettings_Click(object sender, EventArgs e)
		{
			try
			{
				if (sSvcSettingsMgr != null)
				{
					SaveConfigForm();
					sSvcSettingsMgr.SaveSvcSettings();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to save service settings" + ex.Message);
			}

			UpdateStatusButtons();
		}

		private void buttonDefaultSettings_Click(object sender, EventArgs e)
		{
			// Create a new settings object with default values and load them into the form
			try
			{
				if (sSvcSettingsMgr != null)
				{
					sSvcSettingsMgr.SvcSettings = new SvcSettingsMgr.ServiceSettings();
					SvcSettingsMgr.HL7ProcessingSettings tpSettings = sSvcSettingsMgr.SvcSettings.HL7ProcessingSettings;
					tpSettings.ACKSaveSettings = false;
					LoadConfigForm();
				}
			}
			catch (System.Exception ex)
			{
				MessageBox.Show(string.Format("Failed to create default service settings:  Error = {0}", ex.Message));
			}
			UpdateStatusButtons();
		}

		private void HL7ProcessingConfigForm_Load(object sender, EventArgs e)
		{
			// Load settings from file and then load them into the form
			try
			{
				if (sSvcSettingsMgr != null)
				{
					sSvcSettingsMgr.LoadSvcSettings();
					LoadConfigForm();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to load service settings:  Error = " + ex.Message);
			}
			UpdateStatusButtons();
		}

		private void textBoxIPAddress_Validating(object sender, CancelEventArgs e)
		{
			// Validate the IP Address to be of the form xxx.xxx.xxx.xxx where xxx is from 0 to 255
			String ipAddrStr = ((TextBox)sender).Text;
			Regex regex = new Regex(@"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b");

			if (!regex.IsMatch(ipAddrStr))
			{
				e.Cancel = true;
				errorProvider.SetError((Control)sender, "Invalid IP Address: should be in the form '255.255.255.255'");
			}
			else
			{
				errorProvider.Clear();
			}
		}

		private void buttonStopService_Click(object sender, EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				// If we're in the running or paused state
				if (serviceController.Status == ServiceControllerStatus.Running  ||  
					serviceController.Status == ServiceControllerStatus.Paused)
				{
					// Stop the service and wait for the status to change to stopped (timeout after 5 secs)
					serviceController.Stop();
					serviceController.WaitForStatus(ServiceControllerStatus.Stopped, fiveSeconds);
				}
			}
			catch (System.Exception)
			{
			}
			finally
			{
				UpdateStatusButtons();
				Cursor.Current = Cursors.Default;
			}			
		}

		private void buttonStartService_Click(object sender, EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			if (serviceController.Status == ServiceControllerStatus.Running  ||  
				serviceController.Status == ServiceControllerStatus.Paused)
			{
				try
				{
					// We're already running and the "restart" button was clicked, so stop first.
					serviceController.Stop();
					serviceController.WaitForStatus(ServiceControllerStatus.Stopped, fiveSeconds);
				}
				catch (System.Exception)
				{
				}
			}

			try
			{
				// Now start the service and wait for the status to change to running (timeout after 5 secs)
				serviceController.Start();
				serviceController.WaitForStatus(ServiceControllerStatus.Running, fiveSeconds);
			}
			catch (System.Exception)
			{
			}
			finally
			{
				UpdateStatusButtons();
				Cursor.Current = Cursors.Default;
			}
		}

		private void UpdateStatusButtons()
		{
			bool foundTPService = false;
			try
			{
				// Get the list of services on this machine and check for "HL7ProcessingService";
				ServiceController[] serviceControllerList = ServiceController.GetServices();
				foreach (ServiceController service in serviceControllerList)
				{
					if (service.ServiceName == serviceController.ServiceName)
					{
						foundTPService = true;
						break;
					}
				}
			}
			catch (Exception)
			{
			}

			if (!foundTPService)
			{
				// If we failed to find the service then disable the Stop/Start control buttons and show error status
				buttonStartService.Enabled = false;
				buttonStopService.Enabled = false;
				toolStripStatusLabel.Text = "Failed to find HL7 Processing Service on this machine.";
				return;
			}

			// If we're in the stopped state
			if ((serviceController.Status == ServiceControllerStatus.Stopped)  ||  
				(serviceController.Status == ServiceControllerStatus.StopPending))
			{
				buttonStartService.Text = "S&tart Service";
				buttonStartService.Enabled = true;
				buttonStopService.Enabled = false;
				toolStripStatusLabel.Text = "HL7 Processing Service is stopped.";
			}
			// If we're in the running state
			else if ((serviceController.Status == ServiceControllerStatus.StartPending)  ||  
					(serviceController.Status == ServiceControllerStatus.Running))
			{
				buttonStartService.Text = "Res&tart Service";
				buttonStartService.Enabled = true;
				buttonStopService.Enabled = true;
				toolStripStatusLabel.Text = "HL7 Processing Service is running.";
			}
			// Otherwise, we're paused or pending
			else if ((serviceController.Status == ServiceControllerStatus.Paused) ||
					(serviceController.Status == ServiceControllerStatus.PausePending) ||
					(serviceController.Status == ServiceControllerStatus.ContinuePending))
			{
				toolStripStatusLabel.Text = "HL7 Processing Service is paused.";
			}
		}

		private void cbLLPCompliantACK_CheckedChanged(object sender, EventArgs e)
		{
			SvcSettingsMgr.HL7ProcessingSettings tpSettings = sSvcSettingsMgr.SvcSettings.HL7ProcessingSettings;
			tpSettings.ACKSaveSettings = true;
		}
	}
}
