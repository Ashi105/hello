using System;
using System.Collections.Specialized;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Windows.Forms;

namespace HL7ProcessingSettings
{
	public class SvcSettingsMgr
	{
		private string m_SvcPrefFileName;
		private ServiceSettings m_SvcSettings;

		public SvcSettingsMgr()
		{
			string exePath = Path.GetDirectoryName(Application.ExecutablePath);
			m_SvcPrefFileName = Path.Combine(exePath, Application.ProductName + ".config");

			// Create the service settings object
			bool settingsFileExists = LoadSvcSettings();
			if (settingsFileExists == false)
			{
				// service settings don't exist so create default settings. 
				m_SvcSettings = new ServiceSettings();
				SaveSvcSettings();
			}
		}

		public ServiceSettings SvcSettings
		{
			get { return m_SvcSettings; }
			set { m_SvcSettings = value; }
		}

		public bool SaveSvcSettings()
		{
			// Serialize the ServiceSettings object to the config file
			StreamWriter streamWriter = null;
			XmlSerializer xmlSerializer = null;
			try
			{
				// Create an XmlSerializer for the ServiceSettings type.
				xmlSerializer = new XmlSerializer(typeof(ServiceSettings));
				streamWriter = new StreamWriter(m_SvcPrefFileName, false);
				// Serialize the ServiceSettings object to the config file.
				xmlSerializer.Serialize(streamWriter, m_SvcSettings);
			}
			//catch (Exception ex)
			//{
			// Let caller handle exception (service will log error, config program will display error dialog)
			//}
			finally
			{
				if (streamWriter != null)
					streamWriter.Close();
			}

			return true;
		}

		public bool LoadSvcSettings()
		{
			// Deserialize the ServiceSettings object from the config file
			XmlSerializer xmlSerializer = null;
			FileStream fileStream = null;
			bool fileExists = false;

			try
			{
				// Create an XmlSerializer for the ServiceSettings type.
				xmlSerializer = new XmlSerializer(typeof(ServiceSettings));
				FileInfo fileInfo = new FileInfo(m_SvcPrefFileName);
				// If the config file exists, open it.
				if (fileInfo.Exists)
				{
					fileStream = fileInfo.OpenRead();
					// Create a new instance of the ServiceSettings by deserializing the config file.
					m_SvcSettings = (ServiceSettings)xmlSerializer.Deserialize(fileStream);
					fileExists = true;
				}
			}
			//catch (Exception ex)
			//{
			// Let caller handle exception (service will log error, config program will display error dialog)
			//}
			finally
			{
				// If the FileStream is open, close it.
				if (fileStream != null)
				{
					fileStream.Close();
				}
			}

			return fileExists;
		}


		/// <summary>
		/// The ServiceSettings object is a container class for all service preferences
		/// which use XML serialization to read/write their data to the HL7ProcessingSvc.config file.  
		/// </summary>
		[Serializable]
		public class ServiceSettings
		{
			// Objects used to store the service settings.
			public HL7ProcessingSettings HL7ProcessingSettings;
			public HL7ProcessingNetwork HL7ProcessingNetwork;
			public HL7ProcessingUser HL7ProcessingUser;
			public FieldNameCollection HL7SvcToHL7FieldMapper;

			// default constructor to initialize settings
			public ServiceSettings()
			{
				// Create default objects which will initialize themselves
				HL7ProcessingSettings = new HL7ProcessingSettings();
				HL7ProcessingNetwork = new HL7ProcessingNetwork();
				HL7ProcessingUser = new HL7ProcessingUser();
				HL7SvcToHL7FieldMapper = new FieldNameCollection();
			}
		}

		[Serializable]
		public class HL7ProcessingSettings
		{
			private string m_SendingApplication;
			private string m_SendingFacility;
			private string m_ReceivingApplication;
			private string m_ReceivingFacility;
			private bool	m_bLogON;
			private bool m_bLLPCompliantACK;
			private bool m_bACKSaveSettings;

			private int m_ReportProcessingIntervalSecs;
			private int m_nORMPollingTime;
			private double m_fHL7VersionNum;
			private int m_LimitSendingApplication;
			private int m_LimitSendingFacility;
			private int m_LimitReceivingApplication;
			private int m_LimitReceivingFacility;
			private int m_LimitORMMsgMSHControlID;
			private int m_LimitORMMsgMSHDateTime;
			private int m_LimitORMMsgPIDPatientID;
			private int m_LimitORMMsgPIDPatientName;
			private int m_LimitORMMsgPIDPatientDOB;
			private int m_LimitORMMsgPIDPatientSex;
			private int m_LimitORMMsgORCOrderControl;
			private int m_LimitORMMsgOBRRequestedDateTime;
			private int m_LimitORMMsgNTEComment;
			private int m_LimitORMMsgPIDPatientAccountNumber;
			private int m_LimitORMMsgOBROrderControlNumber;
			private int m_LimitORMMsgOBROrderedCategory;
			private int m_LimitORMMsgPV1PatientVisitNumber;
			private int m_LimitORMMsgPV1HospitalService;
			private int m_nLimitORMMsgPV1AssignedPatientLocation;
			private int m_nLimitORMMsgOBRPhysicianName;
			private int m_nLimitORMMsgPV1ReferPhysicianName;
			private int m_LimitORMMsgORCDateOfService;
			private int m_LimitACKMsgMSHDateTime;
			private int m_LimitACKMsgMSAAcknowledgementCode;
			private int m_LimitACKMsgMSAControlID;
			private int m_LimitORUMsgMSHDateTime;
			private int m_LimitORUMsgPIDPatientID;
			private int m_LimitORUMsgPIDPatientName;
			private int m_LimitORUMsgPIDPatientDOB;
			private int m_LimitORUMsgPIDPatientSex;
			private int m_LimitORUMsgOBRRequestedDateTime;
			private int m_LimitORUMsgOBXTypeCode;
			private int m_LimitORUMsgOBXObservationIdentifier;
			private int m_LimitORUMsgOBXObservationValue;
			private int m_LimitORUMsgOBXSummaryNarrative;
			private int m_nLimitORUMsgPIDPatientAccountNumber;
			private int m_nLimitORUMsgOBROrderControlNumber;
			private int m_nLimitORUMsgOBROrderedCategory;
			private int m_nLimitORUMsgOBRPhysicianName;

			public HL7ProcessingSettings()
			{
				m_SendingApplication = "SVCAPP";
				m_SendingFacility = "SVCFAC";
				m_ReceivingApplication = "HISAPP";
				m_ReceivingFacility = "HISFAC";
				m_bLogON = false;
				m_bLLPCompliantACK = true;

				m_ReportProcessingIntervalSecs = 5; // Process reports every X seconds
				m_nORMPollingTime = 30;	// ORM Polling Time = 30ms
				m_fHL7VersionNum = 2.5;
				m_LimitSendingApplication = 30;
				m_LimitSendingFacility = 30;
				m_LimitReceivingApplication = 30;
				m_LimitReceivingFacility = 30;
				m_LimitORMMsgMSHControlID = 20;
				m_LimitORMMsgMSHDateTime = 14; // UNUSED
				m_LimitORMMsgPIDPatientID = 32;
				m_LimitORMMsgPIDPatientName = 64;
				m_LimitORMMsgPIDPatientDOB = 12;//8? UNUSED YYYYMMDD
				m_LimitORMMsgPIDPatientSex = 1;
				m_LimitORMMsgORCOrderControl = 2;
				m_LimitORMMsgOBRRequestedDateTime = 14; // UNUSED YYYYMMDDHHMMSS
				m_LimitORMMsgNTEComment = 80;
				m_LimitORMMsgPIDPatientAccountNumber = 12;
				m_LimitORMMsgOBROrderControlNumber = 39;
				m_LimitORMMsgOBROrderedCategory = 21;
				m_LimitORMMsgPV1PatientVisitNumber = 20;
				m_nLimitORMMsgPV1AssignedPatientLocation = 64;
				m_nLimitORMMsgOBRPhysicianName = 64;
				m_nLimitORMMsgPV1ReferPhysicianName = 64;
				m_LimitORMMsgPV1HospitalService = 3;
				m_LimitORMMsgORCDateOfService = 14;
				m_LimitACKMsgMSHDateTime = 14; // UNUSED YYYYMMDDHHMMSS
				m_LimitACKMsgMSAAcknowledgementCode = 2;
				m_LimitACKMsgMSAControlID = 20;
				m_LimitORUMsgMSHDateTime = 14; // UNUSED YYYYMMDDHHMMSS
				m_LimitORUMsgPIDPatientID = 32;
				m_LimitORUMsgPIDPatientName = 64;
				m_LimitORUMsgPIDPatientDOB = 12;//8? UNUSED YYYYMMDD
				m_LimitORUMsgPIDPatientSex = 1;
				m_LimitORUMsgOBRRequestedDateTime = 14; // UNUSED YYYYMMDDHHMMSS
				m_LimitORUMsgOBXTypeCode = 2;
				m_LimitORUMsgOBXObservationIdentifier = 16;
				m_LimitORUMsgOBXObservationValue = 256;
				m_LimitORUMsgOBXSummaryNarrative = 80;
				m_nLimitORUMsgPIDPatientAccountNumber = 12;
				m_nLimitORUMsgOBROrderControlNumber = 39;
				m_nLimitORUMsgOBROrderedCategory = 21;
				m_nLimitORUMsgOBRPhysicianName = 64;
			}

			public String SendingApplication
			{
				get { return m_SendingApplication; }
				set { m_SendingApplication = value; }
			}

			public String SendingFacility
			{
				get { return m_SendingFacility; }
				set { m_SendingFacility = value; }
			}

			public String ReceivingApplication
			{
				get { return m_ReceivingApplication; }
				set { m_ReceivingApplication = value; }
			}

			public String ReceivingFacility
			{
				get { return m_ReceivingFacility; }
				set { m_ReceivingFacility = value; }
			}

			public int ReportProcessingIntervalSecs
			{
				get { return m_ReportProcessingIntervalSecs; }
				set { m_ReportProcessingIntervalSecs = value; }
			}

			public int ORMPollingTime
			{
				get { return m_nORMPollingTime; }
				set { m_nORMPollingTime = value; }
			}

			public int LimitSendingApplication
			{
				get { return m_LimitSendingApplication; }
				set { m_LimitSendingApplication = value; }
			}

			public int LimitSendingFacility
			{
				get { return m_LimitSendingFacility; }
				set { m_LimitSendingFacility = value; }
			}

			public int LimitReceivingApplication
			{
				get { return m_LimitReceivingApplication; }
				set { m_LimitReceivingApplication = value; }
			}

			public int LimitReceivingFacility
			{
				get { return m_LimitReceivingFacility; }
				set { m_LimitReceivingFacility = value; }
			}

			public int LimitORMMsgMSHControlID
			{
				get { return m_LimitORMMsgMSHControlID; }
				set { m_LimitORMMsgMSHControlID = value; }
			}

			public int LimitORMMsgMSHDateTime
			{
				get { return m_LimitORMMsgMSHDateTime; }
				set { m_LimitORMMsgMSHDateTime = value; }
			}

			public int LimitORMMsgPIDPatientID
			{
				get { return m_LimitORMMsgPIDPatientID; }
				set { m_LimitORMMsgPIDPatientID = value; }
			}

			public int LimitORMMsgPIDPatientName
			{
				get { return m_LimitORMMsgPIDPatientName; }
				set { m_LimitORMMsgPIDPatientName = value; }
			}

			public int LimitORMMsgPIDPatientDOB
			{
				get { return m_LimitORMMsgPIDPatientDOB; }
				set { m_LimitORMMsgPIDPatientDOB = value; }
			}

			public int LimitORMMsgPIDPatientSex
			{
				get { return m_LimitORMMsgPIDPatientSex; }
				set { m_LimitORMMsgPIDPatientSex = value; }
			}

			public int LimitORMMsgORCOrderControl
			{
				get { return m_LimitORMMsgORCOrderControl; }
				set { m_LimitORMMsgORCOrderControl = value; }
			}

			public int LimitORMMsgOBRRequestedDateTime
			{
				get { return m_LimitORMMsgOBRRequestedDateTime; }
				set { m_LimitORMMsgOBRRequestedDateTime = value; }
			}

			public int LimitORMMsgNTEComment
			{
				get { return m_LimitORMMsgNTEComment; }
				set { m_LimitORMMsgNTEComment = value; }
			}

			public int LimitORMMsgPIDPatientAccountNumber
			{
				get { return m_LimitORMMsgPIDPatientAccountNumber; }
				set { m_LimitORMMsgPIDPatientAccountNumber = value; }
			}

			public int LimitORMMsgOBROrderControlNumber
			{
				get { return m_LimitORMMsgOBROrderControlNumber; }
				set { m_LimitORMMsgOBROrderControlNumber = value; }
			}

			public int LimitORMMsgOBROrderedCategory
			{
				get { return m_LimitORMMsgOBROrderedCategory; }
				set { m_LimitORMMsgOBROrderedCategory = value; }
			}

			public int LimitORMMsgPV1PatientVisitNumber
			{
				get { return m_LimitORMMsgPV1PatientVisitNumber; }
				set { m_LimitORMMsgPV1PatientVisitNumber = value; }
			}

			public int LimitORMMsgPV1HospitalService
			{
				get { return m_LimitORMMsgPV1HospitalService; }
				set { m_LimitORMMsgPV1HospitalService = value; }
			}

			public int LimitORMMsgORCDateOfService
			{
				get { return m_LimitORMMsgORCDateOfService; }
				set { m_LimitORMMsgORCDateOfService = value; }
			}

			public int LimitACKMsgMSHDateTime
			{
				get { return m_LimitACKMsgMSHDateTime; }
				set { m_LimitACKMsgMSHDateTime = value; }
			}

			public int LimitACKMsgMSAAcknowledgementCode
			{
				get { return m_LimitACKMsgMSAAcknowledgementCode; }
				set { m_LimitACKMsgMSAAcknowledgementCode = value; }
			}

			public int LimitACKMsgMSAControlID
			{
				get { return m_LimitACKMsgMSAControlID; }
				set { m_LimitACKMsgMSAControlID = value; }
			}

			public int LimitORUMsgMSHDateTime
			{
				get { return m_LimitORUMsgMSHDateTime; }
				set { m_LimitORUMsgMSHDateTime = value; }
			}

			public int LimitORUMsgPIDPatientID
			{
				get { return m_LimitORUMsgPIDPatientID; }
				set { m_LimitORUMsgPIDPatientID = value; }
			}

			public int LimitORUMsgPIDPatientName
			{
				get { return m_LimitORUMsgPIDPatientName; }
				set { m_LimitORUMsgPIDPatientName = value; }
			}

			public int LimitORUMsgPIDPatientDOB
			{
				get { return m_LimitORUMsgPIDPatientDOB; }
				set { m_LimitORUMsgPIDPatientDOB = value; }
			}

			public int LimitORUMsgPIDPatientSex
			{
				get { return m_LimitORUMsgPIDPatientSex; }
				set { m_LimitORUMsgPIDPatientSex = value; }
			}

			public int LimitORUMsgOBRRequestedDateTime
			{
				get { return m_LimitORUMsgOBRRequestedDateTime; }
				set { m_LimitORUMsgOBRRequestedDateTime = value; }
			}

			public int LimitORUMsgOBXTypeCode
			{
				get { return m_LimitORUMsgOBXTypeCode; }
				set { m_LimitORUMsgOBXTypeCode = value; }
			}

			public int LimitORUMsgOBXObservationIdentifier
			{
				get { return m_LimitORUMsgOBXObservationIdentifier; }
				set { m_LimitORUMsgOBXObservationIdentifier = value; }
			}

			public int LimitORUMsgOBXObservationValue
			{
				get { return m_LimitORUMsgOBXObservationValue; }
				set { m_LimitORUMsgOBXObservationValue = value; }
			}

			public int LimitORUMsgOBXSummaryNarrative
			{
				get { return m_LimitORUMsgOBXSummaryNarrative; }
				set { m_LimitORUMsgOBXSummaryNarrative = value; }
			}

			public int LimitORUMsgPIDPatientAccountNumber
			{
				get { return m_nLimitORUMsgPIDPatientAccountNumber; }
				set { m_nLimitORUMsgPIDPatientAccountNumber = value; }
			}

			public int LimitORUMsgOBROrderControlNumber
			{
				get { return m_nLimitORUMsgOBROrderControlNumber; }
				set { m_nLimitORUMsgOBROrderControlNumber = value; }
			}

			public int LimitORUMsgOBROrderedCategory
			{
				get { return m_nLimitORUMsgOBROrderedCategory; }
				set { m_nLimitORUMsgOBROrderedCategory = value; }
			}

			public bool HL7ProcessingLogON
			{
				get { return m_bLogON; }
				set { m_bLogON = value; }
			}

			public bool LLPCompliantACK
			{
				get { return m_bLLPCompliantACK; }
				set { m_bLLPCompliantACK = value; }
			}

			public bool ACKSaveSettings
			{
				get { return m_bACKSaveSettings; }
				set { m_bACKSaveSettings = value; }
			}


			public double HL7VersionNumber
			{
				get { return m_fHL7VersionNum; }
				set { m_fHL7VersionNum = value; }
			}

			public int LimitORMMsgPV1AssignedPatientLocation
			{
				get { return m_nLimitORMMsgPV1AssignedPatientLocation; }
				set { m_nLimitORMMsgPV1AssignedPatientLocation = value; }
			}

			public int LimitORMMsgOBRPhysicianName
			{
				get { return m_nLimitORMMsgOBRPhysicianName; }
				set { m_nLimitORMMsgOBRPhysicianName = value; }
			}

			public int LimitORMMsgPV1ReferPhysicianName
			{
				get { return m_nLimitORMMsgPV1ReferPhysicianName; }
				set { m_nLimitORMMsgPV1ReferPhysicianName = value; }
			}

			public int LimitORUMsgOBRPhysicianName
			{
				get { return m_nLimitORUMsgOBRPhysicianName; }
				set { m_nLimitORUMsgOBRPhysicianName = value; }
			}

		}

		[Serializable]
		public class HL7ProcessingNetwork
		{
			private string m_TPSIPAddress;
			private int m_TPSPortNumber;
			private string m_HISIPAddress;
			private int m_HISPortNumber;

			public String TPSIPAddress
			{
				get { return m_TPSIPAddress; }
				set { m_TPSIPAddress = value; }
			}

			public int TPSPortNumber
			{
				get { return m_TPSPortNumber; }
				set { m_TPSPortNumber = value; }
			}

			public String HISIPAddress
			{
				get { return m_HISIPAddress; }
				set { m_HISIPAddress = value; }
			}

			public int HISPortNumber
			{
				get { return m_HISPortNumber; }
				set { m_HISPortNumber = value; }
			}

			public HL7ProcessingNetwork()
			{
				// HL7 Processing Service IP address and port
				m_TPSIPAddress = "127.0.0.1";
				m_TPSPortNumber = 9000;

				// HIS (Hospital Information system) IP address and port
				m_HISIPAddress = "127.0.0.1";
				m_HISPortNumber = 9001;
			}

		}

		[Serializable]
		public class HL7ProcessingUser
		{
			private string m_UserName;
			private string m_Password;

			public String UserName
			{
				get { return m_UserName; }
				set { m_UserName = value; }
			}

			public String Password
			{
				get { return m_Password; }
				set { m_Password = value; }
			}

			public HL7ProcessingUser()
			{
				m_UserName = "Admin";
				m_Password = "QW f&+&V"; // encrypted password
			}

		}

		// Wrapper for NameValueCollection which is normally NOT serializable
		[Serializable]
		public class FieldNameCollection : IXmlSerializable
		{
			private NameValueCollection attributes;

			public FieldNameCollection()
			{
				// Add default HL7Svc to HL7 field mappings
				attributes = new NameValueCollection();
				// Note that we cannot have any whitespace or special characters like #$%^&| 
				// in the name in order to serialize to XML, so they will be replaced with _'s
				// Any group/fields mapped to blank values will result in no change to default Database.
				attributes.Add("Demographics_First_Name", "FirstName");
				attributes.Add("Demographics_Last_Name", "LastName");
				attributes.Add("Demographics_Date_Of_Birth", "DOB");
				attributes.Add("Demographics_Sex", "Sex");
				attributes.Add("Demographics_ID", "PatientID");
				attributes.Add("Demographics_Medical_Record__", "PatientAccountNumber");
				attributes.Add("Demographics_ID_Type", "OrderControlNumber");
				attributes.Add("Demographics_Physician", "Physician");
				attributes.Add("Logbook_Tech_Name", "");
				attributes.Add("Logbook_Test_Number", "PatientVisitNumber");
				attributes.Add("Logbook_Type_of_Test", "HospitalService");
				attributes.Add("Logbook_Room_Number", "");
				attributes.Add("Logbook_Test_Site", "Test Site");
				attributes.Add("Logbook_Date_of_Request", "");
				attributes.Add("Logbook_Length", "");
				attributes.Add("Logbook_Reviewed", "");
				attributes.Add("Logbook_Start_Date_Time", "DateOfService");
				attributes.Add("Logbook_End_Date_Time", "DateOfService");
				attributes.Add("Logbook_Filename", "");
				attributes.Add("Logbook_Disc_Label", "");
				attributes.Add("Logbook_Interp_Date", "");
				attributes.Add("Logbook_Scoring_Tech", "");
				attributes.Add("Logbook_Scored", "");
				attributes.Add("Logbook_Archived", "");
				attributes.Add("Referral_Refer_Last_Name", "Refer Last Name");
			}

			public FieldNameCollection(NameValueCollection attributes)
			{
				this.attributes = attributes;
			}

			[XmlIgnore]
			public NameValueCollection Attributes
			{
				get { return this.attributes; }
				set { this.attributes = value; }
			}

			#region IXmlSerializable Members

			XmlSchema IXmlSerializable.GetSchema()
			{
				return null; // not needed
			}

			void IXmlSerializable.ReadXml(XmlReader reader)
			{
				this.attributes = new NameValueCollection();

				// Read each element within the HL7SvcToHL7FieldMapper element (up until the end element)
				while (reader.Read() && reader.NodeType != XmlNodeType.EndElement)
				{
					// move to each Field element attribute and get the group/field name and HL7 value
					while (reader.MoveToNextAttribute())
						this.attributes.Add(reader.Name, reader.Value);
				}
				reader.Read(); // Read the end element
			}

			void IXmlSerializable.WriteXml(XmlWriter writer)
			{
				foreach (string key in this.attributes.Keys)
				{
					writer.WriteStartElement("Field");

					string value = this.attributes[key];
					writer.WriteAttributeString(key, value);
					writer.WriteEndElement();
				}
			}

			#endregion
		}
	}

}

