namespace HL7Simulator
{
    partial class HL7SimulatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.tabMsgSwitch = new System.Windows.Forms.TabControl();
			this.tabPageORM = new System.Windows.Forms.TabPage();
			this.tbRoomNumber = new System.Windows.Forms.TextBox();
			this.lbRoomNumber = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.tbReferPhyLName = new System.Windows.Forms.TextBox();
			this.cbLLPCompliantORM = new System.Windows.Forms.CheckBox();
			this.cbHL7ReportStatus = new System.Windows.Forms.ComboBox();
			this.label34 = new System.Windows.Forms.Label();
			this.tbReferPhyFName = new System.Windows.Forms.TextBox();
			this.tbTestSite = new System.Windows.Forms.TextBox();
			this.tbPhyName = new System.Windows.Forms.TextBox();
			this.label33 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.cbHL7VersionNum = new System.Windows.Forms.ComboBox();
			this.tbNarrative7 = new System.Windows.Forms.TextBox();
			this.tbNarrative6 = new System.Windows.Forms.TextBox();
			this.tbNarrative5 = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.tbHospitalService = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.tbVisitNumber = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.tbOrderedCategory = new System.Windows.Forms.TextBox();
			this.label24 = new System.Windows.Forms.Label();
			this.tbOrderControl = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.dateTimePickerDateOfService = new System.Windows.Forms.DateTimePicker();
			this.label22 = new System.Windows.Forms.Label();
			this.tbPatientAccount = new System.Windows.Forms.TextBox();
			this.cbValidateText = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rbUpdate = new System.Windows.Forms.RadioButton();
			this.rbNew = new System.Windows.Forms.RadioButton();
			this.rbCancel = new System.Windows.Forms.RadioButton();
			this.label21 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.tbNarrative4 = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.tbNarrative3 = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.tbNarrative2 = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.tbNarrative1 = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.dateTimePickerApptTime = new System.Windows.Forms.DateTimePicker();
			this.dateTimePickerApptDate = new System.Windows.Forms.DateTimePicker();
			this.label14 = new System.Windows.Forms.Label();
			this.tbComment4 = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.tbComment3 = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.tbComment2 = new System.Windows.Forms.TextBox();
			this.buttonHL7Report = new System.Windows.Forms.Button();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.tbFolderName = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.tbReportName = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.tbComment1 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.tbLastName = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.tbFirstName = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.tbSex = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tbPatientID = new System.Windows.Forms.TextBox();
			this.dateTimePickerDOB = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.tbMessageCode = new System.Windows.Forms.TextBox();
			this.textBoxResults = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonORMMsg = new System.Windows.Forms.Button();
			this.tabPageADT = new System.Windows.Forms.TabPage();
			this.tbNewPatAcc = new System.Windows.Forms.TextBox();
			this.tbNewPatID = new System.Windows.Forms.TextBox();
			this.lblNewPatID = new System.Windows.Forms.Label();
			this.lblNewPatAcc = new System.Windows.Forms.Label();
			this.tbAssignedTestSite = new System.Windows.Forms.TextBox();
			this.tbAssignedRoomNumber = new System.Windows.Forms.TextBox();
			this.lblAssignedRoomNumber = new System.Windows.Forms.Label();
			this.lblAssignedTestSite = new System.Windows.Forms.Label();
			this.cBoxPatientClass = new System.Windows.Forms.ComboBox();
			this.lblPatientClass = new System.Windows.Forms.Label();
			this.textBoxADTResult = new System.Windows.Forms.TextBox();
			this.btnSendADT = new System.Windows.Forms.Button();
			this.lblSendADT = new System.Windows.Forms.Label();
			this.lblADT_Type = new System.Windows.Forms.Label();
			this.cBoxChoose_ADT = new System.Windows.Forms.ComboBox();
			this.tabMsgSwitch.SuspendLayout();
			this.tabPageORM.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.tabPageADT.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabMsgSwitch
			// 
			this.tabMsgSwitch.Controls.Add(this.tabPageORM);
			this.tabMsgSwitch.Controls.Add(this.tabPageADT);
			this.tabMsgSwitch.Location = new System.Drawing.Point(3, 12);
			this.tabMsgSwitch.Name = "tabMsgSwitch";
			this.tabMsgSwitch.SelectedIndex = 0;
			this.tabMsgSwitch.Size = new System.Drawing.Size(769, 607);
			this.tabMsgSwitch.TabIndex = 0;
			// 
			// tabPageORM
			// 
			this.tabPageORM.BackColor = System.Drawing.Color.Transparent;
			this.tabPageORM.Controls.Add(this.tbRoomNumber);
			this.tabPageORM.Controls.Add(this.lbRoomNumber);
			this.tabPageORM.Controls.Add(this.label35);
			this.tabPageORM.Controls.Add(this.tbReferPhyLName);
			this.tabPageORM.Controls.Add(this.cbLLPCompliantORM);
			this.tabPageORM.Controls.Add(this.cbHL7ReportStatus);
			this.tabPageORM.Controls.Add(this.label34);
			this.tabPageORM.Controls.Add(this.tbReferPhyFName);
			this.tabPageORM.Controls.Add(this.tbTestSite);
			this.tabPageORM.Controls.Add(this.tbPhyName);
			this.tabPageORM.Controls.Add(this.label33);
			this.tabPageORM.Controls.Add(this.label32);
			this.tabPageORM.Controls.Add(this.label31);
			this.tabPageORM.Controls.Add(this.cbHL7VersionNum);
			this.tabPageORM.Controls.Add(this.tbNarrative7);
			this.tabPageORM.Controls.Add(this.tbNarrative6);
			this.tabPageORM.Controls.Add(this.tbNarrative5);
			this.tabPageORM.Controls.Add(this.label30);
			this.tabPageORM.Controls.Add(this.label29);
			this.tabPageORM.Controls.Add(this.label28);
			this.tabPageORM.Controls.Add(this.label27);
			this.tabPageORM.Controls.Add(this.tbHospitalService);
			this.tabPageORM.Controls.Add(this.label26);
			this.tabPageORM.Controls.Add(this.tbVisitNumber);
			this.tabPageORM.Controls.Add(this.label25);
			this.tabPageORM.Controls.Add(this.tbOrderedCategory);
			this.tabPageORM.Controls.Add(this.label24);
			this.tabPageORM.Controls.Add(this.tbOrderControl);
			this.tabPageORM.Controls.Add(this.label23);
			this.tabPageORM.Controls.Add(this.dateTimePickerDateOfService);
			this.tabPageORM.Controls.Add(this.label22);
			this.tabPageORM.Controls.Add(this.tbPatientAccount);
			this.tabPageORM.Controls.Add(this.cbValidateText);
			this.tabPageORM.Controls.Add(this.groupBox1);
			this.tabPageORM.Controls.Add(this.label21);
			this.tabPageORM.Controls.Add(this.label17);
			this.tabPageORM.Controls.Add(this.tbNarrative4);
			this.tabPageORM.Controls.Add(this.label18);
			this.tabPageORM.Controls.Add(this.tbNarrative3);
			this.tabPageORM.Controls.Add(this.label19);
			this.tabPageORM.Controls.Add(this.tbNarrative2);
			this.tabPageORM.Controls.Add(this.label20);
			this.tabPageORM.Controls.Add(this.tbNarrative1);
			this.tabPageORM.Controls.Add(this.label16);
			this.tabPageORM.Controls.Add(this.label15);
			this.tabPageORM.Controls.Add(this.dateTimePickerApptTime);
			this.tabPageORM.Controls.Add(this.dateTimePickerApptDate);
			this.tabPageORM.Controls.Add(this.label14);
			this.tabPageORM.Controls.Add(this.tbComment4);
			this.tabPageORM.Controls.Add(this.label13);
			this.tabPageORM.Controls.Add(this.tbComment3);
			this.tabPageORM.Controls.Add(this.label12);
			this.tabPageORM.Controls.Add(this.tbComment2);
			this.tabPageORM.Controls.Add(this.buttonHL7Report);
			this.tabPageORM.Controls.Add(this.label11);
			this.tabPageORM.Controls.Add(this.label10);
			this.tabPageORM.Controls.Add(this.tbFolderName);
			this.tabPageORM.Controls.Add(this.label9);
			this.tabPageORM.Controls.Add(this.tbReportName);
			this.tabPageORM.Controls.Add(this.label8);
			this.tabPageORM.Controls.Add(this.tbComment1);
			this.tabPageORM.Controls.Add(this.label7);
			this.tabPageORM.Controls.Add(this.tbLastName);
			this.tabPageORM.Controls.Add(this.label6);
			this.tabPageORM.Controls.Add(this.tbFirstName);
			this.tabPageORM.Controls.Add(this.label5);
			this.tabPageORM.Controls.Add(this.label4);
			this.tabPageORM.Controls.Add(this.tbSex);
			this.tabPageORM.Controls.Add(this.label3);
			this.tabPageORM.Controls.Add(this.tbPatientID);
			this.tabPageORM.Controls.Add(this.dateTimePickerDOB);
			this.tabPageORM.Controls.Add(this.label2);
			this.tabPageORM.Controls.Add(this.tbMessageCode);
			this.tabPageORM.Controls.Add(this.textBoxResults);
			this.tabPageORM.Controls.Add(this.label1);
			this.tabPageORM.Controls.Add(this.buttonORMMsg);
			this.tabPageORM.Location = new System.Drawing.Point(4, 22);
			this.tabPageORM.Name = "tabPageORM";
			this.tabPageORM.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageORM.Size = new System.Drawing.Size(761, 581);
			this.tabPageORM.TabIndex = 0;
			this.tabPageORM.Text = "ORM";
			// 
			// tbRoomNumber
			// 
			this.tbRoomNumber.Location = new System.Drawing.Point(86, 386);
			this.tbRoomNumber.Name = "tbRoomNumber";
			this.tbRoomNumber.Size = new System.Drawing.Size(86, 20);
			this.tbRoomNumber.TabIndex = 154;
			this.tbRoomNumber.Text = "Rm101";
			// 
			// lbRoomNumber
			// 
			this.lbRoomNumber.AutoSize = true;
			this.lbRoomNumber.Location = new System.Drawing.Point(2, 393);
			this.lbRoomNumber.Name = "lbRoomNumber";
			this.lbRoomNumber.Size = new System.Drawing.Size(78, 13);
			this.lbRoomNumber.TabIndex = 153;
			this.lbRoomNumber.Text = "Room Number:";
			// 
			// label35
			// 
			this.label35.AutoSize = true;
			this.label35.Location = new System.Drawing.Point(184, 389);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(138, 13);
			this.label35.TabIndex = 152;
			this.label35.Text = "Refer Physician Last Name:";
			// 
			// tbReferPhyLName
			// 
			this.tbReferPhyLName.Location = new System.Drawing.Point(322, 386);
			this.tbReferPhyLName.MaxLength = 64;
			this.tbReferPhyLName.Name = "tbReferPhyLName";
			this.tbReferPhyLName.Size = new System.Drawing.Size(110, 20);
			this.tbReferPhyLName.TabIndex = 124;
			this.tbReferPhyLName.Text = "ReferLName";
			// 
			// cbLLPCompliantORM
			// 
			this.cbLLPCompliantORM.AutoSize = true;
			this.cbLLPCompliantORM.Location = new System.Drawing.Point(7, 44);
			this.cbLLPCompliantORM.Name = "cbLLPCompliantORM";
			this.cbLLPCompliantORM.Size = new System.Drawing.Size(155, 17);
			this.cbLLPCompliantORM.TabIndex = 82;
			this.cbLLPCompliantORM.Text = "Add Header-Trailer to ORM";
			this.cbLLPCompliantORM.UseVisualStyleBackColor = true;
			// 
			// cbHL7ReportStatus
			// 
			this.cbHL7ReportStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbHL7ReportStatus.FormattingEnabled = true;
			this.cbHL7ReportStatus.Items.AddRange(new object[] {
            "Pending",
            "Corrected",
            "Finalized"});
			this.cbHL7ReportStatus.Location = new System.Drawing.Point(632, 27);
			this.cbHL7ReportStatus.MaxDropDownItems = 3;
			this.cbHL7ReportStatus.Name = "cbHL7ReportStatus";
			this.cbHL7ReportStatus.Size = new System.Drawing.Size(98, 21);
			this.cbHL7ReportStatus.TabIndex = 144;
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Location = new System.Drawing.Point(185, 363);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(137, 13);
			this.label34.TabIndex = 151;
			this.label34.Text = "Refer Physician First Name:";
			// 
			// tbReferPhyFName
			// 
			this.tbReferPhyFName.Location = new System.Drawing.Point(322, 360);
			this.tbReferPhyFName.MaxLength = 64;
			this.tbReferPhyFName.Name = "tbReferPhyFName";
			this.tbReferPhyFName.Size = new System.Drawing.Size(110, 20);
			this.tbReferPhyFName.TabIndex = 123;
			this.tbReferPhyFName.Text = "ReferFName";
			// 
			// tbTestSite
			// 
			this.tbTestSite.Location = new System.Drawing.Point(86, 360);
			this.tbTestSite.MaxLength = 64;
			this.tbTestSite.Name = "tbTestSite";
			this.tbTestSite.Size = new System.Drawing.Size(86, 20);
			this.tbTestSite.TabIndex = 112;
			this.tbTestSite.Text = "Location 1";
			// 
			// tbPhyName
			// 
			this.tbPhyName.Location = new System.Drawing.Point(322, 330);
			this.tbPhyName.MaxLength = 64;
			this.tbPhyName.Name = "tbPhyName";
			this.tbPhyName.Size = new System.Drawing.Size(110, 20);
			this.tbPhyName.TabIndex = 122;
			this.tbPhyName.Text = "Ordering Doc";
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Location = new System.Drawing.Point(2, 363);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(52, 13);
			this.label33.TabIndex = 149;
			this.label33.Text = "Test Site:";
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Location = new System.Drawing.Point(230, 333);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(86, 13);
			this.label32.TabIndex = 148;
			this.label32.Text = "Physician Name:";
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(4, 89);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(68, 13);
			this.label31.TabIndex = 147;
			this.label31.Text = "HL7 Version:";
			// 
			// cbHL7VersionNum
			// 
			this.cbHL7VersionNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbHL7VersionNum.FormattingEnabled = true;
			this.cbHL7VersionNum.Items.AddRange(new object[] {
            "2.3",
            "2.4",
            "2.5"});
			this.cbHL7VersionNum.Location = new System.Drawing.Point(86, 86);
			this.cbHL7VersionNum.MaxDropDownItems = 3;
			this.cbHL7VersionNum.Name = "cbHL7VersionNum";
			this.cbHL7VersionNum.Size = new System.Drawing.Size(86, 21);
			this.cbHL7VersionNum.TabIndex = 79;
			// 
			// tbNarrative7
			// 
			this.tbNarrative7.Location = new System.Drawing.Point(551, 303);
			this.tbNarrative7.MaxLength = 200;
			this.tbNarrative7.Name = "tbNarrative7";
			this.tbNarrative7.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative7.TabIndex = 140;
			// 
			// tbNarrative6
			// 
			this.tbNarrative6.Location = new System.Drawing.Point(551, 273);
			this.tbNarrative6.MaxLength = 200;
			this.tbNarrative6.Name = "tbNarrative6";
			this.tbNarrative6.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative6.TabIndex = 139;
			// 
			// tbNarrative5
			// 
			this.tbNarrative5.Location = new System.Drawing.Point(551, 244);
			this.tbNarrative5.MaxLength = 200;
			this.tbNarrative5.Name = "tbNarrative5";
			this.tbNarrative5.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative5.TabIndex = 138;
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(464, 303);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(62, 13);
			this.label30.TabIndex = 145;
			this.label30.Text = "Narrative 7:";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(464, 276);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(62, 13);
			this.label29.TabIndex = 142;
			this.label29.Text = "Narrative 6:";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(464, 251);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(62, 13);
			this.label28.TabIndex = 141;
			this.label28.Text = "Narrative 5:";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(230, 306);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(87, 13);
			this.label27.TabIndex = 137;
			this.label27.Text = "Hospital Service:";
			// 
			// tbHospitalService
			// 
			this.tbHospitalService.Location = new System.Drawing.Point(322, 303);
			this.tbHospitalService.MaxLength = 32;
			this.tbHospitalService.Name = "tbHospitalService";
			this.tbHospitalService.Size = new System.Drawing.Size(110, 20);
			this.tbHospitalService.TabIndex = 121;
			this.tbHospitalService.Text = "PSG";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(237, 280);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(69, 13);
			this.label26.TabIndex = 134;
			this.label26.Text = "Visit Number:";
			// 
			// tbVisitNumber
			// 
			this.tbVisitNumber.Location = new System.Drawing.Point(322, 277);
			this.tbVisitNumber.MaxLength = 32;
			this.tbVisitNumber.Name = "tbVisitNumber";
			this.tbVisitNumber.Size = new System.Drawing.Size(110, 20);
			this.tbVisitNumber.TabIndex = 120;
			this.tbVisitNumber.Text = "9";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(237, 251);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(79, 13);
			this.label25.TabIndex = 132;
			this.label25.Text = "Ordered Categ:";
			// 
			// tbOrderedCategory
			// 
			this.tbOrderedCategory.Location = new System.Drawing.Point(322, 248);
			this.tbOrderedCategory.MaxLength = 32;
			this.tbOrderedCategory.Name = "tbOrderedCategory";
			this.tbOrderedCategory.Size = new System.Drawing.Size(110, 20);
			this.tbOrderedCategory.TabIndex = 119;
			this.tbOrderedCategory.Text = "Diagnostic";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(2, 337);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(72, 13);
			this.label24.TabIndex = 128;
			this.label24.Text = "Order Control:";
			// 
			// tbOrderControl
			// 
			this.tbOrderControl.Location = new System.Drawing.Point(86, 334);
			this.tbOrderControl.MaxLength = 32;
			this.tbOrderControl.Name = "tbOrderControl";
			this.tbOrderControl.Size = new System.Drawing.Size(86, 20);
			this.tbOrderControl.TabIndex = 111;
			this.tbOrderControl.Text = "Test 2";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(2, 310);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(84, 13);
			this.label23.TabIndex = 127;
			this.label23.Text = "Date of Service:";
			// 
			// dateTimePickerDateOfService
			// 
			this.dateTimePickerDateOfService.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePickerDateOfService.Location = new System.Drawing.Point(86, 306);
			this.dateTimePickerDateOfService.Name = "dateTimePickerDateOfService";
			this.dateTimePickerDateOfService.Size = new System.Drawing.Size(86, 20);
			this.dateTimePickerDateOfService.TabIndex = 110;
			this.dateTimePickerDateOfService.Value = new System.DateTime(2009, 1, 15, 14, 11, 0, 0);
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(-3, 198);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(86, 13);
			this.label22.TabIndex = 125;
			this.label22.Text = "Patient Account:";
			// 
			// tbPatientAccount
			// 
			this.tbPatientAccount.Location = new System.Drawing.Point(86, 195);
			this.tbPatientAccount.MaxLength = 32;
			this.tbPatientAccount.Name = "tbPatientAccount";
			this.tbPatientAccount.Size = new System.Drawing.Size(86, 20);
			this.tbPatientAccount.TabIndex = 106;
			this.tbPatientAccount.Text = "987654";
			// 
			// cbValidateText
			// 
			this.cbValidateText.AutoSize = true;
			this.cbValidateText.Checked = true;
			this.cbValidateText.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbValidateText.Location = new System.Drawing.Point(667, 302);
			this.cbValidateText.Name = "cbValidateText";
			this.cbValidateText.Size = new System.Drawing.Size(88, 17);
			this.cbValidateText.TabIndex = 143;
			this.cbValidateText.Text = "Validate Text";
			this.cbValidateText.UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rbUpdate);
			this.groupBox1.Controls.Add(this.rbNew);
			this.groupBox1.Controls.Add(this.rbCancel);
			this.groupBox1.Location = new System.Drawing.Point(275, 27);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(183, 31);
			this.groupBox1.TabIndex = 95;
			this.groupBox1.TabStop = false;
			// 
			// rbUpdate
			// 
			this.rbUpdate.AutoSize = true;
			this.rbUpdate.Location = new System.Drawing.Point(116, 10);
			this.rbUpdate.Name = "rbUpdate";
			this.rbUpdate.Size = new System.Drawing.Size(60, 17);
			this.rbUpdate.TabIndex = 2;
			this.rbUpdate.Text = "Update";
			this.rbUpdate.UseVisualStyleBackColor = true;
			// 
			// rbNew
			// 
			this.rbNew.AutoSize = true;
			this.rbNew.Checked = true;
			this.rbNew.Location = new System.Drawing.Point(11, 10);
			this.rbNew.Name = "rbNew";
			this.rbNew.Size = new System.Drawing.Size(47, 17);
			this.rbNew.TabIndex = 1;
			this.rbNew.TabStop = true;
			this.rbNew.Text = "New";
			this.rbNew.UseVisualStyleBackColor = true;
			// 
			// rbCancel
			// 
			this.rbCancel.AutoSize = true;
			this.rbCancel.Location = new System.Drawing.Point(58, 10);
			this.rbCancel.Name = "rbCancel";
			this.rbCancel.Size = new System.Drawing.Size(58, 17);
			this.rbCancel.TabIndex = 1;
			this.rbCancel.Text = "Cancel";
			this.rbCancel.UseVisualStyleBackColor = true;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(200, 39);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(69, 13);
			this.label21.TabIndex = 88;
			this.label21.Text = "Appointment:";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(464, 221);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(62, 13);
			this.label17.TabIndex = 102;
			this.label17.Text = "Narrative 4:";
			// 
			// tbNarrative4
			// 
			this.tbNarrative4.Location = new System.Drawing.Point(551, 218);
			this.tbNarrative4.MaxLength = 200;
			this.tbNarrative4.Name = "tbNarrative4";
			this.tbNarrative4.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative4.TabIndex = 136;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(464, 191);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(62, 13);
			this.label18.TabIndex = 101;
			this.label18.Text = "Narrative 3:";
			// 
			// tbNarrative3
			// 
			this.tbNarrative3.Location = new System.Drawing.Point(551, 188);
			this.tbNarrative3.MaxLength = 200;
			this.tbNarrative3.Name = "tbNarrative3";
			this.tbNarrative3.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative3.TabIndex = 135;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(464, 162);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(62, 13);
			this.label19.TabIndex = 100;
			this.label19.Text = "Narrative 2:";
			// 
			// tbNarrative2
			// 
			this.tbNarrative2.Location = new System.Drawing.Point(551, 159);
			this.tbNarrative2.MaxLength = 200;
			this.tbNarrative2.Name = "tbNarrative2";
			this.tbNarrative2.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative2.TabIndex = 133;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(464, 136);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(62, 13);
			this.label20.TabIndex = 99;
			this.label20.Text = "Narrative 1:";
			// 
			// tbNarrative1
			// 
			this.tbNarrative1.Location = new System.Drawing.Point(551, 133);
			this.tbNarrative1.MaxLength = 200;
			this.tbNarrative1.Name = "tbNarrative1";
			this.tbNarrative1.Size = new System.Drawing.Size(110, 20);
			this.tbNarrative1.TabIndex = 131;
			this.tbNarrative1.Text = "Add narrative...";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(2, 280);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(70, 13);
			this.label16.TabIndex = 87;
			this.label16.Text = "Time of Appt:";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(2, 255);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(70, 13);
			this.label15.TabIndex = 86;
			this.label15.Text = "Date of Appt:";
			// 
			// dateTimePickerApptTime
			// 
			this.dateTimePickerApptTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePickerApptTime.Location = new System.Drawing.Point(86, 277);
			this.dateTimePickerApptTime.Name = "dateTimePickerApptTime";
			this.dateTimePickerApptTime.Size = new System.Drawing.Size(86, 20);
			this.dateTimePickerApptTime.TabIndex = 109;
			// 
			// dateTimePickerApptDate
			// 
			this.dateTimePickerApptDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePickerApptDate.Location = new System.Drawing.Point(86, 251);
			this.dateTimePickerApptDate.Name = "dateTimePickerApptDate";
			this.dateTimePickerApptDate.Size = new System.Drawing.Size(86, 20);
			this.dateTimePickerApptDate.TabIndex = 108;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(243, 225);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(63, 13);
			this.label14.TabIndex = 94;
			this.label14.Text = "Comment 4:";
			// 
			// tbComment4
			// 
			this.tbComment4.Location = new System.Drawing.Point(322, 218);
			this.tbComment4.MaxLength = 200;
			this.tbComment4.Name = "tbComment4";
			this.tbComment4.Size = new System.Drawing.Size(110, 20);
			this.tbComment4.TabIndex = 118;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(243, 195);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(63, 13);
			this.label13.TabIndex = 93;
			this.label13.Text = "Comment 3:";
			// 
			// tbComment3
			// 
			this.tbComment3.Location = new System.Drawing.Point(322, 191);
			this.tbComment3.MaxLength = 200;
			this.tbComment3.Name = "tbComment3";
			this.tbComment3.Size = new System.Drawing.Size(110, 20);
			this.tbComment3.TabIndex = 117;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(243, 166);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(63, 13);
			this.label12.TabIndex = 92;
			this.label12.Text = "Comment 2:";
			// 
			// tbComment2
			// 
			this.tbComment2.Location = new System.Drawing.Point(322, 165);
			this.tbComment2.MaxLength = 200;
			this.tbComment2.Name = "tbComment2";
			this.tbComment2.Size = new System.Drawing.Size(110, 20);
			this.tbComment2.TabIndex = 116;
			// 
			// buttonHL7Report
			// 
			this.buttonHL7Report.Location = new System.Drawing.Point(551, 25);
			this.buttonHL7Report.Name = "buttonHL7Report";
			this.buttonHL7Report.Size = new System.Drawing.Size(75, 23);
			this.buttonHL7Report.TabIndex = 146;
			this.buttonHL7Report.Text = "HL7 Report";
			this.buttonHL7Report.UseVisualStyleBackColor = true;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(464, 30);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(79, 13);
			this.label11.TabIndex = 96;
			this.label11.Text = "Create Record:";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(464, 93);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(70, 13);
			this.label10.TabIndex = 98;
			this.label10.Text = "Folder Name:";
			// 
			// tbFolderName
			// 
			this.tbFolderName.Location = new System.Drawing.Point(548, 90);
			this.tbFolderName.MaxLength = 255;
			this.tbFolderName.Name = "tbFolderName";
			this.tbFolderName.Size = new System.Drawing.Size(175, 20);
			this.tbFolderName.TabIndex = 130;
			this.tbFolderName.Text = "\\TWIN_DATA\\FLINSTONE_JOHN_050708_2201.002\\";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(461, 67);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(73, 13);
			this.label9.TabIndex = 97;
			this.label9.Text = "Report Name:";
			// 
			// tbReportName
			// 
			this.tbReportName.Location = new System.Drawing.Point(548, 64);
			this.tbReportName.MaxLength = 255;
			this.tbReportName.Name = "tbReportName";
			this.tbReportName.Size = new System.Drawing.Size(175, 20);
			this.tbReportName.TabIndex = 129;
			this.tbReportName.Text = "FINAL_REPORT.DOC";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(243, 142);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(63, 13);
			this.label8.TabIndex = 91;
			this.label8.Text = "Comment 1:";
			// 
			// tbComment1
			// 
			this.tbComment1.Location = new System.Drawing.Point(324, 139);
			this.tbComment1.MaxLength = 200;
			this.tbComment1.Name = "tbComment1";
			this.tbComment1.Size = new System.Drawing.Size(108, 20);
			this.tbComment1.TabIndex = 115;
			this.tbComment1.Text = "Wheelchair required";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(245, 116);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(61, 13);
			this.label7.TabIndex = 90;
			this.label7.Text = "Last Name:";
			// 
			// tbLastName
			// 
			this.tbLastName.Location = new System.Drawing.Point(324, 113);
			this.tbLastName.MaxLength = 64;
			this.tbLastName.Name = "tbLastName";
			this.tbLastName.Size = new System.Drawing.Size(108, 20);
			this.tbLastName.TabIndex = 114;
			this.tbLastName.Text = "FLINTSTONE";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(246, 90);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(60, 13);
			this.label6.TabIndex = 89;
			this.label6.Text = "First Name:";
			// 
			// tbFirstName
			// 
			this.tbFirstName.Location = new System.Drawing.Point(324, 87);
			this.tbFirstName.MaxLength = 64;
			this.tbFirstName.Name = "tbFirstName";
			this.tbFirstName.Size = new System.Drawing.Size(108, 20);
			this.tbFirstName.TabIndex = 113;
			this.tbFirstName.Text = "JOHN";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(1, 146);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(69, 13);
			this.label5.TabIndex = 83;
			this.label5.Text = "Date of Birth:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(2, 225);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(64, 13);
			this.label4.TabIndex = 85;
			this.label4.Text = "Patient Sex:";
			// 
			// tbSex
			// 
			this.tbSex.Location = new System.Drawing.Point(86, 222);
			this.tbSex.MaxLength = 1;
			this.tbSex.Name = "tbSex";
			this.tbSex.Size = new System.Drawing.Size(86, 20);
			this.tbSex.TabIndex = 107;
			this.tbSex.Text = "M";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(9, 172);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(57, 13);
			this.label3.TabIndex = 84;
			this.label3.Text = "Patient ID:";
			// 
			// tbPatientID
			// 
			this.tbPatientID.Location = new System.Drawing.Point(86, 166);
			this.tbPatientID.MaxLength = 32;
			this.tbPatientID.Name = "tbPatientID";
			this.tbPatientID.Size = new System.Drawing.Size(86, 20);
			this.tbPatientID.TabIndex = 105;
			this.tbPatientID.Text = "54236798";
			// 
			// dateTimePickerDOB
			// 
			this.dateTimePickerDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dateTimePickerDOB.Location = new System.Drawing.Point(86, 140);
			this.dateTimePickerDOB.Name = "dateTimePickerDOB";
			this.dateTimePickerDOB.Size = new System.Drawing.Size(86, 20);
			this.dateTimePickerDOB.TabIndex = 104;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(1, 117);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(81, 13);
			this.label2.TabIndex = 81;
			this.label2.Text = "Message Code:";
			// 
			// tbMessageCode
			// 
			this.tbMessageCode.Location = new System.Drawing.Point(86, 114);
			this.tbMessageCode.MaxLength = 20;
			this.tbMessageCode.Name = "tbMessageCode";
			this.tbMessageCode.Size = new System.Drawing.Size(86, 20);
			this.tbMessageCode.TabIndex = 103;
			this.tbMessageCode.Text = "104586";
			// 
			// textBoxResults
			// 
			this.textBoxResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxResults.Location = new System.Drawing.Point(4, 422);
			this.textBoxResults.Multiline = true;
			this.textBoxResults.Name = "textBoxResults";
			this.textBoxResults.Size = new System.Drawing.Size(754, 153);
			this.textBoxResults.TabIndex = 150;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(2, 10);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(81, 13);
			this.label1.TabIndex = 80;
			this.label1.Text = "Send Message:";
			// 
			// buttonORMMsg
			// 
			this.buttonORMMsg.Location = new System.Drawing.Point(89, 5);
			this.buttonORMMsg.Name = "buttonORMMsg";
			this.buttonORMMsg.Size = new System.Drawing.Size(75, 23);
			this.buttonORMMsg.TabIndex = 126;
			this.buttonORMMsg.Text = "ORM Msg";
			this.buttonORMMsg.UseVisualStyleBackColor = true;
			this.buttonORMMsg.Click += new System.EventHandler(this.buttonORMMsg_Click);
			// 
			// tabPageADT
			// 
			this.tabPageADT.BackColor = System.Drawing.Color.Transparent;
			this.tabPageADT.Controls.Add(this.tbNewPatAcc);
			this.tabPageADT.Controls.Add(this.tbNewPatID);
			this.tabPageADT.Controls.Add(this.lblNewPatID);
			this.tabPageADT.Controls.Add(this.lblNewPatAcc);
			this.tabPageADT.Controls.Add(this.tbAssignedTestSite);
			this.tabPageADT.Controls.Add(this.tbAssignedRoomNumber);
			this.tabPageADT.Controls.Add(this.lblAssignedRoomNumber);
			this.tabPageADT.Controls.Add(this.lblAssignedTestSite);
			this.tabPageADT.Controls.Add(this.cBoxPatientClass);
			this.tabPageADT.Controls.Add(this.lblPatientClass);
			this.tabPageADT.Controls.Add(this.textBoxADTResult);
			this.tabPageADT.Controls.Add(this.btnSendADT);
			this.tabPageADT.Controls.Add(this.lblSendADT);
			this.tabPageADT.Controls.Add(this.lblADT_Type);
			this.tabPageADT.Controls.Add(this.cBoxChoose_ADT);
			this.tabPageADT.Location = new System.Drawing.Point(4, 22);
			this.tabPageADT.Name = "tabPageADT";
			this.tabPageADT.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageADT.Size = new System.Drawing.Size(761, 581);
			this.tabPageADT.TabIndex = 1;
			this.tabPageADT.Text = "ADT";
			// 
			// tbNewPatAcc
			// 
			this.tbNewPatAcc.Enabled = false;
			this.tbNewPatAcc.Location = new System.Drawing.Point(561, 188);
			this.tbNewPatAcc.Name = "tbNewPatAcc";
			this.tbNewPatAcc.Size = new System.Drawing.Size(115, 20);
			this.tbNewPatAcc.TabIndex = 21;
			this.tbNewPatAcc.Text = "987655";
			// 
			// tbNewPatID
			// 
			this.tbNewPatID.Enabled = false;
			this.tbNewPatID.Location = new System.Drawing.Point(129, 188);
			this.tbNewPatID.Name = "tbNewPatID";
			this.tbNewPatID.Size = new System.Drawing.Size(115, 20);
			this.tbNewPatID.TabIndex = 19;
			this.tbNewPatID.Text = "54236799";
			// 
			// lblNewPatID
			// 
			this.lblNewPatID.AutoSize = true;
			this.lblNewPatID.Location = new System.Drawing.Point(43, 190);
			this.lblNewPatID.Name = "lblNewPatID";
			this.lblNewPatID.Size = new System.Drawing.Size(85, 13);
			this.lblNewPatID.TabIndex = 17;
			this.lblNewPatID.Text = "New Patient ID :";
			// 
			// lblNewPatAcc
			// 
			this.lblNewPatAcc.AutoSize = true;
			this.lblNewPatAcc.Location = new System.Drawing.Point(444, 191);
			this.lblNewPatAcc.Name = "lblNewPatAcc";
			this.lblNewPatAcc.Size = new System.Drawing.Size(114, 13);
			this.lblNewPatAcc.TabIndex = 13;
			this.lblNewPatAcc.Text = "New Patient Account :";
			// 
			// tbAssignedTestSite
			// 
			this.tbAssignedTestSite.Enabled = false;
			this.tbAssignedTestSite.Location = new System.Drawing.Point(561, 143);
			this.tbAssignedTestSite.Name = "tbAssignedTestSite";
			this.tbAssignedTestSite.Size = new System.Drawing.Size(110, 20);
			this.tbAssignedTestSite.TabIndex = 12;
			this.tbAssignedTestSite.Text = "Location 2";
			// 
			// tbAssignedRoomNumber
			// 
			this.tbAssignedRoomNumber.Enabled = false;
			this.tbAssignedRoomNumber.Location = new System.Drawing.Point(131, 143);
			this.tbAssignedRoomNumber.Name = "tbAssignedRoomNumber";
			this.tbAssignedRoomNumber.Size = new System.Drawing.Size(113, 20);
			this.tbAssignedRoomNumber.TabIndex = 11;
			this.tbAssignedRoomNumber.Text = "Rm102";
			// 
			// lblAssignedRoomNumber
			// 
			this.lblAssignedRoomNumber.AutoSize = true;
			this.lblAssignedRoomNumber.Location = new System.Drawing.Point(2, 147);
			this.lblAssignedRoomNumber.Name = "lblAssignedRoomNumber";
			this.lblAssignedRoomNumber.Size = new System.Drawing.Size(127, 13);
			this.lblAssignedRoomNumber.TabIndex = 10;
			this.lblAssignedRoomNumber.Text = "Assigned Room Number :";
			// 
			// lblAssignedTestSite
			// 
			this.lblAssignedTestSite.AutoSize = true;
			this.lblAssignedTestSite.Location = new System.Drawing.Point(457, 147);
			this.lblAssignedTestSite.Name = "lblAssignedTestSite";
			this.lblAssignedTestSite.Size = new System.Drawing.Size(101, 13);
			this.lblAssignedTestSite.TabIndex = 9;
			this.lblAssignedTestSite.Text = "Assigned Test Site :";
			// 
			// cBoxPatientClass
			// 
			this.cBoxPatientClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBoxPatientClass.FormattingEnabled = true;
			this.cBoxPatientClass.Items.AddRange(new object[] {
            "In-Patient",
            "Out-Patient",
            "Emergency",
            "NA"});
			this.cBoxPatientClass.Location = new System.Drawing.Point(78, 67);
			this.cBoxPatientClass.Name = "cBoxPatientClass";
			this.cBoxPatientClass.Size = new System.Drawing.Size(188, 21);
			this.cBoxPatientClass.TabIndex = 8;
			// 
			// lblPatientClass
			// 
			this.lblPatientClass.AutoSize = true;
			this.lblPatientClass.Location = new System.Drawing.Point(2, 72);
			this.lblPatientClass.Name = "lblPatientClass";
			this.lblPatientClass.Size = new System.Drawing.Size(74, 13);
			this.lblPatientClass.TabIndex = 7;
			this.lblPatientClass.Text = "Patient Class :";
			// 
			// textBoxADTResult
			// 
			this.textBoxADTResult.Location = new System.Drawing.Point(5, 269);
			this.textBoxADTResult.Multiline = true;
			this.textBoxADTResult.Name = "textBoxADTResult";
			this.textBoxADTResult.Size = new System.Drawing.Size(749, 306);
			this.textBoxADTResult.TabIndex = 6;
			// 
			// btnSendADT
			// 
			this.btnSendADT.Location = new System.Drawing.Point(679, 4);
			this.btnSendADT.Name = "btnSendADT";
			this.btnSendADT.Size = new System.Drawing.Size(75, 23);
			this.btnSendADT.TabIndex = 5;
			this.btnSendADT.Text = "Send ADT";
			this.btnSendADT.UseVisualStyleBackColor = true;
			this.btnSendADT.Click += new System.EventHandler(this.btnSendADT_Click);
			// 
			// lblSendADT
			// 
			this.lblSendADT.AutoSize = true;
			this.lblSendADT.Location = new System.Drawing.Point(589, 9);
			this.lblSendADT.Name = "lblSendADT";
			this.lblSendADT.Size = new System.Drawing.Size(84, 13);
			this.lblSendADT.TabIndex = 2;
			this.lblSendADT.Text = "Send Message :";
			// 
			// lblADT_Type
			// 
			this.lblADT_Type.AutoSize = true;
			this.lblADT_Type.Location = new System.Drawing.Point(6, 13);
			this.lblADT_Type.Name = "lblADT_Type";
			this.lblADT_Type.Size = new System.Drawing.Size(62, 13);
			this.lblADT_Type.TabIndex = 1;
			this.lblADT_Type.Text = "ADT Type :";
			// 
			// cBoxChoose_ADT
			// 
			this.cBoxChoose_ADT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cBoxChoose_ADT.FormattingEnabled = true;
			this.cBoxChoose_ADT.Items.AddRange(new object[] {
            "A01 ADMIT/VISIT NOTIFICATION",
            "A02 TRANSFER A PATIENT",
            "A03 DISCHARGE/END VISIT",
            "A04 REGISTER A PATIENT",
            "A05 PRE-ADMIT A PATIENT",
            "A06 CHANGE AN OUTPATIENT TO AN INPATIENT",
            "A07 CHANGE AN INPATIENT TO AN OUTPATIENT",
            "A08 UPDATE PATIENT INFORMATION",
            "A11 CANCEL ADMIT/VISIT NOTIFICATION",
            "A12 CANCEL TRANSFER",
            "A13 CANCEL DISCHARGE/END VISIT",
            "A18 MERGE PATIENT INFORMATION",
            "A31 UPDATE PERSON INFORMATION",
            "A40 MERGE PATIENT INFORMATION"});
			this.cBoxChoose_ADT.Location = new System.Drawing.Point(78, 6);
			this.cBoxChoose_ADT.Name = "cBoxChoose_ADT";
			this.cBoxChoose_ADT.Size = new System.Drawing.Size(301, 21);
			this.cBoxChoose_ADT.TabIndex = 0;
			this.cBoxChoose_ADT.SelectedValueChanged += new System.EventHandler(this.cBoxChoose_ADT_SelectedValueChanged);
			// 
			// HL7SimulatorForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(773, 631);
			this.Controls.Add(this.tabMsgSwitch);
			this.MaximizeBox = false;
			this.Name = "HL7SimulatorForm";
			this.Text = "HL7 Simulator";
			this.tabMsgSwitch.ResumeLayout(false);
			this.tabPageORM.ResumeLayout(false);
			this.tabPageORM.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.tabPageADT.ResumeLayout(false);
			this.tabPageADT.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.TabControl tabMsgSwitch;
		private System.Windows.Forms.TabPage tabPageORM;
		private System.Windows.Forms.TextBox tbRoomNumber;
		private System.Windows.Forms.Label lbRoomNumber;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.TextBox tbReferPhyLName;
		private System.Windows.Forms.CheckBox cbLLPCompliantORM;
		private System.Windows.Forms.ComboBox cbHL7ReportStatus;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.TextBox tbReferPhyFName;
		private System.Windows.Forms.TextBox tbTestSite;
		private System.Windows.Forms.TextBox tbPhyName;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.ComboBox cbHL7VersionNum;
		private System.Windows.Forms.TextBox tbNarrative7;
		private System.Windows.Forms.TextBox tbNarrative6;
		private System.Windows.Forms.TextBox tbNarrative5;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox tbHospitalService;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox tbVisitNumber;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.TextBox tbOrderedCategory;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.TextBox tbOrderControl;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.DateTimePicker dateTimePickerDateOfService;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.TextBox tbPatientAccount;
		private System.Windows.Forms.CheckBox cbValidateText;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbUpdate;
		private System.Windows.Forms.RadioButton rbNew;
		private System.Windows.Forms.RadioButton rbCancel;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox tbNarrative4;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.TextBox tbNarrative3;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox tbNarrative2;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.TextBox tbNarrative1;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.DateTimePicker dateTimePickerApptTime;
		private System.Windows.Forms.DateTimePicker dateTimePickerApptDate;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.TextBox tbComment4;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox tbComment3;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox tbComment2;
		private System.Windows.Forms.Button buttonHL7Report;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox tbFolderName;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox tbReportName;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox tbComment1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox tbLastName;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox tbFirstName;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox tbSex;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox tbPatientID;
		private System.Windows.Forms.DateTimePicker dateTimePickerDOB;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbMessageCode;
		private System.Windows.Forms.TextBox textBoxResults;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button buttonORMMsg;
		private System.Windows.Forms.TabPage tabPageADT;
		private System.Windows.Forms.Label lblADT_Type;
		private System.Windows.Forms.ComboBox cBoxChoose_ADT;
		private System.Windows.Forms.Button btnSendADT;
		private System.Windows.Forms.Label lblSendADT;
		private System.Windows.Forms.TextBox textBoxADTResult;
		private System.Windows.Forms.ComboBox cBoxPatientClass;
		private System.Windows.Forms.Label lblPatientClass;
		private System.Windows.Forms.TextBox tbAssignedRoomNumber;
		private System.Windows.Forms.Label lblAssignedRoomNumber;
		private System.Windows.Forms.Label lblAssignedTestSite;
		private System.Windows.Forms.TextBox tbAssignedTestSite;
		private System.Windows.Forms.Label lblNewPatID;
		private System.Windows.Forms.Label lblNewPatAcc;
		private System.Windows.Forms.TextBox tbNewPatAcc;
		private System.Windows.Forms.TextBox tbNewPatID;

	}
}

