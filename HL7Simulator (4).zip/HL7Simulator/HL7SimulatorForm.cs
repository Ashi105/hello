using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

using HL7Messaging;
using ManagedTWinData;
using ManagedTWinDAL;
using TwinMsgHandler;
using TwinPortalSettings;

namespace HL7Simulator
{
	public partial class HL7SimulatorForm : Form
	{
		private static TcpListener sTcpListener;
		private TwinAckHandler m_TwinAckHandler;

		public HL7SimulatorForm()
		{
			SvcSettingsMgr.TwinPortalNetwork tpNetwork = Program.sSvcSettingsMgr.SvcSettings.TwinPortalNetwork;
			IPAddress HISIPAddr = IPAddress.Parse(tpNetwork.HISIPAddress);

			// Start listening for connections on the configured HIS IP address and port.
			sTcpListener = new TcpListener(HISIPAddr, tpNetwork.HISPortNumber);
			sTcpListener.Start();

			// Initialize object for handling ack messages
			m_TwinAckHandler = new TwinAckHandler(this);
			m_TwinAckHandler.Init();

			sTcpListener.BeginAcceptTcpClient(ConnectionHandler, m_TwinAckHandler);
			InitializeComponent();
			cbHL7VersionNum.Text = "2.5";
			cBoxChoose_ADT.Text = "A01 ADMIT/VISIT NOTIFICATION";
			cBoxPatientClass.Text = "In-Patient";
			cbHL7ReportStatus.Text = "Pending";
		}

		string GetADTFlavor(string szSelection)
		{
			string szFlavour = null;
			switch (szSelection)
			{
				case "A01 ADMIT/VISIT NOTIFICATION":
					{
						szFlavour = "A01";
						break;
					}
				case "A04 REGISTER A PATIENT":
					{
						szFlavour = "A04";
						break;
					}
				case "A08 UPDATE PATIENT INFORMATION":
					{
						szFlavour = "A08";
						break;
					}
				case "A40 MERGE PATIENT INFORMATION":
					{
						szFlavour = "A40";
						break;
					}
				case "A18 MERGE PATIENT INFORMATION":
					{
						szFlavour = "A18";
						break;
					}
				case "A03 DISCHARGE/END VISIT":
					{
						szFlavour = "A03";
						break;
					}
				case "A13 CANCEL DISCHARGE/END VISIT":
					{
						szFlavour = "A13";
						break;
					}
				case "A31 UPDATE PERSON INFORMATION":
					{
						szFlavour = "A31";
						break;
					}
				case "A05 PRE-ADMIT A PATIENT":
					{
						szFlavour = "A05";
						break;
					}
				case "A11 CANCEL ADMIT/VISIT NOTIFICATION":
					{
						szFlavour = "A11";
						break;
					}
				case "A02 TRANSFER A PATIENT":
					{
						szFlavour = "A02";
						break;
					}
				case "A06 CHANGE AN OUTPATIENT TO AN INPATIENT":
					{
						szFlavour = "A06";
						break;
					}
				case "A07 CHANGE AN INPATIENT TO AN OUTPATIENT":
					{
						szFlavour = "A07";
						break;
					}
				case "A12 CANCEL TRANSFER":
					{
						szFlavour = "A12";
						break;
					}
			}
			return szFlavour;
		}

		private void buttonORMMsg_Click(object sender, EventArgs e)
		{
			ORMMsgData ORMMsgData = new ORMMsgData();
			ORMMsgData.MessageCode = tbMessageCode.Text;
			ORMMsgData.PatientID = tbPatientID.Text;
			ORMMsgData.Sex = tbSex.Text;
			ORMMsgData.DOB = dateTimePickerDOB.Value;
			ORMMsgData.ApptDateTime = new DateTime(dateTimePickerApptDate.Value.Year, dateTimePickerApptDate.Value.Month, dateTimePickerApptDate.Value.Day,
			dateTimePickerApptTime.Value.Hour, dateTimePickerApptTime.Value.Minute, dateTimePickerApptTime.Value.Second);
			ORMMsgData.FirstName = tbFirstName.Text;
			ORMMsgData.LastName = tbLastName.Text;
			ORMMsgData.OrderControl = rbNew.Checked  ?  "NW"  :  "CA";
			if (rbUpdate.Checked)
			{
				ORMMsgData.OrderControl = "XO";
			}
			ORMMsgData.TestSite = tbTestSite.Text;
			ORMMsgData.RoomNumber = tbRoomNumber.Text;
			ORMMsgData.ReferPhyFName = tbReferPhyFName.Text;
			ORMMsgData.ReferPhyLName = tbReferPhyLName.Text;
			ORMMsgData.PhyName = tbPhyName.Text;

			ORMMsgData.PatientAccountNumber = tbPatientAccount.Text; 
			ORMMsgData.OrderControlNumber = tbOrderControl.Text;
			ORMMsgData.OrderedCategory = tbOrderedCategory.Text;
			ORMMsgData.PatientVisitNumber = tbVisitNumber.Text;
			ORMMsgData.HospitalService = tbHospitalService.Text;
			ORMMsgData.DateOfService = new DateTime(dateTimePickerDateOfService.Value.Year, dateTimePickerDateOfService.Value.Month, dateTimePickerDateOfService.Value.Day);
			ORMMsgData.HL7VersionNumber = double.Parse(cbHL7VersionNum.Text);
			ORMMsgData.LLPCompliantORM = cbLLPCompliantORM.Checked;

			ORMMsgData.Comments = new List<string>();
			if (tbComment1.Text != string.Empty)
			{
				ORMMsgData.Comments.Add(tbComment1.Text);
			}

			if (tbComment2.Text != string.Empty)
			{
				ORMMsgData.Comments.Add(tbComment2.Text);
			}

			if (tbComment3.Text != string.Empty)
			{
				ORMMsgData.Comments.Add(tbComment3.Text);
			}

			if (tbComment4.Text != string.Empty)
			{
				ORMMsgData.Comments.Add(tbComment4.Text);
			}

			// Send message to Twin Portal
			HL7MsgSender msgSender = new HL7MsgSender(null, Program.sSvcSettingsMgr.SvcSettings);
			try
			{
				String strORMMsg;
				if (ORMMsgData.HL7VersionNumber == 2.5)
				{
					strORMMsg = msgSender.BuildORMMsgV25(ORMMsgData, cbValidateText.Checked);
				}
				else if (ORMMsgData.HL7VersionNumber == 2.3)
				{
					strORMMsg = msgSender.BuildORMMsgV23(ORMMsgData, cbValidateText.Checked);
				}
				else
				{
					strORMMsg = msgSender.BuildORMMsgV24(ORMMsgData, cbValidateText.Checked);
				}
				DisplayMessageSent(strORMMsg, "ORM");
				msgSender.SendTwinPortalMessage(strORMMsg);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to send ORM message due to the following error: \n" + ex.Message, "Failed to send ORM message", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void buttonORUMsg_Click(object sender, EventArgs e)
		{
			ORUMsgData ORUMsgData = new ORUMsgData();
			ORUMsgData.PatientID = tbPatientID.Text;
			ORUMsgData.Sex = tbSex.Text;
			ORUMsgData.DOB = dateTimePickerDOB.Value;
			ORUMsgData.FirstName = tbFirstName.Text;
			ORUMsgData.LastName = tbLastName.Text;
			ORUMsgData.ReportName = tbReportName.Text;
			ORUMsgData.ReportFolder = tbFolderName.Text;
			ORUMsgData.PatientAccountNumber = tbPatientAccount.Text;
			ORUMsgData.ReportDateTime = new DateTime(DateTime.Now.Ticks);
			ORUMsgData.HL7ReportStatus = cbHL7ReportStatus.Text;
			ORUMsgData.OrderControlNumber = tbOrderControl.Text;
			ORUMsgData.OrderedCategory = tbOrderedCategory.Text;
			ORUMsgData.HL7VersionNumber = double.Parse(cbHL7VersionNum.Text);
			ORUMsgData.DateOfService = new DateTime(dateTimePickerDateOfService.Value.Year, dateTimePickerDateOfService.Value.Month, dateTimePickerDateOfService.Value.Day);
			ORUMsgData.PhysicianName = tbPhyName.Text;
			ORUMsgData.PatientVisitNumber = tbVisitNumber.Text;
			ORUMsgData.EndDateOfService = ORUMsgData.DateOfService.AddHours(1);

			Dictionary<int, String> SummaryNarrativeList = new Dictionary<int, string>();
			
			if (tbNarrative1.Text != string.Empty)
			{
				SummaryNarrativeList.Add(1, tbNarrative1.Text);
			}

			if (tbNarrative2.Text != string.Empty)
			{
				SummaryNarrativeList.Add(2, tbNarrative2.Text);
			}

			if (tbNarrative3.Text != string.Empty)
			{
				SummaryNarrativeList.Add(3, tbNarrative3.Text);
			}

			if (tbNarrative4.Text != string.Empty)
			{
				SummaryNarrativeList.Add(4, tbNarrative4.Text);
			}

			if (tbNarrative5.Text != string.Empty)
			{
				SummaryNarrativeList.Add(5, tbNarrative5.Text);
			}

			if (tbNarrative6.Text != string.Empty)
			{
				SummaryNarrativeList.Add(6, tbNarrative6.Text);
			}

			if (tbNarrative7.Text != string.Empty)
			{
				SummaryNarrativeList.Add(7, tbNarrative7.Text);
			}

			ORUMsgData.SummaryNarrative = SummaryNarrativeList;

			HL7MsgSender msgSender = new HL7MsgSender(null, Program.sSvcSettingsMgr.SvcSettings);
			try
			{
				string strORUMsg;
				if (ORUMsgData.HL7VersionNumber == 2.5)
				{
					strORUMsg = msgSender.BuildORUMsgV25(ORUMsgData, cbValidateText.Checked);
				}
				else if (ORUMsgData.HL7VersionNumber == 2.3)
				{
					strORUMsg = msgSender.BuildORUMsgV23(ORUMsgData, cbValidateText.Checked);
				}
				else
				{
					strORUMsg = msgSender.BuildORUMsgV24(ORUMsgData, cbValidateText.Checked);
				}

				DisplayMessageSent(strORUMsg, "ORU");
				msgSender.SendTwinPortalMessage(strORUMsg);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to send ORU message due to the following error: \n" + ex.Message, "Failed to send ORU message", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void DisplayMessageSent(String msg, String szMsgType)
		{
			// Add a new line to CR for display purposes
			msg = msg.Replace("\r", "\r\n");
			if (szMsgType == "ADT")
				textBoxADTResult.Text = msg;
			else
				textBoxResults.Text = msg;
		}

		delegate void DisplayResultsDelegate(String results);

		public void DisplayResults(String results)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(new DisplayResultsDelegate(DisplayResults), new object[] { results });
			}
			else
			{
				textBoxResults.Text = results;
			}
		}


		public void DisplayMessageReceived(String msg)
		{
			// Add a new line to CR for display purposes
			msg = msg.Replace("\r", "\r\n");
			DisplayResults(msg);
		}

		private void buttonACK_Click(object sender, EventArgs e)
		{
			HL7MsgSender msgSender = new HL7MsgSender(null, Program.sSvcSettingsMgr.SvcSettings);
			msgSender.SendACK(tbMessageCode.Text, "AA"); // AA for accepted, AR for rejected
		}

		private static void ConnectionHandler(IAsyncResult result)
		{
			TcpClient tcpClient = null;

			try
			{
				// Get the TCP client that initiated the connection
				tcpClient = sTcpListener.EndAcceptTcpClient(result);
			}
			catch (Exception ex)
			{
				Program.sEventLog.WriteEntry("ConnectionHandler: " + ex.Message, EventLogEntryType.Error);
				// failed to accept connection 
				return;
			}

			// start listening for the next client connection
			sTcpListener.BeginAcceptTcpClient(ConnectionHandler, result.AsyncState);

			if (tcpClient != null)
			{
				// Handle client connections on a separate thread
				new HL7MsgReceiver(tcpClient, (TwinAckHandler)result.AsyncState, Program.sEventLog, Program.sSvcSettingsMgr.SvcSettings);
			}
		}

		delegate void ShowMessageDelegate(string message);

		public void ShowMessage(String message)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(new ShowMessageDelegate(ShowMessage), new object[] { message });
			}
			else
			{
				MessageBox.Show(message);
			}
		}

		private void btnSendADT_Click(object sender, EventArgs e)
		{
			ADTMsgData objADTMsgData = new ADTMsgData();
			objADTMsgData.MessageCode = tbMessageCode.Text;
			objADTMsgData.PatientID = tbPatientID.Text;
			objADTMsgData.Sex = tbSex.Text;
			objADTMsgData.DOB = dateTimePickerDOB.Value;
			objADTMsgData.FirstName = tbFirstName.Text;
			objADTMsgData.LastName = tbLastName.Text;
			objADTMsgData.ADTMessageType = cBoxChoose_ADT.Text;
			objADTMsgData.PatientClass = cBoxPatientClass.Text;

			objADTMsgData.TestSite = tbTestSite.Text;
			objADTMsgData.RoomNumber = tbRoomNumber.Text;
			objADTMsgData.AssignedTestSite = tbAssignedTestSite.Text;
			objADTMsgData.AssignedRoomNumber = tbAssignedRoomNumber.Text;
			objADTMsgData.ReferPhyFName = tbReferPhyFName.Text;
			objADTMsgData.ReferPhyLName = tbReferPhyLName.Text;
			objADTMsgData.PhyName = tbPhyName.Text;

			objADTMsgData.PatientAccountNumber = tbPatientAccount.Text;
			objADTMsgData.OrderControlNumber = tbOrderControl.Text;
			objADTMsgData.OrderedCategory = tbOrderedCategory.Text;
			objADTMsgData.PatientVisitNumber = tbVisitNumber.Text;
			objADTMsgData.HospitalService = tbHospitalService.Text;
			objADTMsgData.HL7VersionNumber = double.Parse(cbHL7VersionNum.Text);

			objADTMsgData.ADTFlavor = GetADTFlavor(objADTMsgData.ADTMessageType);
			objADTMsgData.NewPatientAccountNumber = tbNewPatAcc.Text;
			objADTMsgData.NewPatientID = tbNewPatID.Text;

			HL7MsgSender msgSender = new HL7MsgSender(null, Program.sSvcSettingsMgr.SvcSettings, objADTMsgData.ADTFlavor);

			try
			{
				String strADTMsg;
				if (objADTMsgData.HL7VersionNumber == 2.5)
				{
					strADTMsg = msgSender.BuildADTMsgV25(objADTMsgData, cbValidateText.Checked, objADTMsgData.ADTFlavor);
				}
				else if (objADTMsgData.HL7VersionNumber == 2.3)
				{
					strADTMsg = msgSender.BuildADTMsgV23(objADTMsgData, cbValidateText.Checked, objADTMsgData.ADTFlavor);
				}
				else
				{
					strADTMsg = msgSender.BuildADTMsgV24(objADTMsgData, cbValidateText.Checked, objADTMsgData.ADTFlavor);
				}
				DisplayMessageSent(strADTMsg, "ADT");
				msgSender.SendTwinPortalMessage(strADTMsg);
			}
			catch (Exception Ex)
			{
				MessageBox.Show("Failed to send ADT message due to the following error: \n" + Ex.Message, "Failed to send ADT message", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void cBoxChoose_ADT_SelectedValueChanged(object sender, EventArgs e)
		{
			tbAssignedRoomNumber.Enabled = false;
			tbAssignedTestSite.Enabled = false;
			tbNewPatAcc.Enabled = false;
			tbNewPatID.Enabled = false;
			cBoxPatientClass.Enabled = true;

			// Enable disable UI comonents based on selection
			if (cBoxChoose_ADT.Text == "A02 TRANSFER A PATIENT"  ||  cBoxChoose_ADT.Text == "A12 CANCEL TRANSFER")
			{
				tbAssignedRoomNumber.Enabled = true;
				tbAssignedTestSite.Enabled = true;
			}
			if (cBoxChoose_ADT.Text == "A18 MERGE PATIENT INFORMATION"  ||  cBoxChoose_ADT.Text == "A40 MERGE PATIENT INFORMATION")
			{
				tbNewPatAcc.Enabled = true;
				tbNewPatID.Enabled = true;
				cBoxPatientClass.Enabled = false;
			}
		}
	}
}
