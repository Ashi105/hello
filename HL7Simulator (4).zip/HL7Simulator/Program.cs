using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Windows.Forms;

using TwinPortalSettings;

namespace HL7Simulator
{
	static class Program
	{
		public static SvcSettingsMgr sSvcSettingsMgr;
		public static EventLog sEventLog;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			sSvcSettingsMgr = new SvcSettingsMgr();

			sEventLog = new EventLog("Twin Portal Service", System.Environment.MachineName, "Twin Portal Service");

			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new HL7SimulatorForm());
		}
	}
}