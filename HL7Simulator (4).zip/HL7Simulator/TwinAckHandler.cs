using System;
using System.Diagnostics;
using System.Windows.Forms;

using NHapi.Base.Parser;

using HL7Messaging;
using HL7Simulator;

namespace TwinMsgHandler
{
	class TwinAckHandler : ITwinMsgHandler
	{
		private HL7SimulatorForm m_HL7SimulatorForm;

		public TwinAckHandler(HL7SimulatorForm HL7SimulatorForm)
		{
			m_HL7SimulatorForm = HL7SimulatorForm;
		}

		public void Init()
		{
		}

		public int ReceivedORMMsg(ORMMsgData ormMsg)
		{
			// not handled here
			return 0;
		}

		public void ReceivedORUMsg(ORUMsgData oruMsg)
		{
			// not handled here
		}

		public bool ReceivedADTMsg(ADTMsgData adtMsg)
		{
			// not handled here
			return false;
		}

		public void ReceivedAck(ACKMsgData ACKMsgData)
		{
			if (ACKMsgData.AckCode == "AA")
			{
				m_HL7SimulatorForm.ShowMessage(String.Format("Received ACK for MessageCode = {0}", ACKMsgData.MessageCode));
			}
			else
			{
				if (ACKMsgData.AckCode == "AR")
				{
					m_HL7SimulatorForm.ShowMessage("Received Rejection!");
				}
			}
		}

	}
}
