﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Apache.NMS;
using Apache.NMS.ActiveMQ;
using Apache.NMS.ActiveMQ.Commands;
using Apache.NMS.Util;
using System.Threading;
using System.Threading.Tasks;
using Serilog;
using Serilog.Core;
using System.Collections.Concurrent;

namespace CommunicatorLib
{
    public class MessageReceivedEventArgs : EventArgs
    {
        public MessageReceivedEventArgs(string body,string topic)
        {
            Body = body;
            Topic = topic;
        }
        public string Topic { get; set; }
        public string Body { get; set; }
    }
    public class ActiveMQBroker : IMessageBroker, IDisposable
    {     
        private readonly IConnectionFactory connectionFactory = new Apache.NMS.ActiveMQ.ConnectionFactory();
        private IConnection connection;
        private ISession session;          
        //private IMessageConsumer consumer;       
        private readonly string client;
        private List<string> subTopics = new List<string>();
        private List<string> subTopicsNonDurable = new List<string>();
        private ConcurrentDictionary<string, IMessageProducer> producerList = new ConcurrentDictionary<string, IMessageProducer>();

        ActiveMQTopic topic;
        public event EventHandler MessageReceived;
        public event EventHandler CommunicationFailed;
        public event EventHandler CommunicationRestored;

        Thread PingThread;
        private bool isDisposed = false;      
        private bool isConnected = false;
        private bool isSessionCreated = false;
        
        public bool IsConnected()
        {           
            return isConnected;
        }
        public ActiveMQBroker(string clientID)
        {
            this.connection = connectionFactory.CreateConnection();
            this.connection.ConnectionInterruptedListener += Connection_ConnectionInterruptedListener;
            this.connection.ConnectionResumedListener += Connection_ConnectionResumedListener;           
            this.client = clientID;
        }

        public bool Connect()
        {
            var connectTask = Task.Factory.StartNew(() => ConnecAsync(),
                CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default);
            connectTask.Wait(TimeSpan.FromSeconds(2));
            return isConnected;
        }

        private async Task ConnecAsync()
        {         
            if (client != string.Empty)
                this.connection.ClientId = client;
            this.connection.Start();
            this.session = connection.CreateSession();            
            isSessionCreated = true;
            SubscribeToPendingTopics();
            //isConnected = true;
        }


        
        public IMessageProducer GetMessageProducer(string Topic)
        {
            if(producerList.Keys.Contains(Topic))
            {
                return producerList[Topic];
            }
            else
            {
                topic = new ActiveMQTopic(Topic);
                IMessageProducer producer = session.CreateProducer(topic);
                producerList.TryAdd(Topic, producer);
                return producer;
            }
        }
        public bool Publish(string Topic, string Message)
        {
            try
            {
                if (isConnected && isSessionCreated)
                {
                    //var _=PublishAsync(Topic, Message);                                                    
                    IMessageProducer producer = GetMessageProducer(Topic);                   
                    ITextMessage txtMessage = session.CreateTextMessage(Message);                    
                    //producer.DeliveryMode = MsgDeliveryMode.Persistent;                                  
                    producer.Send(txtMessage);                    
                    return true;
                }
                else
                    return false;
            }
            catch(Exception ex)
            {               
                return false;
            }            
        }

        private async Task PublishAsync(string Topic, string Message)
        {            
            IMessageProducer producer = GetMessageProducer(Topic);
            ITextMessage txtMessage = session.CreateTextMessage(Message);
            //producer.DeliveryMode = MsgDeliveryMode.Persistent;        
            producer.Send(txtMessage);          
        }

        public void Subscribe(params string[] Topics)
        {
            if (isConnected && isSessionCreated)
                Task.Factory.StartNew(() => SubscribeAsync(true, Topics));
            else
            {
                foreach (var topic in Topics)
                    subTopics.Add(topic);
            }
        }

        public void SubscribeAsNonDurable(params string[] Topics)
        {
            if (isConnected && isSessionCreated)
                Task.Factory.StartNew(() => SubscribeAsync(false, Topics));
            else
            {
                foreach (var topic in Topics)
                    subTopicsNonDurable.Add(topic);
            }
        }

        private async Task SubscribeAsync(bool isDurable, params string[] Topics)
        {
            IDestination dest;
            foreach (var Topic in Topics)
            {

                dest = session.GetTopic(Topic);
                IMessageConsumer consumer;
                if (isDurable)
                    consumer = session.CreateDurableConsumer(session.GetTopic(Topic), String.Concat(Topic, client), "2>1", false);
                else
                    consumer = session.CreateConsumer(dest);
                consumer.Listener += Consumer_Listener;
            }
        }

        private void Consumer_Listener(IMessage message)
        {
            
            if (message is ITextMessage)
            {               
                ITextMessage txtMsg = message as ITextMessage;
                string body = txtMsg.Text;
                string topic = message.NMSDestination.ToString().Split("//")[1].Replace("}", string.Empty);  //{topic://Testing}
                MessageReceived?.Invoke(this, new MessageReceivedEventArgs(txtMsg.Text, topic));
                message.Acknowledge();             
            }
            
        }
        private void Connection_ConnectionInterruptedListener()
        {            
            bool vals = this.connection.IsStarted;
            isConnected = false;            
            CommunicationFailed?.Invoke(this, EventArgs.Empty);
        }


        private void Connection_ConnectionResumedListener()
        {           
            bool vals = this.connection.IsStarted;
            isConnected = true;           

            CommunicationRestored?.Invoke(this, EventArgs.Empty);            
        }      
        
        public void SubscribeToPendingTopics()
        {
            if (subTopicsNonDurable.Count > 0)
            {
                SubscribeAsync(false, subTopicsNonDurable.ToArray());
                subTopicsNonDurable.Clear();
            }
            if (subTopics.Count > 0)
            {
                SubscribeAsync(true, subTopics.ToArray());
                subTopics.Clear();
            }
        }

        public void Dispose()
        {
            if (!this.isDisposed)
            {
                foreach(var item in producerList)
                {
                    item.Value.Close();
                }
                producerList = null;
                this.session.Close();                
                this.session.Dispose();
                this.connection.Dispose();
                this.isDisposed = true;
            }
        }
    }
}
