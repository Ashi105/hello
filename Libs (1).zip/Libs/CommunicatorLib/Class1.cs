﻿using System;

namespace CommunicatorLib
{
    public class Class1
    {
    }
}
