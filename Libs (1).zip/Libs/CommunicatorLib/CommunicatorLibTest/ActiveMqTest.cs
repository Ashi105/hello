
using CommunicatorLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text;
using System.Threading;
using UCP.Common.Utilities.MQHelper;

namespace CommunicatorLibTest
{
    [TestClass]
    public class ActiveMqTest
    {

        IMessageBroker messageBroker;
        string MSID = "CommunicatorLib";
        BlockingCollection<MessageReceivedEventArgs> collection = new BlockingCollection<MessageReceivedEventArgs>();

        [TestInitialize]
        public void Setup()
        {
            messageBroker = new ActiveMQBroker(MSID);
            messageBroker.Connect();
        }
        [TestMethod]
        public void ActiveMqPublishTest()
        {
            bool published = false;
            Messages message;
            string json = "";
            string topic = "SendData";
            string path = AppDomain.CurrentDomain.BaseDirectory + "JsonData.json";
            using (StreamReader sr = new StreamReader(path))
            {
                json = sr.ReadToEnd();
            }
            byte[] toEncodeAsBytes = ASCIIEncoding.ASCII.GetBytes(json);
            message = new Messages() { Key = "DataReceived", Value = Convert.ToBase64String(toEncodeAsBytes) };
            string corelationID = MessageFormat.GetInstance().CreateRelationID(message, MSID);
            published = messageBroker.Publish(topic, corelationID);

            ActiveMqSubScribe();
            string receivedMsg = ReceivedData();
            if (receivedMsg != null)
            {
                published = true;
            }
            Assert.AreEqual(true, published);

        }


        public void ActiveMqSubScribe()
        {
            messageBroker.MessageReceived += MessageBroker_MessageReceived;
            messageBroker.Subscribe("SendData");

        }

        private void MessageBroker_MessageReceived(object sender, EventArgs e)
        {
            var mesg = (MessageReceivedEventArgs)e;
            collection.Add(mesg);
        }
        public string ReceivedData()
        {
            var data = collection.Take();
            return data.ToString();
        }

    }
}
