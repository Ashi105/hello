﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommunicatorLibTest
{
    public class Messages
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
