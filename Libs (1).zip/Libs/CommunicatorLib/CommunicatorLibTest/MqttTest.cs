﻿using CommunicatorLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using UCP.Common.Utilities.MQHelper;

namespace CommunicatorLibTest
{
    [TestClass]
    public  class MqttTest
    {

        IMessageBroker messageBroker;
  
        string IP = "localhost";
        BlockingCollection<MessageReceivedEventArgs> collection = new BlockingCollection<MessageReceivedEventArgs>();

        [TestInitialize]
        public void Setup()
        {
            messageBroker = new MQTTBroker(IP);
            messageBroker.Connect();
        }
        [TestMethod]
        public void MqttPublishTest()
        {
            bool published = false;
            Messages message;
            string json = "";
            string topic = "SendData";
            string path = AppDomain.CurrentDomain.BaseDirectory + "JsonData.json";
            using (StreamReader sr = new StreamReader(path))
            {
                json = sr.ReadToEnd();
            }
            byte[] toEncodeAsBytes = ASCIIEncoding.ASCII.GetBytes(json);
            message = new Messages() { Key = "DataReceived", Value = Convert.ToBase64String(toEncodeAsBytes) };
            string corelationID = MessageFormat.GetInstance().CreateRelationID(message, IP);

            published = messageBroker.Publish(topic, corelationID);

            MqttSubScribe();
            string receivedMsg = ReceivedData();
            if (receivedMsg != null)
            {
                published = true;
            }
            Assert.AreEqual(true, published);

        }

        public void MqttSubScribe()
        {
            messageBroker.MessageReceived += MessageBroker_MessageReceived;
            messageBroker.Subscribe("SendData");

        }
        private void MessageBroker_MessageReceived(object sender, EventArgs e)
        {
            var mesg = (MessageReceivedEventArgs)e;
            collection.Add(mesg);
        }
        public string ReceivedData()
        {
            var data = collection.Take();
            return data.ToString();
        }

    }
}

