﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CommunicatorLib
{
    public interface IMessageBroker:IDisposable
    {
        event EventHandler MessageReceived;
        event EventHandler CommunicationFailed;
        event EventHandler CommunicationRestored;
        bool Connect();
        bool Publish(string Topic,string Message);
        void Subscribe(params string[] Topic);
        void SubscribeAsNonDurable(params string[] Topic);
        bool IsConnected();
    }
}
