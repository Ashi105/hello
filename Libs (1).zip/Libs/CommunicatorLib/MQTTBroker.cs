﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Mqtt;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CommunicatorLib
{
    public class MQTTBroker : IMessageBroker, IDisposable
    {
        private IMqttClient mqttClient;
        private SessionState sessionState;
        private bool isDisposed = false;
        private bool isConnected = false;
        private string ipAddress = "localhost";
        private bool isThreadRunning = false; 

        public event EventHandler MessageReceived;
        public event EventHandler CommunicationFailed;
        public event EventHandler CommunicationRestored;

        Thread PingThread;

        public MQTTBroker(string MQTTIP)
        {
            ipAddress = MQTTIP;            
        }
        public bool Connect()
        {
            isConnected = ConnectToServer(ipAddress);
            PingThread = new Thread(PingToMessageBroker);
            if (!isConnected)
            {
                CommunicationFailed?.Invoke(this, new EventArgs());
                PingThread.Start();
                isThreadRunning = true;
            }
            return isConnected;
        }

        public bool IsConnected()
        {
            return isConnected;
        }

        public bool ConnectToServer(string MQTTIP)
        {
            try
            {
                mqttClient = MqttClient.CreateAsync(MQTTIP).Result;
                sessionState = mqttClient.ConnectAsync().Result;
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Publish(string Topic, string Message)
        {
            if (isConnected)
            {
                try
                {
                    var data = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(Message));
                    mqttClient.PublishAsync(new MqttApplicationMessage(Topic, data), MqttQualityOfService.ExactlyOnce).Wait();
                    return true;
                }
                catch
                {
                    isConnected = false;
                    CommunicationFailed?.Invoke(this, new EventArgs());
                    if (!isThreadRunning)
                    {
                        isThreadRunning = true;
                        PingThread.Start();
                    }
                    return false;
                }
            }
            else
                return false;

        }
        public void Subscribe(params string[] Topics)
        {
            if (isConnected)
            {
                foreach (var Topic in Topics)
                {
                    mqttClient.SubscribeAsync(Topic, MqttQualityOfService.ExactlyOnce);
                    mqttClient.MessageStream.Subscribe(msg =>
                    {
                        string values = JsonConvert.DeserializeObject<string>(Encoding.UTF8.GetString(msg.Payload));
                        MessageReceived?.Invoke(this, new MessageReceivedEventArgs(values, msg.Topic));
                    });
                }
            }
            
        }


        /// <summary>
        /// Not implemented 
        /// </summary>
        /// <param name="Topics"></param>
        public void SubscribeAsNonDurable(params string[] Topics)
        {
            
        }

        public void PingToMessageBroker()
        {
            while (isThreadRunning)
            {
                try
                {
                    string Topic = "Testing";
                    string Messages = "Testing";
                    if (ConnectToServer(ipAddress))
                    {
                        var data = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(Messages));
                        mqttClient.PublishAsync(new MqttApplicationMessage(Topic, data), MqttQualityOfService.ExactlyOnce).Wait();
                        isThreadRunning = false;
                        isConnected = true;
                        CommunicationRestored?.Invoke(this, new EventArgs());
                    }

                }
                catch(Exception ex)
                {
                    //Will retry on error so handling error
                }
            }
        }


        public void Dispose()
        {
            if (!this.isDisposed)
            {
                this.mqttClient.DisconnectAsync();
                this.mqttClient.Dispose();
                this.isDisposed = true;
            }
        }
    }
}
