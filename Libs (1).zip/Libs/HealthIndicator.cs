﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace ProConnectAddOn.Model
{
   public class HealthIndicator {

    private static object obj = new object();
    private static HealthIndicator mInstance = null;
    public string SERVICE_NAME = Assembly.GetEntryAssembly().GetName().Name;
    public int SERVICE_STARTED { get; set; }
    public int SERVICE_RUNNING { get; set; }
    //public int SERVICE_STOPED { get; set; }
    public int SERVICE_ERROR { get; set; }
    public int SERVICE_FAULT { get; set; }
    public string HealthRemark { get; set; }



    private HealthIndicator()
    {
    }
    /// <summary>
    /// Returns singleton instance to DeviceInterfaceClient
    /// </summary>
    /// <returns></returns>
    public static HealthIndicator GetInstance()
    {
        lock (obj)
        {
            if (mInstance == null)
            {
                mInstance = new HealthIndicator();
            }
        }
        return mInstance;
    }

}
}
