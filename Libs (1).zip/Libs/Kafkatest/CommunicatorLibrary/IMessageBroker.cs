﻿using System;

namespace CommunicatorLibrary
{
    public interface IMessageBroker:IDisposable
    {
        event EventHandler MessageReceived;

        bool Connect();
        bool Publish(string Topic, string key, string Message);
        bool Publish(string Topic, string Message);

        void Subscribe(params string[] Topic);
    }
}
