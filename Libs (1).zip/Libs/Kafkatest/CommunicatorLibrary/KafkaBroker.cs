﻿using Confluent.Kafka;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CommunicatorLibrary
{
    public class MessageReceivedEventArgs : EventArgs
    {
        public MessageReceivedEventArgs(string message, string topic)
        {
            Message = message;
            Topic = topic;
        }
        public string Topic { get; set; }
        public string Message { get; set; }
    }
    public class KafkaBroker: IMessageBroker
    {
        private readonly string DEFAULT_BOOTSTRAP_SERVER = "localhost:9092";
        private ProducerConfig producerConfig;
        private IProducer<string,string> producer;
        private IConsumer<Ignore, string> consumer;
        private CancellationTokenSource cancellationToken = new CancellationTokenSource();
        private Task ConsumerTask;


        public event EventHandler MessageReceived;
        /// <summary>
        /// IP address and port number: default = localhost:9092
        /// </summary>
        /// <param name="BootstrapServer"></param>
        public KafkaBroker(string BootstrapServer)
        {
            if (!string.IsNullOrEmpty(BootstrapServer))
                DEFAULT_BOOTSTRAP_SERVER = BootstrapServer;
        }

        public bool Connect()
        {
            //try
            //{
            producerConfig = new ProducerConfig { BootstrapServers = DEFAULT_BOOTSTRAP_SERVER };
            producer = new ProducerBuilder<string, string>(producerConfig).Build();           
    
            //}
            //catch
            //{
            //    return false;
            //}
            return true;
        }

        private async Task PublishToBroker(string topic, Message<string, string> message)
        {
            if(producerConfig==null)
            {

            }
            // Note: Awaiting the asynchronous produce request below prevents flow of execution
            // from proceeding until the acknowledgement from the broker is received (at the 
            // expense of low throughput).
            var deliveryReport = await producer.ProduceAsync(
                topic, message);
        }
      
        public bool Publish(string topic, string key, string Message)
        {
            var _=PublishToBroker(topic, new Message<string, string> { Key = key, Value = Message });
            return true;
        }

        public bool Publish(string topic, string Message)
        {
            var _ = PublishToBroker(topic, new Message<string, string> { Key = string.Empty, Value = Message });
            return true;
        }

        public void Subscribe(params string[] topics)
        {
            if (consumer == null)
            {
                var config = new ConsumerConfig
                {
                    BootstrapServers = DEFAULT_BOOTSTRAP_SERVER,
                    GroupId = "csharp-consumer",
                    EnableAutoCommit = false,
                    StatisticsIntervalMs = 5000,
                    SessionTimeoutMs = 6000,
                    AutoOffsetReset = AutoOffsetReset.Earliest,
                    EnablePartitionEof = true
                };

                //var consumer = new ConsumerBuilder<Ignore, string>(config).Build();
                // To enable error 
                consumer = new ConsumerBuilder<Ignore, string>(config).
                    SetErrorHandler((_, e) => Console.WriteLine($"Error: {e.Reason}")).Build();                
            }            
            consumer.Subscribe(topics);

            if (ConsumerTask == null)
                ConsumerTask = Task.Factory.StartNew(() => RunConsumer());
        }

        private void RunConsumer()
        {
            const int commitPeriod = 1;
            while (true)
            {
                var consumeResult = consumer.Consume(cancellationToken.Token);
                if (consumeResult.IsPartitionEOF)
                {
                    //Console.WriteLine(
                    //    $"Reached end of topic {consumeResult.Topic}, partition {consumeResult.Partition}, offset {consumeResult.Offset}.");

                    continue;
                }

                //Console.WriteLine($"Received message at {consumeResult.TopicPartitionOffset}: {consumeResult.Value}");
                MessageReceived?.Invoke(this, new MessageReceivedEventArgs(consumeResult.Value, consumeResult.Topic));
                //if (consumeResult.Offset % commitPeriod == 0)
                //{
                // The Commit method sends a "commit offsets" request to the Kafka
                // cluster and synchronously waits for the response. This is very
                // slow compared to the rate at which the consumer is capable of
                // consuming messages. A high performance application will typically
                // commit offsets relatively infrequently and be designed handle
                // duplicate messages in the event of failure.
                try
                    {
                        consumer.Commit(consumeResult);
                    }
                    catch (KafkaException e)
                    {
                        Console.WriteLine($"Commit error: {e.Error.Reason}");
                    }
                //}
            }
        }

        public void Dispose()
        {
            cancellationToken.Cancel();
            if (consumer != null)
            {
                consumer.Close();
                consumer.Dispose();            
            }

            if (producer != null)
            {              
                producer.Dispose();
            }
            //throw new NotImplementedException();
        }
    }
}
