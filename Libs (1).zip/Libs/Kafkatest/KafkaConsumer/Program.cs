﻿using CommunicatorLibrary;
using System;

namespace KafkaConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kafka Consumer!");
            IMessageBroker messageBroker = new KafkaBroker("localhost:9092");
            messageBroker.MessageReceived += MessageBroker_MessageReceived;
            while(true)
            {
                Console.WriteLine("Enter Topic to Subscribe: ");
                string topic = Console.ReadLine();
                messageBroker.Subscribe(topic);
            }
        }

        private static void MessageBroker_MessageReceived(object sender, EventArgs e)
        {
            var mesg = (MessageReceivedEventArgs)e;
            Console.WriteLine("Consumer Message - Topic: {0} - Message :{1}", mesg.Topic, mesg.Message);
            //throw new NotImplementedException();
        }
    }
}
