﻿using CommunicatorLibrary;
using Confluent.Kafka;
using System;

namespace Kafkatest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Kafka Producer!");
            IMessageBroker messageBroker = new KafkaBroker("localhost:9092");

            //Control + C to cancel 
            //Console.CancelKeyPress += (_, e) => {
            //    e.Cancel = true; // prevent the process from terminating.
            //    messageBroker.Dispose();
            //};

            messageBroker.Connect();
            while(true)
            {
                Console.WriteLine("Enter Topic to Publish:");
                string topic = Console.ReadLine();
                Console.WriteLine("Enter Message to Publish on topic :{0}",topic);
                string message = Console.ReadLine();
                messageBroker.Publish(topic, message);
            }

        }
    }
}
