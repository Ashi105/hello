﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace UCP.Common.Utilities.AppConfiguration
{
    public  class AppSettingsLogger
    {       
        IConfigurationRoot configuration;
        public AppSettingsLogger()
        {
            try
            {
                var builder = new ConfigurationBuilder()
             .SetBasePath(Directory.GetCurrentDirectory())
             .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                configuration = builder.Build();
               // Console.WriteLine("Appsettings Read success");
            }
            catch(Exception ex)
            {
                //Console.WriteLine("Appsettings Exception {0}", ex.ToString());
            }
        }        

        public int GetMinLogLevel()
        {
            int defaultValue = 2;
            try
            {
                string value = GetKeysValue("MinLevelLoging");
                defaultValue= string.IsNullOrEmpty(value) ? defaultValue : Convert.ToInt32(value);
            }catch
            {

            }
            return defaultValue;
        }

      
        public bool IsEnableActiveMq()
        {
            bool defaultValue = true;
            try
            {
                string value = GetKeysValue("EnableActivemq");
                defaultValue = string.IsNullOrEmpty(value) ? defaultValue : Convert.ToBoolean(value);
            }
            catch
            {

            }
            return defaultValue;            
        }

       

        public string GetBaseDataFolder()
        {
            return configuration.GetSection("BASE_DATA_FOLDER").Value;
        }

        public string GetDataSource()
        {
            string connectionString = configuration.GetSection("ConnectionString").Value;
            if (!connectionString.Contains("Data Source"))
                connectionString = "Data Source=" + Directory.GetCurrentDirectory() + "\\DB\\" + connectionString;
            return connectionString;
        } 

        public string GetLogLocation(string MSID)
        {
            try
            {
                string value = GetKeysValue("LogFile");
                //Console.WriteLine("Location is :{0}", value);
                if (string.IsNullOrEmpty(value))
                {
                    return Path.Combine("Log", MSID + ".log");
                }
                else
                {
#if NET35 || NET40
			if (Environment.OSVersion.Platform==PlatformID.Unix)
#else
                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
#endif
                    {
                        if (value.Contains(@"\"))
                            value = value.Replace(@"\", @"/");

                        //Console.WriteLine("Linux");
                    }
                    else
                    {
                        if (value.Contains(@"/"))
                            value = value.Replace(@"/", @"\");
                        //Console.WriteLine("Windows");
                    }
                    return value;
                }
            }
            catch(Exception ex)
            {
                //Console.WriteLine("Logger Exception {0}", ex.ToString());
                return Path.Combine("Log", MSID + ".log");
            }
           // return configuration.GetSection("LogFile").Value;
        }

        public string GetAPIUrl()
        {
            return configuration.GetSection("API_Url").Value;
        }

        public string GetCycleFileAPI()
        {
            return configuration.GetSection("Cycle_File_API_EndPoint").Value;
        }

        public string GetPingAPI()
        {
            return configuration.GetSection("Ping_API_EndPoint").Value;
        }

        public bool IsDataRedundancyEnabled()
        {
            return Convert.ToBoolean(configuration.GetSection("Enable_Data_Redundancy").Value);
        }

        public bool IsRestrictAnalogData()
        {
            return Convert.ToBoolean(configuration.GetSection("Restrict_Analog_Data").Value);
        }

        public bool DoesOSLinux()
        {
            return Convert.ToBoolean(configuration.GetSection("Is_Linux_OS").Value);
        }

        public string PortDetails()
        {
            if (DoesOSLinux())
                return configuration.GetSection("Linux_Port").Value;
            else
                return configuration.GetSection("Windows_Port").Value;

        }

        public bool DoesRabbitMQEnabled()
        {
            return Convert.ToBoolean(configuration.GetSection("Enable_RabbitMQ").Value);
        }

        public string GetQueueDataSource()
        {
            return configuration.GetSection("BackUpDBConnectionString").Value;
        }

        public string GetKeysValue(string Keys)
        {
            return configuration.GetSection(Keys).Value;
        }

    }
}
