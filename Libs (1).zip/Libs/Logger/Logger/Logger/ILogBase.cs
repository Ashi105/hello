﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger
{
    interface ILogBase
    {

        void Debug(string messageTemplate);
        void Debug(string messageTemplate, params object[] propertyValues);
        void Debug(Exception exception, string messageTemplate);
        void Debug(Exception exception, string messageTemplate, params object[] propertyValues);
        void Error(string messageTemplate);
        void Error(string messageTemplate, params object[] propertyValues);
        void Error(Exception exception, string messageTemplate);
        void Error(Exception exception, string messageTemplate, params object[] propertyValues);        
        void Fatal(string messageTemplate);
        void Fatal(string messageTemplate, params object[] propertyValues);
        void Fatal(Exception exception, string messageTemplate);
        void Fatal(Exception exception, string messageTemplate, params object[] propertyValues);


        void Information(string messageTemplate);


        void Information(string messageTemplate, params object[] propertyValues);

        void Information(Exception exception, string messageTemplate);
       

         void Information<T>(Exception exception, string messageTemplate, T propertyValue)
        {
            
        }

         void Information<T0, T1>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Information<T0, T1, T2>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Information(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            
        }

         bool IsEnabled(LogEventLevel level)
        {
            
        }

         void Verbose(string messageTemplate)
        {
            
        }

         void Verbose<T>(string messageTemplate, T propertyValue)
        {
            
        }

         void Verbose<T0, T1>(string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Verbose<T0, T1, T2>(string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Verbose(string messageTemplate, params object[] propertyValues)
        {
            
        }

         void Verbose(Exception exception, string messageTemplate)
        {
            
        }

         void Verbose<T>(Exception exception, string messageTemplate, T propertyValue)
        {
            
        }

         void Verbose<T0, T1>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Verbose<T0, T1, T2>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Verbose(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            
        }

         void Warning(string messageTemplate)
        {
            
        }

         void Warning<T>(string messageTemplate, T propertyValue)
        {
            
        }

         void Warning<T0, T1>(string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Warning<T0, T1, T2>(string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Warning(string messageTemplate, params object[] propertyValues)
        {
            
        }

         void Warning(Exception exception, string messageTemplate)
        {
            
        }

         void Warning<T>(Exception exception, string messageTemplate, T propertyValue)
        {
            
        }

         void Warning<T0, T1>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Warning<T0, T1, T2>(Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Warning(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            
        }

         void Write(LogEvent logEvent)
        {
            
        }

         void Write(LogEventLevel level, string messageTemplate)
        {
            
        }

         void Write<T>(LogEventLevel level, string messageTemplate, T propertyValue)
        {
            
        }

         void Write<T0, T1>(LogEventLevel level, string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Write<T0, T1, T2>(LogEventLevel level, string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Write(LogEventLevel level, string messageTemplate, params object[] propertyValues)
        {
            
        }

         void Write(LogEventLevel level, Exception exception, string messageTemplate)
        {
            
        }

         void Write<T>(LogEventLevel level, Exception exception, string messageTemplate, T propertyValue)
        {
            
        }

         void Write<T0, T1>(LogEventLevel level, Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1)
        {
            
        }

         void Write<T0, T1, T2>(LogEventLevel level, Exception exception, string messageTemplate, T0 propertyValue0, T1 propertyValue1, T2 propertyValue2)
        {
            
        }

         void Write(LogEventLevel level, Exception exception, string messageTemplate, params object[] propertyValues)
        {
            
        }
    }
}
