﻿using Serilog;
using Serilog.Core;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace LoggerLib
{
    public class Logger
    {
        ILogger mLogger;
        string type;
        public Logger(Type logger)
        {
            mLogger = Log.Logger;
            type = logger.FullName;
        }

        internal string AppendMSID(string messageTemp)
        {
            return "(" + UCPSeriLog.MSID + " - "+ type+") - " + messageTemp;
        }           

        public void Debug(string messageTemplate)
        {
            mLogger.Debug(AppendMSID(messageTemplate));
        }        

        public void Debug(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Debug(AppendMSID(messageTemplate), propertyValues);
        }

        public void Debug(Exception exception, string messageTemplate)
        {
            mLogger.Debug(exception, AppendMSID(messageTemplate));
        }      

        public void Debug(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Debug(exception, AppendMSID(messageTemplate), propertyValues);
        }         

        public void Verbose(string messageTemplate)
        {
            mLogger.Verbose(AppendMSID(messageTemplate));
        }


        public void Verbose(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Verbose(AppendMSID(messageTemplate), propertyValues);
        }

        public void Verbose(Exception exception, string messageTemplate)
        {
            mLogger.Verbose(exception, AppendMSID(messageTemplate));
        }

        public void Verbose(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Verbose(exception, AppendMSID(messageTemplate), propertyValues);
        }        

        public void Write(LogEvent logEvent)
        {
            mLogger.Write(logEvent);
        }

        public void Write(LogEventLevel level, string messageTemplate)
        {
            mLogger.Write(level, AppendMSID(messageTemplate));
        }

        public void Write(LogEventLevel level, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Write(level, AppendMSID(messageTemplate), propertyValues);
        }

        public void Write(LogEventLevel level, Exception exception, string messageTemplate)
        {
            mLogger.Write(level, exception, AppendMSID(messageTemplate));
        }

        public void Write(LogEventLevel level, Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Write(level, exception, AppendMSID(messageTemplate), propertyValues);
        }


        #region Log and ActiveMQ
        public void Error(string messageTemplate)
        {
            mLogger.Error(AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Error, null, messageTemplate, null);
        }
        public void Error(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Error(AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Error, null, messageTemplate, propertyValues);
        }
        public void Error(Exception exception, string messageTemplate)
        {
            mLogger.Error(exception, AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Error, exception, messageTemplate, null);
        }
        public void Error(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Error(exception, AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Error, exception, messageTemplate, propertyValues);
        }

        public void Warning(string messageTemplate)
        {
            mLogger.Warning(AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Warning, null, messageTemplate, null);

        }

        public void Warning(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Warning(AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Warning, null, messageTemplate, propertyValues);
        }

        public void Warning(Exception exception, string messageTemplate)
        {
            mLogger.Warning(exception, AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Warning, exception, messageTemplate, null);
        }

        public void Warning(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Warning(exception, AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Warning, exception, messageTemplate, propertyValues);
        }

        public void Fatal(string messageTemplate)
        {
            mLogger.Fatal(AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Fatal, null, messageTemplate, null);
        }

        public void Fatal(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Fatal(AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Fatal, null, messageTemplate, propertyValues);
        }

        public void Fatal(Exception exception, string messageTemplate)
        {
            mLogger.Fatal(exception, AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Fatal, exception, messageTemplate, null);
        }

        public void Information(string messageTemplate)
        {
            mLogger.Information(AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Information, null, messageTemplate, null);
        }

        public void Information(string messageTemplate, params object[] propertyValues)
        {
            mLogger.Information(AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Information, null, messageTemplate, propertyValues);
        }

        public void Information(Exception exception, string messageTemplate)
        {
            mLogger.Information(exception, AppendMSID(messageTemplate));
            PublishToActiveMQ(LogEventLevel.Information, exception, messageTemplate, null);
        }

        public void Information(Exception exception, string messageTemplate, params object[] propertyValues)
        {
            mLogger.Information(exception, AppendMSID(messageTemplate), propertyValues);
            PublishToActiveMQ(LogEventLevel.Information,exception, messageTemplate, propertyValues);
        }

        private void PublishToActiveMQ(LogEventLevel logLevel,Exception exception, string messageTemplate, params object[] propertyValues)
        {
            string message = messageTemplate;
            string[] propertyMesg;
            if (exception != null)
                message = message + exception.ToString();
            if (propertyValues != null && propertyValues.Count() > 0)
            {
                if (propertyValues[0].GetType().ToString().Contains("System"))
                {
                    propertyMesg = new string[propertyValues.Count()];
                    for (int i = 0; i < propertyValues.Count(); i++)
                    {
                        propertyMesg[i] = propertyValues[i].ToString();
                    }
                    message = string.Format(message, propertyMesg);
                }
                else
                {
                    propertyMesg = ReadProperty(propertyValues);
                    if (propertyMesg != null)
                        message = string.Format(message, propertyMesg);
                    else
                        message = string.Format(message, propertyValues);
                }
            }
            message = "{" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff zzz") + "} { " + logLevel.ToString() + "} " + AppendMSID(message);
            UCPSeriLog.PublishToActiveMQ(message);

        }

        private string[] ReadProperty(params object[] propertyValues)
        {
            string[] desriptionMessage = new string[propertyValues.Count()];
            try
            {               
                for (int i= 0;i<propertyValues.Count();i++)
                {
                    object item = propertyValues[i];
                    string message = "";
                    foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(item))
                    {
                        string name = descriptor.Name;
                        if (message != "")
                            message = message + ", ";
                        message = message + name + " - " + descriptor.GetValue(item);
                    }
                    desriptionMessage[i] = message;
                }
            }
            catch
            {
                return null;
            }

            return desriptionMessage;
        }


        #endregion
    }

    
}
