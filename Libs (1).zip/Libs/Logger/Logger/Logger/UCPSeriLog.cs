﻿using CommunicatorLib;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Core;
using Serilog.Formatting.Display;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UCP.Common.Utilities.AppConfiguration;

namespace LoggerLib
{
    public class UCPSeriLog
    {
        internal static string MSID;
        private static IMessageBroker messageBroker;
        private static bool isActivmqEnabled=true;
        static AppSettingsLogger AppSettingsLogger = new AppSettingsLogger();
        public static void LoggerConfigurations(string msid)
        {
            MSID = msid;
            isActivmqEnabled = AppSettingsLogger.IsEnableActiveMq();
            if (messageBroker == null && isActivmqEnabled)
            {               
                messageBroker = new ActiveMQBroker(MSID + "Logger");
                messageBroker.Connect();
            }
            var levelSwitch = new LoggingLevelSwitch();
            levelSwitch.MinimumLevel = (Serilog.Events.LogEventLevel)AppSettingsLogger.GetMinLogLevel();

            string outputTemplated = "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level}] {Message}{NewLine}{Exception}";
            var formatter = new MessageTemplateTextFormatter(outputTemplated, CultureInfo.InvariantCulture);
            string logPath = AppSettingsLogger.GetLogLocation(msid);
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File(path: logPath,
                rollOnFileSizeLimit: true, fileSizeLimitBytes: 10000,
                retainedFileCountLimit: 10, outputTemplate: outputTemplated).MinimumLevel.ControlledBy(levelSwitch)
                .CreateLogger();
          
        }

        internal static void PublishToActiveMQ(string logMessage)
        {
            if (isActivmqEnabled)
                messageBroker.Publish("Log", logMessage);
        }
    }
}
