﻿using System;
using System.Collections.Generic;
using System.Text;
using LoggerLib;
using Serilog;

namespace TestApplication
{
    public  class TestProperties
    {
        public string Serivece { get; set; }
        public string RawData { get; set; }
        public Status State { get; set; }
    }
    public enum Status
    {
        Start=0,
        Running=1,
        Stopped=2
    }
    public class ConsoleBusMonitor
    {
        Logger mlogger = new Logger(typeof(ConsoleBusMonitor));
        public void Start()
        {            
            mlogger.Debug("Befroe Assign Contest");           
            mlogger.Debug("After Assign Contest");
            mlogger.Error("ErrorHandling");
            mlogger.Error("Error With Properties -{0} - Test","ProperyValue");
            mlogger.Information("Information With Properties -{0} - Test", "ProperyValue");
            TestProperties testProperties = new TestProperties() { RawData = "Raw1", Serivece = "service Started", State = Status.Running };
            mlogger.Fatal("Error With Properties -{0} - Test", testProperties);

        }
    }

    public class ConsoleBusProcess
    {
        Logger mlogger = new Logger(typeof(ConsoleBusProcess));
        public void Start()
        {
            mlogger.Debug("Befroe Assign Contest");
            mlogger.Debug("After Assign Contest");
            mlogger.Error("ErrorHandling");
            mlogger.Error("Error With Properties -{0} - Test", "ProperyValue");
            mlogger.Information("Information With Properties -{0} - Test", "ProperyValue");
            TestProperties testProperties = new TestProperties() { RawData = "Raw1", Serivece = "service Started", State = Status.Running };
            mlogger.Fatal("Error With Properties -{0} - Test", testProperties);
        }
    }
}
