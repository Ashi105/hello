﻿using LoggerLib;
using Serilog;
using System;
using UCP.Common.Utilities.AppConfiguration;

namespace TestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string MSID = Guid.NewGuid().ToString();
            AppSettingsLogger appsettinngsLog = new AppSettingsLogger();
            int minLogLevel = appsettinngsLog.GetMinLogLevel();
            bool enable = appsettinngsLog.IsEnableActiveMq();
            UCPSeriLog.LoggerConfigurations(MSID);
            ConsoleBusMonitor consoleBusMonitor = new ConsoleBusMonitor();
            consoleBusMonitor.Start();
            ConsoleBusProcess consoleBusProcess = new ConsoleBusProcess();
            consoleBusProcess.Start();
            Console.WriteLine("Hello World!");
        }
    }
}
