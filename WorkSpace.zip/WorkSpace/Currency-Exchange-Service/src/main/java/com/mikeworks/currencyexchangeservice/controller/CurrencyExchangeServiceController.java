package com.mikeworks.currencyexchangeservice.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mikeworks.currencyexchangeservice.bean.ExchangeValue;

@RestController
public class CurrencyExchangeServiceController {

	@Autowired
	private Environment environment;  
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	public ExchangeValue retrieveExchangeValue(@PathVariable String from , @PathVariable String to) {

		BigDecimal  conversionMultiple=BigDecimal.valueOf(0);
		switch (from) {
		case "USD":
			conversionMultiple=BigDecimal.valueOf(65);
			break;
		case "EURO":
			conversionMultiple=BigDecimal.valueOf(75);			
			break;
		case "POUND":
			conversionMultiple=BigDecimal.valueOf(85);			
			break;
		default:
			break;
		}
		
		ExchangeValue exchangeValue= new ExchangeValue(1L,from,to,conversionMultiple);
		
		//exchangeValue.setPort(8000);
		exchangeValue.setPort(Integer.valueOf(environment.getProperty("local.server.port")));
		return exchangeValue;
	}
}
