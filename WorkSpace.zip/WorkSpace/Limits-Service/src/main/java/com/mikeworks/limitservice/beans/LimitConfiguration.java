package com.mikeworks.limitservice.beans;

public class LimitConfiguration {

	private int minimum,maximum;

	
	
	protected LimitConfiguration() {
		super();
	}

	public int getMinimum() {
		return minimum;
	}

	public int getMaximum() {
		return maximum;
	}

	public LimitConfiguration(int minimum, int maximum) {
		super();
		this.minimum = minimum;
		this.maximum = maximum;
	}
	
	
}
