var fs = require('fs');
var parse = require('csv-parse');

var inputFile='view.csv';
console.log("Processing");

var parser = parse({delimiter: ','}, function (err, data) {
    // when all countries are available,then process them
    // note: array element at index 0 contains the row of headers that we should skip
    data.forEach(function(line) {
      // create country object out of parsed fields

     var country = { "lclid" : line[0],
                       "tstp" : line[1],
                       "energy": line[2]

                    };
      if(country.lclid == "MAC000030")
    { console.log(JSON.stringify(country));}
    });
});

// read the inputFile, feed the contents to the parser
fs.createReadStream(inputFile).pipe(parser);
