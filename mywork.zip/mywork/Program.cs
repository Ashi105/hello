﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Newtonsoft.Json;




using Microsoft.Azure.Documents.Linq;



using Newtonsoft.Json.Serialization;





using System.Configuration;






namespace ConsoleApp16
{
    class Program
    {
        private const string EndpointUrl = "https://localhost:8081";
        private const string PrimaryKey = "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==";
        private DocumentClient client;
        static void Main(string[] args)
        {
            try
            {
                Program p = new Program();
                p.GetStartedDemo().Wait();
            }
            catch (DocumentClientException de)
            {
                Exception baseException = de.GetBaseException();
                Console.WriteLine($"{de.StatusCode} error occurred: {de.Message}, Message: {baseException.Message}");
            }
            catch (Exception e)
            {
                Exception baseException = e.GetBaseException();
                Console.WriteLine($"Error: {e.Message}, Message: {baseException.Message}");
            }
            finally
            {
                Console.WriteLine("End of demo, press any key to exit.");
                Console.ReadKey();
            }
        }
        private async Task GetStartedDemo()
        {
            client = new DocumentClient(new Uri(EndpointUrl), PrimaryKey);

            await client.CreateDatabaseIfNotExistsAsync(new Database { Id = "Dfordatabase" });

            await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri("Dfordatabase"), new DocumentCollection { Id = "DCollection" });
            Uri collectionUri = UriFactory.CreateDocumentCollectionUri("Dfordatabase", "DCollection");
            Book abc = new Book
            {
                id = "abc1",
                Title = "Atomic Habits",
                Author = new Author
                {
                    FirstName = "Leo",
                    LastName = "shark"
                },
                Price = 345,
                Publish = new Publisher[] {
                    new Publisher
                    {
                        Name= "Merriam",
                        Location= "Mumbai",
                       
                        Grade= 8,
                        
                    },
                    new  Publisher
                    {
                        Name= "Lisa",
                        Location= "Delhi",
                        Grade= 1
                    }
                 },

            };
            await CreatePlantDocumentIfNotExists("Dfordatabase", "DCollection", abc);
            Book pqr = new Book
            {
                id = "pqr1",
                Title = "The Writers Journey",
                Author = new Author
                {
                    FirstName = "Leo",
                    LastName = "shark"
                },
                Price = 550,
                Publish = new Publisher[] {
                    new Publisher
                    {
                        Name= "disha",
                        Location= "kolkata",

                        Grade= 5

                    },
                    new  Publisher
                    {
                        Name= "sasa",
                        Location= "Andra Pradesh",
                        Grade= 7
                    }
                 },

            };
            await CreatePlantDocumentIfNotExists("Dfordatabase", "DCollection", pqr);
            Book rst = new Book
            {
                id = "rst1",
                Title = "To Kill a Mocking Bird",
                Author = new Author
                {
                    FirstName = "sherlok",
                    LastName = "homes"
                },
                Price = 600,
                Publish = new Publisher[] {
                    new Publisher
                    {
                        Name= "neon",
                        Location= "UP",

                        Grade= 5

                    },
                    new  Publisher
                    {
                        Name= "LUCKY",
                        Location= "BANGALORE",
                        Grade= 7
                    }
                 },

            };
            await CreatePlantDocumentIfNotExists("Dfordatabase", "DCollection", rst);

            Book uvw = new Book
            {
                id = "uvw1",
                Title = "The Guide",
                Author = new Author
                {
                    FirstName = "sher",
                    LastName = "james"
                },
                Price = 450,
                Publish = new Publisher[] {
                    new Publisher
                    {
                        Name= "JAMES",
                        Location= "Nepal",

                        Grade= 3

                    },
                    new  Publisher
                    {
                        Name= "Darshan",
                        Location= "BANGALORE",
                        Grade= 9
                    }
                 },

            };
            await CreatePlantDocumentIfNotExists("Dfordatabase", "DCollection", uvw);
           
            Console.WriteLine("enter the book title whose record u want to know");
            string tar = Console.ReadLine();
            ExecuteSimpleQuery("Dfordatabase", "DCollection",tar);
            QueryAllDocuments(collectionUri);
            await BasicAsync();

        }
        private void WriteToConsoleAndPromptToContinue(string format, params object[] args)
        {
            Console.WriteLine(format, args);
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
        public class Book
        {

            public string id { get; set; }
            public string Title { get; set; }
            public Author Author { get; set; }
            public int Price { get; set; }
            public Publisher[] Publish { get; set; }

            public override string ToString()
            {
                return JsonConvert.SerializeObject(this);
            }
        }
        public class Author
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
        public class Publisher
        {
            public string Name { get; set; }
            public string Location { get; set; }
            
            public int Grade { get; set; }
          
        }

        private async Task CreatePlantDocumentIfNotExists(string Dfordatabase, string DCollection, Book family)
        {
            try
            {
                await client.ReadDocumentAsync(UriFactory.CreateDocumentUri(Dfordatabase, DCollection, family.id));
                WriteToConsoleAndPromptToContinue($"Found bookid is {family.id}, book title is {family.Title}");
            }
            catch (DocumentClientException de)
            {
                if (de.StatusCode == HttpStatusCode.NotFound)
                {
                    await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(Dfordatabase, DCollection), family);
                    WriteToConsoleAndPromptToContinue($"Created Family {family.id}");
                }
                else
                {
                    throw;
                }
            }

        }
        public void ExecuteSimpleQuery(string databaseName, string collectionName, string bookname)
        {
          
            Book book = client.CreateDocumentQuery<Book>(UriFactory.CreateDocumentCollectionUri(databaseName, collectionName)).Where(b => b.Title == bookname).AsEnumerable().FirstOrDefault();
            Console.WriteLine($"\tRead {book}");
            Console.WriteLine("enter the price range for books");
            int y = int.Parse(Console.ReadLine());

            foreach (Book matchingBook in client.CreateDocumentQuery<Book>(UriFactory.CreateDocumentCollectionUri(databaseName, collectionName)).Where(b => b.Price < y))
            {
                Console.WriteLine($"\tRead {matchingBook}");
                // Iterate through books
            }
            Console.WriteLine("--------------------------------------------------");
            /*
            var query = new SqlQuerySpec(
    "SELECT * FROM books b WHERE b.Title = @title",
    new SqlParameterCollection(new SqlParameter[] { new SqlParameter { Name = "@title", Value = "abchello" } }));
            Book bookA = client.CreateDocumentQuery<Book>(UriFactory.CreateDocumentCollectionUri(databaseName, collectionName), query).AsEnumerable().FirstOrDefault();
            Console.WriteLine($"\tRead {bookA}");
            query = new SqlQuerySpec(
    "SELECT * FROM books b WHERE b.Price > @minPrice",
    new SqlParameterCollection(new SqlParameter[] { new SqlParameter { Name = "@minPrice", Value = 500 } }));
            foreach (Book b in client.CreateDocumentQuery<Book>(
            UriFactory.CreateDocumentCollectionUri(databaseName, collectionName), query)) { Console.WriteLine($"\tRead {b}"); }
            Console.WriteLine("-----------------------------------------------------------------");*/
        }
        private void QueryAllDocuments(Uri collectionUri)

        {
            var query = client.CreateDocumentQuery<Book>(collectionUri)

                      .Where(f => f.id == "rst1" || f.Title == "The Writers Journey")

                      .Select(f => new { Name = f.id, City = f.Title });
            Console.ReadKey();
            Console.WriteLine("The Required Books are");

            foreach (var item in query)

            {

                Console.WriteLine("The {0}  book title is {1}", item.Name, item.City);

            }

            var query1 = client.CreateDocumentQuery<Book>(

                 collectionUri,

                 "SELECT * FROM Families f ORDER BY f.Price");
            Console.ReadKey();
            Console.WriteLine("The Required Books accoring to price");

            foreach (var item in query1)

            {

                Console.WriteLine($"\tRead {item.id} -> {item.Price} ");

            }
            Console.WriteLine("------------------------------------------------");


        }

        private  async Task BasicAsync()

        {
            Console.ReadKey();
            var response = await client.ReadDocumentAsync(UriFactory.CreateDocumentUri("Dfordatabase", "DCollection", "abc1"));

            Console.WriteLine("Document read by Id {0}", response.Resource);
        }

    }
}
