var iothub = require('azure-iothub');
 
var connectionString = 'HostName=myiothub66.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=7xoabxg9ucv7tUl/PzuY3Y/3IwPkzYmWGz6GXkGY+/c=';
 
var registry = iothub.Registry.fromConnectionString(connectionString);
 
// Create a new device
var device = {
deviceId: 'sample-device-' + Date.now()
};
 
registry.create(device, function(err, deviceInfo, res) {
    if (err) console.log(op + ' error: ' + err.toString());
    if (res) console.log(op + ' status: ' + res.statusCode + ' ' + res.statusMessage);
    if (deviceInfo) console.log(op + ' device info: ' + JSON.stringify(deviceInfo));
});