var iothub = require('azure-iothub');
 
var connectionString = 'HostName=myiothub66.azure-devices.net;DeviceId=1234;SharedAccessKey=X+v1bM3BFZ9kqxT3aYv5lSz74m9xolT1F0S6I9oez70=';
 
var registry = iothub.Registry.fromConnectionString(connectionString);
 
// Create a new device
var device = {
deviceId: 'sample-device-' + Date.now()
};
 
registry.create(device, function(err, deviceInfo, res) {
    if (err) console.log(op + ' error: ' + err.toString());
    if (res) console.log(op + ' status: ' + res.statusCode + ' ' + res.statusMessage);
    if (deviceInfo) console.log(op + ' device info: ' + JSON.stringify(deviceInfo));
});