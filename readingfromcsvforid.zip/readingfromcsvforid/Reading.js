'use strict';


var connectionString = 'HostName=myiothub66.azure-devices.net;DeviceId=1234;SharedAccessKey=X+v1bM3BFZ9kqxT3aYv5lSz74m9xolT1F0S6I9oez70=';


var Mqtt = require('azure-iot-device-mqtt').Mqtt;
var DeviceClient = require('azure-iot-device').Client
var Message = require('azure-iot-device').Message;

var client = DeviceClient.fromConnectionString(connectionString, Mqtt);

const fs = require('fs');
var parse = require('csv-parse');
const results = [];
const results1 = [];
var i=0;
var j=0;
var k=0;


var inputFile='view.csv';
console.log("Processing");

var parser = parse({delimiter: ','}, function (err, data) {
    // when all countries are available,then process them
    // note: array element at index 0 contains the row of headers that we should skip
    data.forEach(function(line) {
      // create country object out of parsed fields

     var count =   { "lclid" : line[0],
                       "tstp" : new Date(),
                       "energy": line[2]

                    };
      if(count.lclid == "MAC000030")
    {

       results[i++]= count;


    }
     if(count.lclid == "MAC000103")
     {   results1[k++]= count;}
    });
});

// read the inputFile, feed the contents to the parser
fs.createReadStream(inputFile).pipe(parser);
setInterval(function(){
  // Simulate telemetry.



  //  .on('end', () => {
    //  console.log(results[i++]);


    var show = results[j++];

    var message = new Message(JSON.stringify({
     value: show,
     }));





  console.log('Sending message: ' + message.getData());

//  Send the message.
 client.sendEvent(message, function (err) {
   if (err) {
    console.error('send error: ' + err.toString());
   } else {
     console.log('message sent');
   }
  });
}, 1000);
